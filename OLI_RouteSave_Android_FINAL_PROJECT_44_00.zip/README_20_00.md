# OLI RouteSave 20.0

Cumulative source package based on version 19.0.

This milestone adds a home-screen state/controller foundation and a catalogue for the five principal sections. It does not yet include a rendered Jetpack Compose screen or a working APK.

See `docs/HOME_SCREEN_FOUNDATION_20_00.md` for integration notes and remaining work.
