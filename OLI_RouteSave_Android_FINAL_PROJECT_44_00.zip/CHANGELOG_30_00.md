# Changelog 30.0

- Pridané zoradenie poskytovateľom dodaných plánov podľa ceny, trvania, prestupov alebo času príchodu.
- Pridaná základná ochranná logika vyžadujúca výslovné potvrdenie pred externou akciou.
- Verzia zvýšená na 30.0.
- Živé dopravné dáta a plná hlasová integrácia zostávajú nepripojené.
