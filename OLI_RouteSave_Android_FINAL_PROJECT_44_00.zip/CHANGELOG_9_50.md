# OLI RouteSave 9.50

Pridaná správa vlastných pomenovaní kontaktov: repository rozhranie, validačné use cases, zoznam/odstránenie aliasov a text ochrany súkromia. Trvalé Android úložisko a UI ešte treba doplniť.
