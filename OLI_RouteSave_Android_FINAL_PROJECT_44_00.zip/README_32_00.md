# OLI RouteSave 32.0

# OLI RouteSave 32.0 — Hlasová konverzácia a bezpečný tok potvrdenia

## Pridané
- Platformovo nezávislý `VoiceConversationEngine` pre odpovede asistenta na rozpoznaný príkaz.
- Modely odpovedí: informácia, otázka na potvrdenie, spresnenie alebo chyba.
- Základné rozlíšenie nízkej istoty rozpoznania; pri neistote asistent požiada o zopakovanie.
- Pomocný model kontaktu a bezpečné riešenie kontaktu: nula zhôd → spresnenie, jedna zhoda → kandidát, viac zhôd → výber/spresnenie. Samotné volanie sa nevykoná.
- `VoiceConfirmationFlow`, ktorý odlišuje jasné „áno“, jasné „nie“ a nejednoznačnú odpoveď.
- Verzia zvýšená na 32.0.

## Bezpečnostné správanie
- Telefonát, SMS, zdieľanie polohy, otvorenie rezervácie a nákup lístka sa najprv zmenia na čakajúcu akciu s hlasovou otázkou.
- Samotné rozpoznanie príkazu nie je súhlas.
- Neistá odpoveď alebo nejednoznačný kontakt vyžaduje doplňujúcu otázku.
- Tento modul neuskutočňuje telefonáty, neposiela správy a nezdieľa polohu.

## Čo ešte treba napojiť v Android aplikácii
- Android `SpeechRecognizer` alebo inú službu rozpoznávania reči, vrátane oprávnení a spracovania chýb.
- Android `TextToSpeech` na skutočné hovorené odpovede a výber jazyka/hlasu.
- Android Contacts Provider na čítanie kontaktov až po udelení povolenia.
- Android Telecom/Intent na uskutočnenie hovoru až po výslovnom potvrdení používateľa.
- SMS aplikáciu alebo podporovanú službu, ak bude používateľ chcieť odoslať správu; aj tá vyžaduje samostatné potvrdenie.
- Testy na zariadení a kontrolu správania pri vypnutom mikrofóne, slabom signáli, hluku a odmietnutých oprávneniach.

## Stav zostavenia
Toto je zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
