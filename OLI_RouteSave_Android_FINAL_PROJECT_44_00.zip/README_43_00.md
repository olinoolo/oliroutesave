# OLI RouteSave 43.0

# OLI RouteSave 43.0 — cloud build APK bez počítača

## Čo je nové
- Pridaný GitHub Actions workflow `.github/workflows/android-apk.yml`.
- Workflow používa Java 17, Gradle 8.9 a Android SDK 35 a pokúsi sa zostaviť `app-debug.apk`.
- APK sa po úspešnom zostavení uloží ako artefakt s názvom `OLI-RouteSave-debug-APK`.
- Verzia aplikácie zvýšená na 43.0.

## Dôležité obmedzenie
Workflow sa nespustí len tým, že ZIP stiahneš do telefónu. Musí byť nahraný a rozbalený ako zdrojové súbory v GitHub repozitári. GitHub Actions následne spustí zostavenie v cloude. Tento archív ešte nebol zostavený a nevieme, či Kotlin kompilácia prejde.

## Postup z Android telefónu
1. Stiahni ZIP a rozbaľ ho v aplikácii na správu súborov, ak máš takú možnosť.
2. Otvor existujúci OLI RouteSave repozitár v prehliadači a skontroluj, či už obsahuje zdrojové súbory projektu.
3. Ak je repozitár už synchronizovaný s týmito zdrojmi, nahraj/commitni priečinok `.github/workflows/android-apk.yml` a zmeny verzie 43.0.
4. V repozitári otvor kartu **Actions**.
5. Vyber **Build OLI RouteSave APK** a stlač **Run workflow** (alebo workflow spustí push do `main`/`master`).
6. Ak beh skončí zeleno, otvor dokončený beh a sekciu **Artifacts**.
7. Stiahni `OLI-RouteSave-debug-APK`, rozbaľ stiahnutý artefakt a nájdi `app-debug.apk`.
8. Otvor APK v telefóne a povoľ inštaláciu z daného zdroja, ak Android o to požiada.

## Ak repozitár ešte nemá zdrojové súbory
Samotné nahratie ZIP-u ako jedného súboru do GitHub repozitára nestačí — GitHub Actions by nevidel projektové súbory na koreňovej úrovni. Vtedy treba najprv dostať rozbalený obsah projektu do repozitára. Na telefóne to môže byť nepraktické; nebudem predstierať, že sa dá urobiť jediným kliknutím.

## Čo sa ešte neoverilo
- Gradle build sa v tomto prostredí nevykonal.
- APK zatiaľ neexistuje.
- Workflow sa ešte nespustil a môže odhaliť skutočné chyby v zdrojovom kóde.
