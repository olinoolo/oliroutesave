package com.oli.routesave.data.model

data class TripRecord(
    val id: String,
    val vehicleId: String?,
    val origin: String,
    val destination: String,
    val distanceKm: Double,
    val consumptionL100Km: Double,
    val fuelPricePerLiter: Double,
    val fuelCost: Double,
    val tollCost: Double = 0.0,
    val parkingCost: Double = 0.0,
    val totalCost: Double = fuelCost + tollCost + parkingCost,
    val createdAtEpochMs: Long
)
