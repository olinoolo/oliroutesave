package com.oli.routesave.ui

data class RouteUiState(
    val origin: String = "",
    val destination: String = "",
    val distanceKm: Double? = null,
    val durationMinutes: Int? = null,
    val fuelCost: Double? = null,
    val tollCost: Double? = null,
    val parkingCost: Double? = null,
    val totalCost: Double? = null,
    val loading: Boolean = false,
    val error: String? = null
)
