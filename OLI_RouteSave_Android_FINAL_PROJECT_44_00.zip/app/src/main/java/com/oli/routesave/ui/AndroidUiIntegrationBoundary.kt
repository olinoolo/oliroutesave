package com.oli.routesave.ui

/**
 * Boundary for the actual Android UI toolkit.
 *
 * A production implementation can connect this contract to Jetpack Compose
 * or XML views without changing the application/domain layer.
 */
interface AndroidUiIntegrationBoundary {
    fun renderHome(state: HomeUiState)
    fun renderDrive(state: DriveUiState)
    fun renderRoute(state: RouteUiState)
    fun renderVehicle(state: VehicleUiState)
    fun renderAssistant(state: AssistantUiState)
    fun renderCommunity(state: CommunityUiState)
    fun renderSettings(state: SettingsUiState)
}
