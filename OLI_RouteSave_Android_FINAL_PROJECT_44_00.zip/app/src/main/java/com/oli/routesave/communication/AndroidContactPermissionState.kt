package com.oli.routesave.communication

/**
 * Platform-neutral permission states for the Android contacts adapter.
 * The actual Android adapter must request READ_CONTACTS at runtime and explain
 * why access is needed. A permission grant never authorizes placing a call.
 */
enum class ContactPermissionState {
    GRANTED,
    NOT_GRANTED,
    PERMANENTLY_DENIED,
    NOT_YET_REQUESTED
}

sealed interface ContactLookupOutcome {
    data class Found(val contacts: List<ContactCandidate>) : ContactLookupOutcome
    data object NoMatch : ContactLookupOutcome
    data object PermissionRequired : ContactLookupOutcome
    data class Failed(val reason: String) : ContactLookupOutcome
}

data class ContactCandidate(
    val contactId: String,
    val displayName: String,
    val phoneNumbers: List<ContactPhoneNumber>
)

data class ContactPhoneNumber(
    val label: String?,
    val number: String,
    val normalizedNumber: String? = null
)
