package com.oli.routesave.android.runtime
import com.oli.routesave.runtime.location.*
class AndroidLocationLifecycle(private val delegate:AndroidLocationDelegate):LocationProvider{
 private var active=false
 override fun start(onLocation:(LocationPoint)->Unit){delegate.startLocationUpdates(onLocation);active=true}
 override fun stop(){delegate.stopLocationUpdates();active=false}
 override fun isActive()=active
}
interface AndroidLocationDelegate{fun startLocationUpdates(callback:(LocationPoint)->Unit);fun stopLocationUpdates()}
