package com.oli.routesave.android.runtime

data class DriveRuntimeSnapshot(
    val state: DriveRuntimeState = DriveRuntimeState.STOPPED,
    val foregroundActive: Boolean = false,
    val locationActive: Boolean = false,
    val audioFocusActive: Boolean = false,
    val notificationActive: Boolean = false
)
