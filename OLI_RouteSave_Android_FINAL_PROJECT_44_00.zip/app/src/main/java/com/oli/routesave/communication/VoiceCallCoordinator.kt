package com.oli.routesave.communication

/**
 * Confirmation-first flow for voice-controlled calls.
 *
 * UI/voice layer should read confirmationPrompt aloud and wait for an explicit
 * yes/no. A permission grant is not consent. Unknown or ambiguous contacts
 * must be clarified before this coordinator is called with a final request.
 */
class VoiceCallCoordinator(
    private val providers: Map<CallChannel, CommunicationCallProvider>
) {
    data class PendingCall(
        val request: CallRequest,
        val confirmationPrompt: String,
        val launchToken: String
    )

    sealed interface PrepareOutcome {
        data class NeedsConfirmation(val pending: PendingCall) : PrepareOutcome
        data class CannotProceed(val reason: String) : PrepareOutcome
    }

    sealed interface ConfirmOutcome {
        data object Cancelled : ConfirmOutcome
        data object Started : ConfirmOutcome
        data class Failed(val reason: String) : ConfirmOutcome
    }

    suspend fun prepare(request: CallRequest): PrepareOutcome {
        val provider = providers[request.channel]
            ?: return PrepareOutcome.CannotProceed("Tento spôsob volania nie je pripojený.")

        val capability = provider.capability(request.mode)
        if (!capability.available) {
            return PrepareOutcome.CannotProceed(
                capability.explanation ?: "Vybraný spôsob volania nie je dostupný."
            )
        }
        if (request.mode == CallMode.VIDEO && !capability.supportsVideo) {
            return PrepareOutcome.CannotProceed("Tento poskytovateľ nepodporuje spustenie videohovoru.")
        }
        if (request.mode == CallMode.AUDIO && !capability.supportsAudio) {
            return PrepareOutcome.CannotProceed("Tento poskytovateľ nepodporuje hlasové hovory.")
        }

        return when (val result = provider.prepare(request)) {
            is CallPreparationResult.Ready -> PrepareOutcome.NeedsConfirmation(
                PendingCall(
                    request = request,
                    confirmationPrompt = buildConfirmationPrompt(request),
                    launchToken = result.launchToken
                )
            )
            is CallPreparationResult.Unavailable -> PrepareOutcome.CannotProceed(result.reason)
            is CallPreparationResult.NeedsClarification -> PrepareOutcome.CannotProceed(result.question)
        }
    }

    suspend fun confirm(pending: PendingCall, clearlyConfirmed: Boolean): ConfirmOutcome {
        if (!clearlyConfirmed) return ConfirmOutcome.Cancelled

        val provider = providers[pending.request.channel]
            ?: return ConfirmOutcome.Failed("Poskytovateľ hovoru už nie je dostupný.")

        return when (val result = provider.launchConfirmed(pending.request, pending.launchToken)) {
            CallLaunchResult.Started -> ConfirmOutcome.Started
            is CallLaunchResult.Failed -> ConfirmOutcome.Failed(result.reason)
        }
    }

    private fun buildConfirmationPrompt(request: CallRequest): String {
        val target = when (val destination = request.destination) {
            is CallDestination.Contact -> destination.displayName
            is CallDestination.PhoneNumber -> destination.normalizedNumber
        }
        val mode = if (request.mode == CallMode.VIDEO) "videohovor" else "hlasový hovor"
        val channel = when (request.channel) {
            CallChannel.PHONE -> "bežným telefonátom"
            CallChannel.WHATSAPP -> "cez WhatsApp"
            CallChannel.MESSENGER -> "cez Messenger"
        }
        return "Mám spustiť $mode s kontaktom alebo číslom $target $channel?"
    }
}
