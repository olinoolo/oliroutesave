package com.oli.routesave.messaging

/**
 * App-specific implementation should use the supported RemoteInput action
 * from the exact notification after the user confirms the recipient and text.
 */
data class PreparedMessageReply(
    val notificationKey: String,
    val packageName: String,
    val recipientLabel: String,
    val text: String
)

sealed class MessageReplyResult {
    object Sent : MessageReplyResult()
    data class Unavailable(val reason: String) : MessageReplyResult()
    data class Failed(val reason: String) : MessageReplyResult()
}

interface NotificationReplyProvider {
    fun canReply(notificationKey: String): Boolean
    fun sendConfirmedReply(reply: PreparedMessageReply): MessageReplyResult
}
