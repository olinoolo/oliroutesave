package com.oli.routesave.community

interface CommunityHelpRepository {
    suspend fun publishConfirmed(request: CommunityHelpRequest): CommunityPublishResult
    suspend fun cancel(requestId: String): Boolean
}

sealed interface CommunityPublishResult {
    data class Published(val requestId: String) : CommunityPublishResult
    data class Rejected(val reason: String) : CommunityPublishResult
    data class Failed(val reason: String) : CommunityPublishResult
}

/**
 * Enforces that only a request marked PUBLISHED after consent can be passed
 * to a repository. The real repository must still enforce authentication,
 * expiry, access control and server-side validation.
 */
class ConfirmedCommunityHelpPublisher(
    private val repository: CommunityHelpRepository,
    private val nowMillis: () -> Long = { System.currentTimeMillis() }
) {
    suspend fun publish(request: CommunityHelpRequest): CommunityPublishResult {
        if (request.status != HelpRequestStatus.PUBLISHED) {
            return CommunityPublishResult.Rejected("Žiadosť nebola výslovne potvrdená.")
        }
        if (request.expiresAtEpochMillis <= nowMillis()) {
            return CommunityPublishResult.Rejected("Žiadosť o pomoc už vypršala.")
        }
        if (CommunityHelpRequestValidator.validate(request) !is CommunityHelpValidation.Valid) {
            return CommunityPublishResult.Rejected("Žiadosť obsahuje neplatné údaje.")
        }
        return repository.publishConfirmed(request)
    }
}
