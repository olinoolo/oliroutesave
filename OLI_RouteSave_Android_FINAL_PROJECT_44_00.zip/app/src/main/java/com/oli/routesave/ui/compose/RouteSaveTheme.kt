package com.oli.routesave.ui.compose

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Navy = Color(0xFF071A2D)
private val Panel = Color(0xFF102A43)
private val Blue = Color(0xFF168BFF)
private val Orange = Color(0xFFFF7900)
private val TextMain = Color(0xFFF5F8FC)
private val TextMuted = Color(0xFFB7C7D8)

private val RouteSaveColors = darkColorScheme(
    primary = Blue,
    secondary = Orange,
    background = Navy,
    surface = Panel,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = TextMain,
    onSurface = TextMain,
    surfaceVariant = Color(0xFF18364F),
    onSurfaceVariant = TextMuted
)

@Composable
fun RouteSaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RouteSaveColors,
        content = content
    )
}
