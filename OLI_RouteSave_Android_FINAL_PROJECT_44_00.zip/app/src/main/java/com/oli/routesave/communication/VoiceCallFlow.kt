package com.oli.routesave.communication

/**
 * Orchestrates number parsing and contact-selection decisions into spoken
 * prompts. The Android UI/speech adapter supplies actual recognition and
 * speaks the returned prompt. No phonebook access or call is performed here.
 */
sealed interface VoiceCallFlowResult {
    data class Speak(val text: String) : VoiceCallFlowResult
    data class NumberReadyForReadback(val number: String) : VoiceCallFlowResult
    data class ContactLookupRequired(val query: String) : VoiceCallFlowResult
}

class VoiceCallFlow(
    private val numberParser: PhoneNumberEntryParser = PhoneNumberEntryParser()
) {
    fun handleNumberTranscript(transcript: String): VoiceCallFlowResult =
        when (val result = numberParser.parse(transcript)) {
            is PhoneNumberEntryResult.AcceptedForReview ->
                VoiceCallFlowResult.NumberReadyForReadback(result.dialableNumber)
            is PhoneNumberEntryResult.NeedsClarification ->
                VoiceCallFlowResult.Speak(result.prompt)
            is PhoneNumberEntryResult.Rejected ->
                VoiceCallFlowResult.Speak(result.reason)
        }

    fun requestContactLookup(spokenContact: String): VoiceCallFlowResult {
        val query = spokenContact.trim()
        return if (query.isBlank()) {
            VoiceCallFlowResult.Speak("Koho mám vyhľadať v kontaktoch?")
        } else {
            VoiceCallFlowResult.ContactLookupRequired(query)
        }
    }
}
