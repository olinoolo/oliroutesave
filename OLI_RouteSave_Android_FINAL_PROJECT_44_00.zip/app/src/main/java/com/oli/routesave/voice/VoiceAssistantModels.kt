package com.oli.routesave.voice

/**
 * Domain types for the hands-free assistant. These types do not themselves
 * implement Android speech recognition, microphone capture, or phone actions.
 */
enum class VoiceAssistantId(val displayName: String, val invocation: String) {
    MAREK("Marek", "Marek"),
    BRANISLAV("Branislav", "Brandži"),
    NIKOLAS("Nikolas", "Niko"),
    TANYA("Tanya", "Tanya"),
    VANESA("Vanesa", "Vany"),
    NATALIA("Natália", "Naty"),
    KATERINA("Kateřina", "Kateřina")
}

enum class VoiceIntent {
    SET_DESTINATION,
    SEARCH_TRANSIT,
    CALCULATE_TRIP_COST,
    CALL_CONTACT,
    SEND_MESSAGE,
    SHARE_LOCATION,
    OPEN_BOOKING,
    PURCHASE_TICKET,
    UNKNOWN
}

enum class VoiceActionRisk {
    LOCAL_INFORMATION, EXTERNAL_ACTION, SENSITIVE_EXTERNAL_ACTION
}

data class VoiceCommand(
    val rawText: String,
    val assistant: VoiceAssistantId,
    val intent: VoiceIntent,
    val entities: Map<String, String> = emptyMap(),
    val confidence: Float = 0f
)

data class VoiceCommandResult(
    val understood: Boolean,
    val responseText: String,
    val requiresConfirmation: Boolean,
    val actionReady: Boolean = false
)

data class PendingVoiceAction(
    val intent: VoiceIntent,
    val summary: String,
    val assistant: VoiceAssistantId,
    val confirmationPrompt: String,
    val isConfirmed: Boolean = false
)

object VoiceCommandPolicy {
    private val confirmationRequired = setOf(
        VoiceIntent.CALL_CONTACT,
        VoiceIntent.SEND_MESSAGE,
        VoiceIntent.SHARE_LOCATION,
        VoiceIntent.OPEN_BOOKING,
        VoiceIntent.PURCHASE_TICKET
    )

    fun requiresConfirmation(intent: VoiceIntent): Boolean =
        intent in confirmationRequired

    /**
     * A yes/no utterance only counts as confirmation if it is clear and is
     * tied to the currently pending action. Recognition permission is not consent.
     */
    fun confirmPendingAction(
        pending: PendingVoiceAction?,
        recognizedText: String,
        confidence: Float
    ): PendingVoiceAction? {
        if (pending == null || confidence < 0.85f) return null
        val normalized = recognizedText.trim().lowercase()
        val explicitYes = normalized in setOf(
            "áno", "ano", "áno potvrď", "ano potvrd", "potvrdzujem",
            "yes", "confirm", "ja"
        )
        if (!explicitYes) return null
        return pending.copy(isConfirmed = true)
    }

    fun invocationMatches(text: String, assistant: VoiceAssistantId): Boolean {
        val normalized = text.trim().lowercase()
        val invocation = assistant.invocation.lowercase()
        return normalized.startsWith("$invocation ") ||
            normalized == invocation ||
            normalized.startsWith("$invocation,") ||
            normalized.startsWith("$invocation:")
    }

    fun createConfirmationPrompt(
        intent: VoiceIntent,
        assistant: VoiceAssistantId,
        summary: String
    ): PendingVoiceAction {
        val verb = when (intent) {
            VoiceIntent.CALL_CONTACT -> "Mám zavolať"
            VoiceIntent.SEND_MESSAGE -> "Mám odoslať správu"
            VoiceIntent.SHARE_LOCATION -> "Mám zdieľať tvoju polohu"
            VoiceIntent.OPEN_BOOKING -> "Mám otvoriť stránku rezervácie"
            VoiceIntent.PURCHASE_TICKET -> "Mám pokračovať k nákupu lístka"
            else -> "Mám vykonať túto akciu"
        }
        return PendingVoiceAction(
            intent = intent,
            summary = summary,
            assistant = assistant,
            confirmationPrompt = "$verb: $summary? Povedz jasne áno alebo nie."
        )
    }
}
