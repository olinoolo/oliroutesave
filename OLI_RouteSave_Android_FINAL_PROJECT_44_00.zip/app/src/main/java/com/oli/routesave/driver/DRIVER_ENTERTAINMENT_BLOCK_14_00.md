# OLI RouteSave 14.0 — Driver support and entertainment

## Included
- Configurable reminders before a user-defined break deadline (default lead: 30 minutes).
- User-configurable planned break duration (default 45 minutes).
- Rest-stop provider interface with input validation, result filtering and distance sorting.
- Rest-stop fields for truck/car parking, toilets, food, source and last update.
- Entertainment item model for music, podcasts, audiobooks, quizzes, word games and travel facts.
- Safety policy that defers entertainment during emergencies, active calls and critical navigation, and avoids visual word games while driving.

## Not yet connected
- No GPS or live rest-stop/parking provider is connected.
- No audio catalog, music service, podcast directory or audiobook provider is connected.
- Break times are user-configurable reminders, not tachograph data or a determination of legal compliance.
- App UI, notification scheduling, audio playback and Android background/lifecycle integration remain to be wired.

## Safety notes
- Reminders should not encourage stopping in unsafe places; recommend only a safe, legal stopping place.
- Do not display or ask for visual interaction while the vehicle is moving.
- The app must not claim to be a certified tachograph or legal rest-time calculator.
- Source-only milestone; not compiled or device-tested.
