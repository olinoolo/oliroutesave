package com.oli.routesave.ui.compose

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Preview(showBackground = true, backgroundColor = 0xFF071A2D)
@Composable
private fun RouteSavePreview() {
    RouteSaveComposeApp()
}
