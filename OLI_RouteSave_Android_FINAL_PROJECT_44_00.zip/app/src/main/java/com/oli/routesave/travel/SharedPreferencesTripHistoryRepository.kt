package com.oli.routesave.travel

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Local persistent trip history. Records are stored in app-private preferences.
 * For larger histories or complex querying, migrate this adapter to Room.
 */
class SharedPreferencesTripHistoryRepository(
    context: Context,
    preferencesName: String = DEFAULT_PREFERENCES_NAME
) : TripHistoryRepository {
    private val preferences: SharedPreferences =
        context.applicationContext.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
    private val lock = Any()

    override fun save(record: TripHistoryRecord) {
        val errors = record.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        synchronized(lock) {
            preferences.edit().putString(KEY_PREFIX + record.id, encode(record)).apply()
        }
    }

    override fun find(id: String): TripHistoryRecord? = synchronized(lock) {
        preferences.getString(KEY_PREFIX + id, null)?.let(::decodeOrNull)
    }

    override fun all(): List<TripHistoryRecord> = synchronized(lock) {
        preferences.all.entries.asSequence()
            .filter { it.key.startsWith(KEY_PREFIX) }
            .mapNotNull { (it.value as? String)?.let(::decodeOrNull) }
            .sortedByDescending { it.createdAtEpochMs }
            .toList()
    }

    override fun delete(id: String): Boolean = synchronized(lock) {
        val key = KEY_PREFIX + id
        if (!preferences.contains(key)) false
        else {
            preferences.edit().remove(key).apply()
            true
        }
    }

    override fun clear() {
        synchronized(lock) {
            val editor = preferences.edit()
            preferences.all.keys.filter { it.startsWith(KEY_PREFIX) }.forEach(editor::remove)
            editor.apply()
        }
    }

    private fun encode(r: TripHistoryRecord): String =
        JSONObject()
            .put("id", r.id)
            .put("origin", r.origin)
            .put("destination", r.destination)
            .put("distanceKm", r.distanceKm)
            .put("consumptionL100Km", r.consumptionL100Km)
            .put("fuelPricePerLitre", r.fuelPricePerLitre)
            .put("fuelLitres", r.fuelLitres)
            .put("fuelCost", r.fuelCost)
            .put("tollCost", r.tollCost)
            .put("parkingCost", r.parkingCost)
            .put("otherCosts", r.otherCosts)
            .put("totalCost", r.totalCost)
            .put("currencyCode", r.currencyCode)
            .put("vehicleId", r.vehicleId ?: JSONObject.NULL)
            .put("createdAtEpochMs", r.createdAtEpochMs)
            .toString()

    private fun decodeOrNull(raw: String): TripHistoryRecord? = try {
        val j = JSONObject(raw)
        val record = TripHistoryRecord(
            id = j.optString("id"),
            origin = j.optString("origin"),
            destination = j.optString("destination"),
            distanceKm = j.optDouble("distanceKm", Double.NaN),
            consumptionL100Km = j.optDouble("consumptionL100Km", Double.NaN),
            fuelPricePerLitre = j.optDouble("fuelPricePerLitre", Double.NaN),
            fuelLitres = j.optDouble("fuelLitres", Double.NaN),
            fuelCost = j.optDouble("fuelCost", Double.NaN),
            tollCost = j.optDouble("tollCost", Double.NaN),
            parkingCost = j.optDouble("parkingCost", Double.NaN),
            otherCosts = j.optDouble("otherCosts", Double.NaN),
            totalCost = j.optDouble("totalCost", Double.NaN),
            currencyCode = j.optString("currencyCode", "EUR"),
            vehicleId = if (j.isNull("vehicleId")) null else j.optString("vehicleId"),
            createdAtEpochMs = j.optLong("createdAtEpochMs", -1L)
        )
        if (record.validate().isEmpty()) record else null
    } catch (_: Exception) {
        null
    }

    companion object {
        const val DEFAULT_PREFERENCES_NAME = "oli_routesave_trip_history"
        private const val KEY_PREFIX = "trip:"
    }
}
