package com.oli.routesave.communication

/**
 * Small deterministic policy layer for explicit voice confirmation.
 * Speech recognition must map an utterance to YES/NO/UNCLEAR using a localized
 * recognizer; unclear responses must never be treated as consent.
 */
enum class VoiceConfirmationAnswer { YES, NO, UNCLEAR }

sealed interface ConfirmationDecision {
    data object Approved : ConfirmationDecision
    data object Rejected : ConfirmationDecision
    data class AskAgain(val prompt: String) : ConfirmationDecision
    data object Expired : ConfirmationDecision
    data object Stale : ConfirmationDecision
}

class CallConfirmationPolicy {
    fun decide(
        answer: VoiceConfirmationAnswer,
        expectedNonce: String,
        receivedNonce: String,
        expiresAtEpochMillis: Long,
        nowEpochMillis: Long
    ): ConfirmationDecision {
        if (expectedNonce != receivedNonce) return ConfirmationDecision.Stale
        if (nowEpochMillis >= expiresAtEpochMillis) return ConfirmationDecision.Expired
        return when (answer) {
            VoiceConfirmationAnswer.YES -> ConfirmationDecision.Approved
            VoiceConfirmationAnswer.NO -> ConfirmationDecision.Rejected
            VoiceConfirmationAnswer.UNCLEAR -> ConfirmationDecision.AskAgain(
                "Nerozumel som potvrdeniu. Mám hovor spustiť? Povedz áno alebo nie."
            )
        }
    }
}
