package com.oli.routesave.runtime.location

data class LocationPoint(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 0f,
    val timestampEpochMs: Long = 0L
)
