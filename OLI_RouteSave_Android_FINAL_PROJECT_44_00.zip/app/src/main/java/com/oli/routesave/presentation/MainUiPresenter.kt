package com.oli.routesave.presentation

import com.oli.routesave.core.RouteSaveApplicationState
import com.oli.routesave.ui.AppScreen

class MainUiPresenter {
    fun present(state: RouteSaveApplicationState): MainUiModel {
        val drive = state.drive
        return MainUiModel(
            assistantInvocation = drive.assistantInvocation,
            vehicleName = drive.vehicleName.ifBlank { "Moje vozidlo" },
            destination = drive.destination,
            eta = drive.etaText,
            remainingKm = drive.remainingKm?.let { "%.1f km".format(it) }.orEmpty(),
            driving = drive.isDriving,
            listening = drive.voiceListening
        )
    }

    fun actionToScreen(action: MainUiAction): AppScreen? = when (action) {
        MainUiAction.OpenRoute -> AppScreen.ROUTE
        MainUiAction.OpenVehicle -> AppScreen.VEHICLE
        MainUiAction.OpenAssistant -> AppScreen.ASSISTANT
        MainUiAction.OpenCommunity -> AppScreen.COMMUNITY
        MainUiAction.OpenSettings -> AppScreen.SETTINGS
        else -> null
    }
}
