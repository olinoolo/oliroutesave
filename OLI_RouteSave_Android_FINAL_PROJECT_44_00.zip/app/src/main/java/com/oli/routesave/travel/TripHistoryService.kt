package com.oli.routesave.travel

import java.util.UUID

class TripHistoryService(
    private val repository: TripHistoryRepository
) {
    fun recordEstimate(
        origin: String,
        destination: String,
        vehicle: VehicleProfile,
        input: TripCostInput,
        estimate: TripCostEstimate,
        createdAtEpochMs: Long = System.currentTimeMillis(),
        id: String = UUID.randomUUID().toString()
    ): TripHistoryRecord {
        val record = TripHistoryRecord(
            id = id,
            origin = origin.trim(),
            destination = destination.trim(),
            distanceKm = estimate.distanceKm,
            consumptionL100Km = estimate.consumptionLitresPer100Km,
            fuelPricePerLitre = input.fuelPricePerLitre,
            fuelLitres = estimate.fuelLitres,
            fuelCost = estimate.fuelCost,
            tollCost = estimate.tollCost,
            parkingCost = estimate.parkingCost,
            otherCosts = estimate.otherCosts,
            totalCost = estimate.totalCost,
            currencyCode = estimate.currencyCode,
            vehicleId = vehicle.id,
            createdAtEpochMs = createdAtEpochMs
        )
        repository.save(record)
        return record
    }

    fun history(): List<TripHistoryRecord> = repository.all()

    fun summary(): TripHistorySummary {
        val records = repository.all()
        val currency = records.firstOrNull()?.currencyCode ?: "EUR"
        val sameCurrency = records.filter { it.currencyCode == currency }
        return TripHistorySummary(
            tripCount = sameCurrency.size,
            totalDistanceKm = sameCurrency.sumOf { it.distanceKm },
            totalFuelLitres = sameCurrency.sumOf { it.fuelLitres },
            totalCost = sameCurrency.sumOf { it.totalCost },
            currencyCode = currency
        )
    }

    fun delete(id: String): Boolean = repository.delete(id)
}
