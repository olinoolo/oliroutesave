package com.oli.routesave.travel

enum class TravelMode {
    CAR, TRAIN, BUS, PLANE
}

data class VehicleProfile(
    val id: String,
    val displayName: String,
    val averageConsumptionLitresPer100Km: Double,
    val defaultFuelPricePerLitre: Double? = null
) {
    fun validate(): List<String> = buildList {
        if (id.isBlank()) add("ID vozidla je povinné.")
        if (displayName.isBlank()) add("Názov vozidla je povinný.")
        if (!averageConsumptionLitresPer100Km.isFinite() ||
            averageConsumptionLitresPer100Km < 0.0 ||
            averageConsumptionLitresPer100Km > 100.0
        ) add("Spotreba musí byť v rozsahu 0 až 100 l/100 km.")
        if (defaultFuelPricePerLitre != null &&
            (!defaultFuelPricePerLitre.isFinite() || defaultFuelPricePerLitre < 0.0 || defaultFuelPricePerLitre > 20.0)
        ) add("Cena paliva musí byť v rozsahu 0 až 20 za liter.")
    }
}

data class TripCostInput(
    val distanceKm: Double,
    val fuelPricePerLitre: Double,
    val consumptionOverrideLitresPer100Km: Double? = null,
    val tollCost: Double = 0.0,
    val parkingCost: Double = 0.0,
    val otherCosts: Double = 0.0
)

data class TripCostEstimate(
    val distanceKm: Double,
    val consumptionLitresPer100Km: Double,
    val fuelLitres: Double,
    val fuelCost: Double,
    val tollCost: Double,
    val parkingCost: Double,
    val otherCosts: Double,
    val totalCost: Double,
    val currencyCode: String
)

sealed interface TripCostResult {
    data class Success(val estimate: TripCostEstimate) : TripCostResult
    data class Invalid(val reasons: List<String>) : TripCostResult
}
