package com.oli.routesave.communication

/**
 * Adapter boundary for Android Contacts or app-specific contact lookup.
 * Implementations must not guess when more than one result matches.
 */
interface ContactResolver {
    suspend fun resolveSpokenReference(reference: String): ContactResolution
}

sealed interface ContactResolution {
    data class Match(val contact: CallDestination.Contact) : ContactResolution
    data class MultipleMatches(val displayNames: List<String>) : ContactResolution
    data object NotFound : ContactResolution
}

/** Accepts a dictated number even when it is not saved in Contacts. */
interface PhoneNumberNormalizer {
    fun normalize(spokenOrTypedNumber: String, defaultRegion: String? = null): NumberNormalization
}

sealed interface NumberNormalization {
    data class Valid(val e164OrDialableNumber: String) : NumberNormalization
    data class Invalid(val reason: String) : NumberNormalization
}
