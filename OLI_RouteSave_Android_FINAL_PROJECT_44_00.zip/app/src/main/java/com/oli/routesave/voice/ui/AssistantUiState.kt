package com.oli.routesave.voice.ui

import com.oli.routesave.voice.intent.ExternalActionType

enum class AssistantUiPhase {
    READY, LISTENING, PROCESSING, SPEAKING, WAITING_FOR_CONFIRMATION, ERROR
}

data class AssistantUiState(
    val phase: AssistantUiPhase = AssistantUiPhase.READY,
    val statusText: String = "Niko je pripravený",
    val lastRecognizedText: String? = null,
    val lastResponse: String? = null,
    val pendingAction: ExternalActionType? = null,
    val errorMessage: String? = null
) {
    val needsConfirmation: Boolean
        get() = phase == AssistantUiPhase.WAITING_FOR_CONFIRMATION && pendingAction != null
}
