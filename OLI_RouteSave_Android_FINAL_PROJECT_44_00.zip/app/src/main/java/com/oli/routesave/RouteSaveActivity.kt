package com.oli.routesave

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.oli.routesave.ui.compose.RouteSaveComposeApp

/**
 * Launcher Activity host for the Compose UI.
 *
 * Navigation, map, speech, and real permission-dependent actions still need
 * to be connected to their runtime providers before production use.
 */
class RouteSaveActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RouteSaveComposeApp()
        }
    }
}
