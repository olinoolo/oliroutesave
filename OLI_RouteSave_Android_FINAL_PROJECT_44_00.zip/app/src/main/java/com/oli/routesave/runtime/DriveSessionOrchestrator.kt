package com.oli.routesave.runtime

import com.oli.routesave.android.runtime.DriveRuntimeCoordinator
import com.oli.routesave.android.runtime.DriveRuntimeEvent
import com.oli.routesave.android.runtime.DriveRuntimeSnapshot
import com.oli.routesave.runtime.location.LocationSession
import com.oli.routesave.runtime.navigation.NavigationSession
import com.oli.routesave.ui.DriveUiController

class DriveSessionOrchestrator(
    private val runtime: DriveRuntimeCoordinator,
    private val location: LocationSession,
    private val navigation: NavigationSession,
    private val ui: DriveUiController
) {
    fun start(): DriveRuntimeSnapshot {
        ui.startDriving()
        return runtime.handle(DriveRuntimeEvent.Start)
    }

    fun pause(): DriveRuntimeSnapshot {
        navigation.pause()
        return runtime.handle(DriveRuntimeEvent.Pause)
    }

    fun resume(): DriveRuntimeSnapshot {
        navigation.resume()
        return runtime.handle(DriveRuntimeEvent.Resume)
    }

    fun stop(): DriveRuntimeSnapshot {
        navigation.stop()
        location.stop()
        ui.stopDriving()
        return runtime.handle(DriveRuntimeEvent.Stop)
    }

    fun attachLocationUpdates() {
        location.start { point ->
            // Location is intentionally kept behind the provider boundary.
            // A production navigation engine consumes this point.
            if (point.accuracyMeters < 0f) {
                runtime.handle(DriveRuntimeEvent.Error("Neplatná presnosť GPS"))
            }
        }
    }
}
