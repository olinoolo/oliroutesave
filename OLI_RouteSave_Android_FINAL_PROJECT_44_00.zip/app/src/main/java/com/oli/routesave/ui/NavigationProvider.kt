package com.oli.routesave.ui

data class NavigationRoute(
    val distanceKm: Double,
    val durationMinutes: Int,
    val destination: String,
    val points: List<Pair<Double, Double>> = emptyList()
)

interface NavigationProvider {
    suspend fun calculateRoute(
        origin: String,
        destination: String
    ): Result<NavigationRoute>
}
