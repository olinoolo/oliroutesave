package com.oli.routesave.android.runtime

class DriveRuntimeCoordinator(
    private val foregroundController: ForegroundController,
    private val locationController: LocationController,
    private val audioFocusController: AudioFocusController,
    private val notificationController: DriveNotificationController
) {
    private var snapshot = DriveRuntimeSnapshot()

    fun handle(event: DriveRuntimeEvent): DriveRuntimeSnapshot {
        snapshot = when (event) {
            DriveRuntimeEvent.Start -> {
                foregroundController.start()
                notificationController.show()
                locationController.start()
                audioFocusController.request()
                snapshot.copy(
                    state = DriveRuntimeState.RUNNING,
                    foregroundActive = true,
                    locationActive = true,
                    audioFocusActive = true,
                    notificationActive = true
                )
            }
            DriveRuntimeEvent.Pause -> {
                locationController.pause()
                snapshot.copy(
                    state = DriveRuntimeState.PAUSED,
                    locationActive = false
                )
            }
            DriveRuntimeEvent.Resume -> {
                locationController.start()
                snapshot.copy(
                    state = DriveRuntimeState.RUNNING,
                    locationActive = true
                )
            }
            DriveRuntimeEvent.Stop -> {
                locationController.stop()
                audioFocusController.abandon()
                notificationController.hide()
                foregroundController.stop()
                DriveRuntimeSnapshot()
            }
            is DriveRuntimeEvent.Error -> {
                locationController.stop()
                audioFocusController.abandon()
                snapshot.copy(state = DriveRuntimeState.ERROR)
            }
        }
        return snapshot
    }

    fun snapshot(): DriveRuntimeSnapshot = snapshot
}

interface ForegroundController {
    fun start()
    fun stop()
}

interface LocationController {
    fun start()
    fun pause()
    fun stop()
}

interface AudioFocusController {
    fun request()
    fun abandon()
}

interface DriveNotificationController {
    fun show()
    fun hide()
}
