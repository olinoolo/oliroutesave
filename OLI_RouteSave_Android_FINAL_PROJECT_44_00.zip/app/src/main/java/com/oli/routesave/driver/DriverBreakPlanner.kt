package com.oli.routesave.driver

enum class BreakReminderKind {
    APPROACHING_BREAK, BREAK_DUE, BREAK_ENDS_SOON
}

data class DriverBreakPreferences(
    val enabled: Boolean = true,
    val reminderLeadMinutes: Int = 30,
    val breakDurationMinutes: Int = 45,
    val repeatIntervalMinutes: Int = 15
) {
    fun validate(): List<String> = buildList {
        if (reminderLeadMinutes !in 1..120) add("Predstih pripomienky musí byť 1 až 120 minút.")
        if (breakDurationMinutes !in 5..180) add("Dĺžka prestávky musí byť 5 až 180 minút.")
        if (repeatIntervalMinutes !in 5..60) add("Interval opakovania musí byť 5 až 60 minút.")
    }
}

data class DriverWorkSession(
    val sessionStartedAtMillis: Long,
    val nextBreakDueAtMillis: Long,
    val breakStartedAtMillis: Long? = null,
    val breakCompletedAtMillis: Long? = null,
    val isDriving: Boolean = true
)

data class BreakReminder(
    val kind: BreakReminderKind,
    val title: String,
    val spokenMessage: String,
    val dueAtMillis: Long
)

sealed interface BreakPlannerResult {
    data class Reminder(val reminder: BreakReminder) : BreakPlannerResult
    data object NoReminder : BreakPlannerResult
    data class Invalid(val reason: String) : BreakPlannerResult
}

/**
 * User-configurable reminder logic only. It does not read a tachograph and
 * does not certify legal driving/rest compliance.
 */
class DriverBreakPlanner(
    private val preferences: DriverBreakPreferences = DriverBreakPreferences()
) {
    fun nextReminder(session: DriverWorkSession, nowMillis: Long): BreakPlannerResult {
        val errors = preferences.validate()
        if (errors.isNotEmpty()) return BreakPlannerResult.Invalid(errors.joinToString(" "))
        if (!preferences.enabled || !session.isDriving || session.breakStartedAtMillis != null) {
            return BreakPlannerResult.NoReminder
        }
        if (session.nextBreakDueAtMillis <= session.sessionStartedAtMillis) {
            return BreakPlannerResult.Invalid("Čas nasledujúcej prestávky musí byť po začiatku zmeny.")
        }

        val reminderAt = session.nextBreakDueAtMillis - preferences.reminderLeadMinutes * 60_000L
        return when {
            nowMillis < reminderAt -> BreakPlannerResult.NoReminder
            nowMillis < session.nextBreakDueAtMillis -> BreakPlannerResult.Reminder(
                BreakReminder(
                    kind = BreakReminderKind.APPROACHING_BREAK,
                    title = "Prestávka sa blíži",
                    spokenMessage = "Prestávka ťa čaká približne o ${((session.nextBreakDueAtMillis - nowMillis) / 60_000L).coerceAtLeast(1)} minút. Keď to bude bezpečné, naplánuj si odpočívadlo.",
                    dueAtMillis = session.nextBreakDueAtMillis
                )
            )
            else -> BreakPlannerResult.Reminder(
                BreakReminder(
                    kind = BreakReminderKind.BREAK_DUE,
                    title = "Čas na prestávku",
                    spokenMessage = "Podľa tvojho nastavenia je čas na prestávku. Zastav iba na bezpečnom mieste.",
                    dueAtMillis = session.nextBreakDueAtMillis
                )
            )
        }
    }

    fun plannedBreakEnd(startedAtMillis: Long): Long =
        startedAtMillis + preferences.breakDurationMinutes * 60_000L
}
