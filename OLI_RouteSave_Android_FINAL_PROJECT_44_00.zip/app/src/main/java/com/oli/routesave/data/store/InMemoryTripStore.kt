package com.oli.routesave.data.store

import com.oli.routesave.data.model.TripRecord

class InMemoryTripStore : TripStore {
    private val items = linkedMapOf<String, TripRecord>()

    override fun save(trip: TripRecord) {
        items[trip.id] = trip
    }

    override fun get(id: String): TripRecord? = items[id]

    override fun getRecent(limit: Int): List<TripRecord> =
        items.values.sortedByDescending { it.createdAtEpochMs }.take(limit)

    override fun delete(id: String) {
        items.remove(id)
    }
}
