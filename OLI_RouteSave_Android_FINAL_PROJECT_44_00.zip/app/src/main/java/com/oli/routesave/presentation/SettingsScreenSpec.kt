package com.oli.routesave.presentation

data class SettingsScreenSpec(
    val language: String,
    val metricUnits: Boolean,
    val truckMode: Boolean,
    val communityEnabled: Boolean,
    val voiceEnabled: Boolean
)
