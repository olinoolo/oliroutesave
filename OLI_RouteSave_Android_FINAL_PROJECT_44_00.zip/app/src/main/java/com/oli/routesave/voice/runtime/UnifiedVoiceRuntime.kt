package com.oli.routesave.voice.runtime

class UnifiedVoiceRuntime(
    private val machine: UnifiedVoiceStateMachine =
        UnifiedVoiceStateMachine(),
    private val safety: UnifiedVoiceSafetyPolicy =
        UnifiedVoiceSafetyPolicy(),
    private val actionGate: UnifiedVoiceActionGate =
        UnifiedVoiceActionGate(),
    private val formatter: UnifiedVoiceResponseFormatter =
        UnifiedVoiceResponseFormatter()
) {

    fun state(): UnifiedVoiceState = machine.current()

    fun invoke(context: UnifiedVoiceContext): String {
        machine.apply(
            UnifiedVoiceEvent(UnifiedVoiceEventType.ASSISTANT_INVOCATION)
        )
        return formatter.greeting(context)
    }

    fun processSpeech(text: String): UnifiedVoiceTransition =
        machine.apply(
            UnifiedVoiceEvent(
                UnifiedVoiceEventType.USER_SPEECH,
                text = text
            )
        )

    fun requestConfirmation(
        context: UnifiedVoiceContext,
        action: UnifiedVoiceAction
    ): String {
        machine.apply(
            UnifiedVoiceEvent(
                UnifiedVoiceEventType.CONFIRMATION_REQUIRED,
                requiresConfirmation = true
            )
        )
        return formatter.confirmationQuestion(
            context,
            action.description
        )
    }

    fun execute(
        context: UnifiedVoiceContext,
        action: UnifiedVoiceAction
    ): Result<String> {
        if (!actionGate.canExecute(action)) {
            return Result.failure(
                IllegalStateException(
                    "Explicit assistant confirmation required"
                )
            )
        }

        if (!safety.canContinueConversation(context)) {
            return Result.failure(
                IllegalStateException(
                    "Voice action interrupted by safety state"
                )
            )
        }

        machine.apply(
            UnifiedVoiceEvent(
                UnifiedVoiceEventType.CONFIRMATION_RECEIVED
            )
        )

        return Result.success(action.description)
    }

    fun interrupt(reason: UnifiedVoiceEventType): UnifiedVoiceTransition =
        machine.apply(UnifiedVoiceEvent(reason))

    fun finishSpeech(): UnifiedVoiceTransition =
        machine.apply(
            UnifiedVoiceEvent(UnifiedVoiceEventType.TTS_FINISHED)
        )
}
