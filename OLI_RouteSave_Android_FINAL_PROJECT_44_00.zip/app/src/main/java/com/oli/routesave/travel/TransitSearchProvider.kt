package com.oli.routesave.travel

interface TransitSearchProvider {
    suspend fun search(request: TransitSearchRequest): TransitSearchResult
}

/**
 * Safe placeholder: reports unavailable rather than inventing departures or fares.
 * Replace with a licensed/official provider adapter when API access is configured.
 */
class UnconfiguredTransitSearchProvider : TransitSearchProvider {
    override suspend fun search(request: TransitSearchRequest): TransitSearchResult {
        val errors = request.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        return TransitSearchResult(
            request = request,
            connections = emptyList(),
            freshness = TransitDataFreshness.UNAVAILABLE,
            providerMessage = "Živé vyhľadávanie nie je nakonfigurované. Nezobrazujeme vymyslené spoje ani ceny."
        )
    }
}

class TransitSearchService(
    private val provider: TransitSearchProvider
) {
    suspend fun search(request: TransitSearchRequest): TransitSearchResult {
        val errors = request.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        val result = provider.search(request)
        require(result.connections.all { it.validate().isEmpty() }) {
            "Poskytovateľ vrátil neplatné údaje o spoji."
        }
        return result.copy(
            connections = result.connections.sortedWith(
                compareBy<TransitConnection> { it.price ?: Double.POSITIVE_INFINITY }
                    .thenBy { it.departureEpochMs ?: Long.MAX_VALUE }
            )
        )
    }
}
