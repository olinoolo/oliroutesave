package com.oli.routesave.travel

data class TravelOption(
    val mode: TravelMode,
    val estimatedDurationMinutes: Int? = null,
    val estimatedCost: Double? = null,
    val currencyCode: String = "EUR",
    val notes: List<String> = emptyList(),
    val sourceLabel: String? = null,
    val isLiveQuote: Boolean = false
) {
    fun validate(): List<String> = buildList {
        if (estimatedDurationMinutes != null && estimatedDurationMinutes < 0) {
            add("Čas cesty nemôže byť záporný.")
        }
        if (estimatedCost != null &&
            (!estimatedCost.isFinite() || estimatedCost < 0.0)
        ) add("Cena cesty musí byť nezáporná.")
        if (currencyCode.isBlank()) add("Mena musí byť uvedená.")
        if (isLiveQuote && sourceLabel.isNullOrBlank()) {
            add("Živá cenová ponuka musí uvádzať zdroj.")
        }
    }
}

data class TravelComparison(
    val origin: String,
    val destination: String,
    val options: List<TravelOption>
) {
    fun cheapestKnownOption(): TravelOption? =
        options.filter { it.validate().isEmpty() && it.estimatedCost != null }
            .minByOrNull { it.estimatedCost!! }

    fun fastestKnownOption(): TravelOption? =
        options.filter { it.validate().isEmpty() && it.estimatedDurationMinutes != null }
            .minByOrNull { it.estimatedDurationMinutes!! }
}

interface TravelQuoteProvider {
    suspend fun search(origin: String, destination: String, mode: TravelMode): List<TravelOption>
}

sealed interface TravelSearchResult {
    data class Success(val comparison: TravelComparison) : TravelSearchResult
    data class Invalid(val reason: String) : TravelSearchResult
    data class Failed(val reason: String) : TravelSearchResult
}

/**
 * Orchestrates providers, but does not pretend to provide live fares when no
 * provider is connected. Implementations should label estimates vs live quotes.
 */
class TravelComparisonService(
    private val providers: Map<TravelMode, TravelQuoteProvider>
) {
    suspend fun compare(origin: String, destination: String): TravelSearchResult {
        val from = origin.trim()
        val to = destination.trim()
        if (from.isEmpty() || to.isEmpty()) {
            return TravelSearchResult.Invalid("Zadaj miesto odchodu aj cieľ.")
        }
        if (from.equals(to, ignoreCase = true)) {
            return TravelSearchResult.Invalid("Odchod a cieľ nemôžu byť rovnaké.")
        }

        val options = mutableListOf<TravelOption>()
        var providerErrors = 0
        TravelMode.entries.forEach { mode ->
            val provider = providers[mode]
            if (provider == null) {
                options.add(
                    TravelOption(
                        mode = mode,
                        notes = listOf("Poskytovateľ vyhľadávania ešte nie je pripojený.")
                    )
                )
            } else {
                try {
                    val results = provider.search(from, to, mode)
                    options.addAll(results.filter { it.validate().isEmpty() })
                } catch (_: Exception) {
                    providerErrors++
                    options.add(
                        TravelOption(
                            mode = mode,
                            notes = listOf("Vyhľadávanie pre tento spôsob dopravy sa nepodarilo.")
                        )
                    )
                }
            }
        }
        if (options.isEmpty() || providerErrors == providers.size && providers.isNotEmpty()) {
            return TravelSearchResult.Failed("Nepodarilo sa získať možnosti cestovania.")
        }
        return TravelSearchResult.Success(TravelComparison(from, to, options))
    }
}
