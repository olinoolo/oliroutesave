package com.oli.routesave.voice.assistant

data class AssistantProfile(
    val id: String,
    val officialName: String,
    val invocationName: String,
    val personalAddress: String? = null,
    val languageTag: String = "sk-SK",
    val conciseResponses: Boolean = true
) {
    fun displayName(): String = personalAddress?.takeIf { it.isNotBlank() } ?: officialName
}

object DefaultAssistantProfiles {
    val nikolas = AssistantProfile(
        id = "nikolas",
        officialName = "Nikolas",
        invocationName = "Niko",
        personalAddress = null,
        languageTag = "sk-SK"
    )
    val branislav = AssistantProfile(
        id = "branislav",
        officialName = "Branislav",
        invocationName = "Brandži",
        languageTag = "sk-SK"
    )
    val natalia = AssistantProfile(
        id = "natalia",
        officialName = "Natália",
        invocationName = "Naty",
        languageTag = "sk-SK"
    )
    val vanesa = AssistantProfile(
        id = "vanesa",
        officialName = "Vanesa",
        invocationName = "Vany",
        languageTag = "sk-SK"
    )
}
