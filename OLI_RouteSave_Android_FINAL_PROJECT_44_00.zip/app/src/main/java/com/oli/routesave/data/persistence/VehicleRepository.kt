package com.oli.routesave.data.persistence
import com.oli.routesave.data.model.VehicleProfile
import com.oli.routesave.data.store.VehicleStore
class VehicleRepository(private val store:VehicleStore){
    fun save(v:VehicleProfile)=store.save(v)
    fun find(id:String)=store.get(id)
    fun all()=store.getAll()
    fun defaultVehicle()=store.getDefault()
    fun delete(id:String)=store.delete(id)
}
