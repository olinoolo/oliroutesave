package com.oli.routesave.runtime

data class ProviderHealth(
    val locationAvailable: Boolean = false,
    val navigationAvailable: Boolean = false,
    val voiceAvailable: Boolean = false,
    val mapAvailable: Boolean = false
) {
    val readyForDrive: Boolean
        get() = locationAvailable && navigationAvailable
}
