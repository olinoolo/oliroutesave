package com.oli.routesave.core

sealed interface RouteSaveEvent {
    data object AppStarted : RouteSaveEvent
    data object StartDrive : RouteSaveEvent
    data object StopDrive : RouteSaveEvent
    data object PauseDrive : RouteSaveEvent
    data object ResumeDrive : RouteSaveEvent
    data class OpenScreen(val screenName: String) : RouteSaveEvent
    data object Emergency : RouteSaveEvent
}
