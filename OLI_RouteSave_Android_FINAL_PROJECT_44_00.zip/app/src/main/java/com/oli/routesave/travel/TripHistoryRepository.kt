package com.oli.routesave.travel

interface TripHistoryRepository {
    fun save(record: TripHistoryRecord)
    fun find(id: String): TripHistoryRecord?
    fun all(): List<TripHistoryRecord>
    fun delete(id: String): Boolean
    fun clear()
}

class InMemoryTripHistoryRepository : TripHistoryRepository {
    private val records = linkedMapOf<String, TripHistoryRecord>()

    override fun save(record: TripHistoryRecord) {
        val errors = record.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        records[record.id] = record
    }

    override fun find(id: String): TripHistoryRecord? = records[id]

    override fun all(): List<TripHistoryRecord> =
        records.values.sortedByDescending { it.createdAtEpochMs }

    override fun delete(id: String): Boolean = records.remove(id) != null

    override fun clear() = records.clear()
}
