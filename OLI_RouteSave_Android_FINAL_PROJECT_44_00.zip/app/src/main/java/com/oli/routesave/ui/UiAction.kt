package com.oli.routesave.ui

sealed interface UiAction {
    data class OpenScreen(val screen: AppScreen): UiAction
    data object Back: UiAction
    data object StartDrive: UiAction
    data object StopDrive: UiAction
}
