package com.oli.routesave.voice.runtime

data class VoiceRuntimeSnapshot(
    val state: UnifiedVoiceState,
    val assistantName: String,
    val invocationName: String,
    val pendingConfirmation: Boolean
)
