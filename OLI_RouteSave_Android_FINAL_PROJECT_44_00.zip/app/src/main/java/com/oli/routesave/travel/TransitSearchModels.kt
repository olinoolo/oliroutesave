package com.oli.routesave.travel

enum class TransitMode { TRAIN, BUS }

enum class TransitDataFreshness { LIVE, CACHED, SAMPLE, UNAVAILABLE }

data class TransitSearchRequest(
    val origin: String,
    val destination: String,
    val departureEpochMs: Long? = null,
    val mode: TransitMode? = null,
    val passengers: Int = 1
) {
    fun validate(): List<String> = buildList {
        if (origin.isBlank()) add("Zadaj miesto odchodu.")
        if (destination.isBlank()) add("Zadaj cieľ.")
        if (origin.trim().equals(destination.trim(), ignoreCase = true)) add("Odchod a cieľ musia byť rozdielne.")
        if (passengers !in 1..20) add("Počet cestujúcich musí byť od 1 do 20.")
        if (departureEpochMs != null && departureEpochMs < 0) add("Neplatný čas odchodu.")
    }
}

data class TransitConnection(
    val id: String,
    val mode: TransitMode,
    val provider: String,
    val origin: String,
    val destination: String,
    val departureEpochMs: Long?,
    val arrivalEpochMs: Long?,
    val price: Double?,
    val currencyCode: String = "EUR",
    val changes: Int? = null,
    val bookingUrl: String? = null,
    val freshness: TransitDataFreshness = TransitDataFreshness.UNAVAILABLE,
    val notes: String = ""
) {
    fun validate(): List<String> = buildList {
        if (id.isBlank()) add("Spoj nemá ID.")
        if (provider.isBlank()) add("Chýba poskytovateľ údajov.")
        if (origin.isBlank() || destination.isBlank()) add("Spoj nemá úplný smer.")
        if (price != null && (!price.isFinite() || price < 0.0)) add("Neplatná cena.")
        if (currencyCode !in setOf("EUR", "CZK", "USD", "GBP", "PLN", "HUF", "RON")) add("Nepodporovaná mena.")
        if (changes != null && changes < 0) add("Počet prestupov nemôže byť záporný.")
        if (bookingUrl != null && !bookingUrl.startsWith("https://")) add("Odkaz na nákup musí používať HTTPS.")
        if (departureEpochMs != null && arrivalEpochMs != null && arrivalEpochMs < departureEpochMs) add("Príchod nemôže byť pred odchodom.")
    }
}

data class TransitSearchResult(
    val request: TransitSearchRequest,
    val connections: List<TransitConnection>,
    val freshness: TransitDataFreshness,
    val providerMessage: String
)
