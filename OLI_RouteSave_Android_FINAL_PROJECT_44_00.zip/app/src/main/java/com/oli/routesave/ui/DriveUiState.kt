package com.oli.routesave.ui

data class DriveUiState(
    val isDriving: Boolean = false,
    val assistantInvocation: String = "Niko",
    val assistantAddress: String = "",
    val vehicleName: String = "",
    val destination: String = "",
    val etaText: String = "",
    val remainingKm: Double? = null,
    val voiceListening: Boolean = false,
    val mapReady: Boolean = false
)
