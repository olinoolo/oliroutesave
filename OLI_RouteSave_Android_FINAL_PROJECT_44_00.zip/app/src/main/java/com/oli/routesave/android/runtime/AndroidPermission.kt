package com.oli.routesave.android.runtime
enum class AndroidPermission { LOCATION_FINE, LOCATION_COARSE, LOCATION_BACKGROUND, MICROPHONE, NOTIFICATION, PHONE, CONTACTS }
