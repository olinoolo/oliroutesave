package com.oli.routesave.ui

data class HomeUiState(
    val assistantName: String = "Niko",
    val vehicleName: String = "",
    val destination: String = "",
    val remainingDistanceKm: Double? = null,
    val etaText: String? = null,
    val driveActive: Boolean = false,
    val communityAlerts: Int = 0
)
