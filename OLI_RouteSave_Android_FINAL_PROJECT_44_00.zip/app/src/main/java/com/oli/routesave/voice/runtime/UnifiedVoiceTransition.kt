package com.oli.routesave.voice.runtime

data class UnifiedVoiceTransition(
    val state: UnifiedVoiceState,
    val reason: String
)
