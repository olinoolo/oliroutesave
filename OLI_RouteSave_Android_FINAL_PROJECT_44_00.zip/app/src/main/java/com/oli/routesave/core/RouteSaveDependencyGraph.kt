package com.oli.routesave.core

import com.oli.routesave.android.runtime.*
import com.oli.routesave.data.persistence.*
import com.oli.routesave.data.store.*
import com.oli.routesave.runtime.*
import com.oli.routesave.runtime.location.LocationSession
import com.oli.routesave.runtime.navigation.NavigationSession
import com.oli.routesave.ui.*

/**
 * Composition root for the application.
 *
 * Android-specific implementations are injected here.
 * This keeps the core runtime independent from Mapbox, Android AudioManager,
 * Android permission APIs and concrete GPS implementations.
 */
class RouteSaveDependencyGraph(
    private val permissionChecker: PermissionChecker,
    private val locationProvider: com.oli.routesave.runtime.location.LocationProvider,
    private val navigationProvider: NavigationProvider,
    private val foregroundController: ForegroundController,
    private val audioFocusController: AudioFocusController,
    private val notificationController: DriveNotificationController
) {
    fun createRuntime(): RouteSaveRuntime {
        val settingsStore = InMemoryKeyValueStore()
        val settingsRepository = SettingsRepository(settingsStore)
        val vehicleRepository = VehicleRepository(InMemoryVehicleStore())

        val permissionController = PermissionController(permissionChecker)
        val readiness = DriveReadinessChecker(permissionController)

        val runtimeCoordinator = DriveRuntimeCoordinator(
            foregroundController = foregroundController,
            locationController = object : LocationController {
                private val session = LocationSession(locationProvider)
                override fun start() { session.start {} }
                override fun pause() { session.stop() }
                override fun stop() { session.stop() }
            },
            audioFocusController = audioFocusController,
            notificationController = notificationController
        )

        val driveUi = DriveUiController()
        val navigation = NavigationSession(navigationProvider)
        val location = LocationSession(locationProvider)

        val orchestrator = DriveSessionOrchestrator(
            runtime = runtimeCoordinator,
            location = location,
            navigation = navigation,
            ui = driveUi
        )

        return RouteSaveRuntime(
            settingsRepository = settingsRepository,
            vehicleRepository = vehicleRepository,
            permissions = permissionController,
            readiness = readiness,
            navigator = AppNavigator(),
            drive = orchestrator,
            driveUi = driveUi
        )
    }
}
