package com.oli.routesave.communication

/** UI-safe state model for hands-free call preparation and progress. */
sealed interface CallSessionState {
    data object Idle : CallSessionState
    data class ResolvingDestination(val spokenReference: String) : CallSessionState
    data class ClarificationRequired(val question: String) : CallSessionState
    data class Preparing(val request: CallRequest) : CallSessionState
    data class AwaitingVoiceConfirmation(
        val request: CallRequest,
        val spokenPrompt: String,
        val confirmationNonce: String
    ) : CallSessionState
    data class Launching(val request: CallRequest) : CallSessionState
    data class Started(val request: CallRequest) : CallSessionState
    data class Failed(val message: String) : CallSessionState
    data object Cancelled : CallSessionState
}

/**
 * A nonce binds a yes/no response to one exact pending call. UI implementations
 * should invalidate it on timeout, cancellation, new command, or screen/session
 * reset, so an old "yes" cannot approve a different call.
 */
data class PendingCallConfirmation(
    val request: CallRequest,
    val spokenPrompt: String,
    val nonce: String,
    val expiresAtEpochMillis: Long
)
