package com.oli.routesave.ui

data class CommunityUiState(
    val nearbyHelpRequests: Int = 0,
    val nearbyAlerts: Int = 0,
    val trustedHelpers: Int = 0
)
