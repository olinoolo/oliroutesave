package com.oli.routesave.ui

import com.oli.routesave.data.persistence.SettingsRepository
import com.oli.routesave.data.persistence.VehicleRepository

class HomeController(
    private val settings: SettingsRepository,
    private val vehicles: VehicleRepository
) {
    fun load(): HomeUiState {
        val assistant = settings.loadAssistantSettings()
        return HomeUiState(
            assistantName = assistant?.invocationName?.ifBlank { "Niko" } ?: "Niko",
            vehicleName = vehicles.defaultVehicle()?.name.orEmpty()
        )
    }
}
