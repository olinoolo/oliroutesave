package com.oli.routesave.ui

data class UiThemeSpec(
    val appName: String = "OLI RouteSave",
    val slogan: String = "Save money. Travel smarter.",
    val primaryColorHex: String = "#0B3D91",
    val accentColorHex: String = "#F28C28",
    val darkBackgroundHex: String = "#071B33"
)
