# Voice contact alias call flow — milestone 9.70

## New source components
- `ContactAliasCallResolver` checks a saved alias first and then delegates to a regular contact-name resolver.
- `RecipientResolution` distinguishes a successful match, missing contact, ambiguous match, missing permission and empty input.
- `CallConfirmationReadback` builds Slovak confirmation prompts for audio calls, video calls and dictated phone numbers.

## Intended flow
1. The user says a command using the currently selected assistant's invocation, e.g. “Niko, zavolaj môjmu bratovi”.
2. The app resolves “môj brat” only if that phrase has been saved as an alias; otherwise it asks the regular contact resolver.
3. If multiple contacts match, the assistant asks which person the user means.
4. The selected assistant reads back the contact and call type and asks for a clear “áno/nie”.
5. Only the existing confirmed-call coordinator may launch the external action. Resolving a contact is not consent.

## Integration boundary
These classes are orchestration building blocks. They do not themselves access the device contacts, speak audio, request Android permissions or launch calls. Connect them to the app's existing contacts gateway, speech output, and confirmation coordinator.

## Validation
Source-only milestone. It has not been compiled or tested on a physical Android device.
