package com.oli.routesave.messaging

data class MessageNotification(
    val packageName: String,
    val sender: String?,
    val messagePreview: String?,
    val conversationTitle: String?,
    val receivedAtEpochMillis: Long,
    val hasReplyAction: Boolean
) {
    val readableContent: Boolean
        get() = !messagePreview.isNullOrBlank()
}
