package com.oli.routesave.voice.intent

import java.text.Normalizer
import java.util.Locale

enum class VoiceIntentType {
    PLAN_ROUTE,
    FUEL_ESTIMATE,
    REPORT_BREAKDOWN,
    CALL_CONTACT,
    SEND_MESSAGE,
    SHARE_LOCATION,
    UNKNOWN
}

enum class ConfirmationRequirement {
    NONE,
    REQUIRED
}

data class ParsedVoiceIntent(
    val type: VoiceIntentType,
    val originalText: String,
    val argument: String? = null,
    val confirmationRequirement: ConfirmationRequirement = ConfirmationRequirement.NONE,
    val assistantInvocation: String? = null
)

class VoiceIntentParser(
    private val knownInvocations: Set<String> = setOf("niko", "brandzi", "naty", "vany", "marek", "tanya", "katerina")
) {
    fun parse(utterance: String): ParsedVoiceIntent {
        val normalized = normalize(utterance)
        val invocation = knownInvocations.firstOrNull { normalized.startsWith("$it ") || normalized == it }
        val command = if (invocation != null) normalized.removePrefix(invocation).trim() else normalized

        return when {
            command.startsWith("naplanuj trasu") || command.startsWith("najdi trasu") ->
                ParsedVoiceIntent(VoiceIntentType.PLAN_ROUTE, utterance, extractAfterKeyword(command, listOf("do ")), assistantInvocation = invocation)
            command.contains("kolko ma bude stat palivo") || command.contains("vypocitaj palivo") || command.contains("cena paliva") ->
                ParsedVoiceIntent(VoiceIntentType.FUEL_ESTIMATE, utterance, assistantInvocation = invocation)
            command.contains("mam defekt") || command.contains("pokazilo sa auto") || command.contains("potrebujem pomoc") ->
                ParsedVoiceIntent(VoiceIntentType.REPORT_BREAKDOWN, utterance, confirmationRequirement = ConfirmationRequirement.REQUIRED, assistantInvocation = invocation)
            command.startsWith("zavolaj ") || command.startsWith("zavolat ") ->
                ParsedVoiceIntent(VoiceIntentType.CALL_CONTACT, utterance, extractAfterKeyword(command, listOf("zavolaj ", "zavolat ")), ConfirmationRequirement.REQUIRED, invocation)
            command.startsWith("posli spravu ") || command.startsWith("posli sms ") ->
                ParsedVoiceIntent(VoiceIntentType.SEND_MESSAGE, utterance, extractAfterKeyword(command, listOf("posli spravu ", "posli sms ")), ConfirmationRequirement.REQUIRED, invocation)
            command.contains("zdielaj moju polohu") || command.contains("posli moju polohu") ->
                ParsedVoiceIntent(VoiceIntentType.SHARE_LOCATION, utterance, confirmationRequirement = ConfirmationRequirement.REQUIRED, assistantInvocation = invocation)
            else -> ParsedVoiceIntent(VoiceIntentType.UNKNOWN, utterance, assistantInvocation = invocation)
        }
    }

    private fun extractAfterKeyword(command: String, keywords: List<String>): String? {
        val keyword = keywords.firstOrNull { command.contains(it) } ?: return null
        return command.substringAfter(keyword).trim().takeIf { it.isNotBlank() }
    }

    private fun normalize(input: String): String {
        val lowered = input.lowercase(Locale.ROOT).trim()
        return Normalizer.normalize(lowered, Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("[,!?;:.]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }
}
