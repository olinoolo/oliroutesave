package com.oli.routesave.community

enum class HelperUserType {
    DRIVER, CYCLIST, PEDESTRIAN, OTHER
}

enum class HelpCategory {
    VEHICLE_BREAKDOWN,
    FLAT_TIRE,
    OUT_OF_FUEL,
    MEDICAL_ASSISTANCE,
    SAFETY_CONCERN,
    DIRECTIONS,
    OTHER
}

enum class HelpUrgency {
    NORMAL, URGENT
}

data class CommunityHelpRequest(
    val requestId: String,
    val requesterId: String,
    val requesterType: HelperUserType,
    val category: HelpCategory,
    val description: String,
    val latitude: Double?,
    val longitude: Double?,
    val radiusKm: Double,
    val urgency: HelpUrgency,
    val createdAtEpochMillis: Long,
    val expiresAtEpochMillis: Long,
    val status: HelpRequestStatus = HelpRequestStatus.DRAFT
)

enum class HelpRequestStatus {
    DRAFT,
    AWAITING_CONFIRMATION,
    PUBLISHED,
    CANCELLED,
    EXPIRED,
    RESOLVED
}

sealed interface CommunityHelpValidation {
    data object Valid : CommunityHelpValidation
    data class Invalid(val reasons: List<String>) : CommunityHelpValidation
}

object CommunityHelpRequestValidator {
    fun validate(request: CommunityHelpRequest): CommunityHelpValidation {
        val errors = mutableListOf<String>()
        if (request.requestId.isBlank()) errors.add("Chýba identifikátor žiadosti.")
        if (request.requesterId.isBlank()) errors.add("Chýba identifikátor žiadateľa.")
        if (request.description.length > 500) errors.add("Opis môže mať najviac 500 znakov.")
        if (!request.radiusKm.isFinite() || request.radiusKm !in 0.5..100.0) {
            errors.add("Okruh pomoci musí byť od 0,5 do 100 km.")
        }
        val hasLat = request.latitude != null
        val hasLon = request.longitude != null
        if (hasLat != hasLon) errors.add("Poloha musí obsahovať obe súradnice.")
        if (hasLat && (request.latitude!!.isNaN() || request.latitude !in -90.0..90.0)) {
            errors.add("Zemepisná šírka nie je platná.")
        }
        if (hasLon && (request.longitude!!.isNaN() || request.longitude !in -180.0..180.0)) {
            errors.add("Zemepisná dĺžka nie je platná.")
        }
        if (request.expiresAtEpochMillis <= request.createdAtEpochMillis) {
            errors.add("Čas vypršania musí byť neskôr ako vytvorenie žiadosti.")
        }
        if (request.description.isBlank() && request.category == HelpCategory.OTHER) {
            errors.add("Pri kategórii Iné doplň krátky opis.")
        }
        return if (errors.isEmpty()) CommunityHelpValidation.Valid
        else CommunityHelpValidation.Invalid(errors)
    }
}
