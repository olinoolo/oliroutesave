package com.oli.routesave.runtime

import com.oli.routesave.ui.DriveUiController
import com.oli.routesave.ui.VoiceUiController

class VoiceNavigationBridge(
    private val driveUi: DriveUiController,
    private val voiceUi: VoiceUiController
) {
    fun beginVoiceCommand() {
        if (!driveUi.state().isDriving) return
        voiceUi.pressAssistantButton()
    }

    fun finishVoiceCommand() {
        voiceUi.finishListening()
    }

    fun emergencyInterrupt() {
        voiceUi.interrupt()
        driveUi.stopDriving()
    }
}
