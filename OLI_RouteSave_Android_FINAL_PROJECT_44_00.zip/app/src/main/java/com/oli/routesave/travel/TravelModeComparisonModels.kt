package com.oli.routesave.travel

enum class TravelQuoteStatus { ESTIMATE, LIVE_QUOTE, UNAVAILABLE }

data class TravelOptionQuote(
    val mode: TravelMode,
    val providerName: String,
    val distanceKm: Double?,
    val durationMinutes: Int?,
    val ticketOrEnergyCost: Double?,
    val extraCosts: Double = 0.0,
    val currencyCode: String = "EUR",
    val status: TravelQuoteStatus = TravelQuoteStatus.ESTIMATE,
    val notes: String = ""
) {
    val totalCost: Double?
        get() = if (ticketOrEnergyCost == null) null else ticketOrEnergyCost + extraCosts

    fun validate(): List<String> = buildList {
        if (providerName.isBlank()) add("Názov možnosti je povinný.")
        if (distanceKm != null && (!distanceKm.isFinite() || distanceKm < 0.0)) add("Neplatná vzdialenosť.")
        if (durationMinutes != null && durationMinutes < 0) add("Neplatný čas cesty.")
        if (ticketOrEnergyCost != null && (!ticketOrEnergyCost.isFinite() || ticketOrEnergyCost < 0.0)) add("Neplatná cena.")
        if (!extraCosts.isFinite() || extraCosts < 0.0) add("Neplatné dodatočné náklady.")
        if (currencyCode !in setOf("EUR", "CZK", "USD", "GBP", "PLN", "HUF", "RON")) add("Nepodporovaná mena.")
    }
}

data class TravelComparisonInput(
    val distanceKm: Double,
    val fuelConsumptionL100Km: Double,
    val fuelPricePerLitre: Double,
    val carTollCost: Double = 0.0,
    val carParkingCost: Double = 0.0,
    val trainTicketCost: Double? = null,
    val busTicketCost: Double? = null,
    val planeTicketCost: Double? = null,
    val trainExtraCosts: Double = 0.0,
    val busExtraCosts: Double = 0.0,
    val planeExtraCosts: Double = 0.0,
    val trainDurationMinutes: Int? = null,
    val busDurationMinutes: Int? = null,
    val planeDurationMinutes: Int? = null,
    val currencyCode: String = "EUR"
)

data class TravelComparisonResult(
    val options: List<TravelOptionQuote>,
    val cheapestAvailable: TravelOptionQuote?,
    val fastestAvailable: TravelOptionQuote?,
    val allPricesAreEstimates: Boolean
)
