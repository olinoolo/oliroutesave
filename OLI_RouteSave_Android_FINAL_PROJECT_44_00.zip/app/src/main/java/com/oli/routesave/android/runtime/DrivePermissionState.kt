package com.oli.routesave.android.runtime

data class DrivePermissionState(
    val fineLocation: Boolean = false,
    val coarseLocation: Boolean = false,
    val microphone: Boolean = false,
    val notification: Boolean = false,
    val phone: Boolean = false,
    val contacts: Boolean = false
) {
    val canStartNavigation: Boolean
        get() = fineLocation || coarseLocation

    val canStartVoice: Boolean
        get() = microphone

    val canUseCalling: Boolean
        get() = phone && contacts
}
