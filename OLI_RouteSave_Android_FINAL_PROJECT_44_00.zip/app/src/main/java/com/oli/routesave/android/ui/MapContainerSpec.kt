package com.oli.routesave.android.ui

data class MapContainerSpec(
    val visible: Boolean = true,
    val showUserLocation: Boolean = true,
    val showRoute: Boolean = true,
    val followUser: Boolean = true,
    val zoom: Double = 14.0
)
