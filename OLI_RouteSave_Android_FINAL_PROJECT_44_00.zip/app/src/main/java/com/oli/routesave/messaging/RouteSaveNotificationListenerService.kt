package com.oli.routesave.messaging

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Android notification listener template.
 *
 * IMPORTANT: users must explicitly enable notification access in Android settings.
 * Connect the repository to an application-scoped event bus before relying on it.
 */
class RouteSaveNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val notification = sbn.notification ?: return
        val hasReply = NotificationMessageExtractor.hasReplyAction(notification)
        val event = NotificationMessageExtractor.extract(
            packageName = sbn.packageName,
            extras = notification.extras,
            receivedAtEpochMillis = sbn.postTime,
            hasReplyAction = hasReply
        ) ?: return

        // Intentionally do not log message contents.
        MessageNotificationRepositoryHolder.repository.onMessageNotification(event)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        MessageNotificationRepositoryHolder.repository.onNotificationRemoved(
            sbn.packageName,
            sbn.key
        )
    }
}

/**
 * Replace this holder with a proper DI/application-scoped provider when integrating.
 */
object MessageNotificationRepositoryHolder {
    @Volatile
    var repository: MessageNotificationRepository = NoOpMessageNotificationRepository
}
