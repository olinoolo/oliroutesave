package com.oli.routesave.voice.runtime

data class UnifiedVoiceContext(
    val assistantName: String,
    val invocationName: String,
    val personalAddress: String?,
    val driving: Boolean,
    val navigationCritical: Boolean,
    val emergencyActive: Boolean,
    val activeCall: Boolean,
    val pendingConfirmation: Boolean
)
