package com.oli.routesave.android.runtime

class DriveRuntimeSafetyGate {
    fun canStart(
        permissions: DrivePermissionState,
        emergencyActive: Boolean,
        activeCall: Boolean
    ): Boolean {
        if (emergencyActive || activeCall) return false
        return permissions.canStartNavigation
    }

    fun canEnableVoice(permissions: DrivePermissionState): Boolean =
        permissions.canStartVoice
}
