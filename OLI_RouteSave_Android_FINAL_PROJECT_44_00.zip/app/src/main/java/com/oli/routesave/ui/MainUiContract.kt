package com.oli.routesave.ui

object MainUiContract {
    const val APP_TITLE = "OLI RouteSave"
    const val START_DRIVE = "Spustiť jazdu"
    const val STOP_DRIVE = "Ukončiť jazdu"
    const val VOICE = "Hlasový asistent"
    const val ROUTE = "Trasa"
    const val VEHICLE = "Vozidlo"
    const val COMMUNITY = "Komunita"
}
