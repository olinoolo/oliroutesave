package com.oli.routesave.messaging

/**
 * In-memory event boundary. Avoid persisting private message bodies by default.
 * The Android service can forward events to an app-scoped implementation.
 */
interface MessageNotificationRepository {
    fun onMessageNotification(notification: MessageNotification)
    fun onNotificationRemoved(packageName: String, notificationKey: String)
}

object NoOpMessageNotificationRepository : MessageNotificationRepository {
    override fun onMessageNotification(notification: MessageNotification) = Unit
    override fun onNotificationRemoved(packageName: String, notificationKey: String) = Unit
}
