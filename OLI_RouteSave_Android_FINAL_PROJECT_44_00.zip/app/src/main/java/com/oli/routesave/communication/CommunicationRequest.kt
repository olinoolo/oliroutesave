package com.oli.routesave.communication

enum class CommunicationChannel {
    PHONE, WHATSAPP, MESSENGER, SMS
}

enum class CommunicationMode {
    AUDIO_CALL, VIDEO_CALL, TEXT_MESSAGE
}

data class CommunicationRequest(
    val recipientDisplayName: String,
    val channel: CommunicationChannel,
    val mode: CommunicationMode,
    val messageText: String? = null,
    val destinationNumber: String? = null
) {
    fun validate(): CommunicationValidation {
        if (recipientDisplayName.isBlank() && destinationNumber.isNullOrBlank()) {
            return CommunicationValidation.Invalid("Najprv vyber príjemcu alebo nadiktuj telefónne číslo.")
        }
        if (mode == CommunicationMode.TEXT_MESSAGE && messageText.isNullOrBlank()) {
            return CommunicationValidation.Invalid("Správa je prázdna.")
        }
        if (mode != CommunicationMode.TEXT_MESSAGE && channel == CommunicationChannel.SMS) {
            return CommunicationValidation.Invalid("SMS kanál nepodporuje hlasový ani videohovor.")
        }
        if (mode == CommunicationMode.VIDEO_CALL &&
            channel != CommunicationChannel.WHATSAPP &&
            channel != CommunicationChannel.MESSENGER
        ) {
            return CommunicationValidation.Invalid("Videohovor je dostupný iba cez podporovaný videohovorový kanál.")
        }
        return CommunicationValidation.Valid
    }
}

sealed interface CommunicationValidation {
    data object Valid : CommunicationValidation
    data class Invalid(val reason: String) : CommunicationValidation
}
