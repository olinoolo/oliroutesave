package com.oli.routesave.ui

class DriveUiController(initial: DriveUiState = DriveUiState()) {
    private var state = initial

    fun state(): DriveUiState = state

    fun mapReady() {
        state = state.copy(mapReady = true)
    }

    fun setAssistant(invocation: String, address: String) {
        state = state.copy(
            assistantInvocation = invocation,
            assistantAddress = address
        )
    }

    fun setVehicle(name: String) {
        state = state.copy(vehicleName = name)
    }

    fun setDestination(destination: String) {
        state = state.copy(destination = destination)
    }

    fun setRoute(etaText: String, remainingKm: Double?) {
        state = state.copy(
            etaText = etaText,
            remainingKm = remainingKm
        )
    }

    fun startDriving() {
        state = state.copy(isDriving = true)
    }

    fun stopDriving() {
        state = state.copy(isDriving = false, voiceListening = false)
    }

    fun setVoiceListening(active: Boolean) {
        state = state.copy(voiceListening = active)
    }
}
