package com.oli.routesave.android.ui

import com.oli.routesave.core.RouteSaveEvent
import com.oli.routesave.core.RouteSaveEventHandler
import com.oli.routesave.presentation.MainUiPresenter
import com.oli.routesave.presentation.MainUiAction

class RouteSaveActivityBridge(
    private val events: RouteSaveEventHandler,
    private val presenter: MainUiPresenter,
    private val host: RouteSaveUiHost
) {
    fun start() {
        val state = events.handle(RouteSaveEvent.AppStarted)
        host.render(presenter.present(state))
    }

    fun action(action: MainUiAction) {
        val state = when (action) {
            MainUiAction.StartDrive -> events.handle(RouteSaveEvent.StartDrive)
            MainUiAction.StopDrive -> events.handle(RouteSaveEvent.StopDrive)
            MainUiAction.Voice -> events.handle(RouteSaveEvent.OpenScreen("ASSISTANT"))
            MainUiAction.OpenRoute -> events.handle(RouteSaveEvent.OpenScreen("ROUTE"))
            MainUiAction.OpenVehicle -> events.handle(RouteSaveEvent.OpenScreen("VEHICLE"))
            MainUiAction.OpenAssistant -> events.handle(RouteSaveEvent.OpenScreen("ASSISTANT"))
            MainUiAction.OpenCommunity -> events.handle(RouteSaveEvent.OpenScreen("COMMUNITY"))
            MainUiAction.OpenSettings -> events.handle(RouteSaveEvent.OpenScreen("SETTINGS"))
        }
        host.render(presenter.present(state))
        state.lastError?.let(host::showMessage)
    }
}
