package com.oli.routesave.presentation

import com.oli.routesave.data.model.VehicleProfile

/**
 * Pure Kotlin form state for the vehicle profile screen.
 * Text input remains a String until validation succeeds, avoiding crashes
 * while the user is editing incomplete numeric fields.
 */
data class VehicleProfileFormState(
    val id: String = "",
    val name: String = "",
    val brand: String = "",
    val model: String = "",
    val fuelType: String = "PETROL",
    val consumptionL100Km: String = "",
    val fuelPricePerLiter: String = "",
    val isDefault: Boolean = false
) {
    fun toVehicleProfile(): VehicleFormResult {
        val errors = mutableListOf<String>()
        val parsedConsumption = consumptionL100Km.trim().replace(',', '.').toDoubleOrNull()
        val parsedPrice = fuelPricePerLiter.trim().replace(',', '.').toDoubleOrNull()

        if (id.isBlank()) errors += "Chýba interné ID vozidla."
        if (name.isBlank()) errors += "Zadaj názov vozidla."
        if (fuelType !in SUPPORTED_FUEL_TYPES) errors += "Vyber platný druh paliva."
        if (parsedConsumption == null || !parsedConsumption.isFinite() || parsedConsumption !in 0.0..100.0) {
            errors += "Spotreba musí byť číslo od 0 do 100 l/100 km."
        }
        if (parsedPrice == null || !parsedPrice.isFinite() || parsedPrice !in 0.0..20.0) {
            errors += "Cena paliva musí byť číslo od 0 do 20 za liter."
        }

        if (errors.isNotEmpty()) return VehicleFormResult.Invalid(errors)

        return VehicleFormResult.Valid(
            VehicleProfile(
                id = id.trim(),
                name = name.trim(),
                brand = brand.trim(),
                model = model.trim(),
                fuelType = fuelType,
                averageConsumptionL100Km = parsedConsumption!!,
                fuelPricePerLiter = parsedPrice!!,
                isDefault = isDefault
            )
        )
    }

    companion object {
        val SUPPORTED_FUEL_TYPES = setOf("PETROL", "DIESEL", "LPG", "CNG", "ELECTRIC", "HYBRID")
    }
}

sealed interface VehicleFormResult {
    data class Valid(val vehicle: VehicleProfile) : VehicleFormResult
    data class Invalid(val errors: List<String>) : VehicleFormResult
}

fun VehicleProfile.toFormState(): VehicleProfileFormState = VehicleProfileFormState(
    id = id,
    name = name,
    brand = brand,
    model = model,
    fuelType = fuelType,
    consumptionL100Km = averageConsumptionL100Km.toString(),
    fuelPricePerLiter = fuelPricePerLiter.toString(),
    isDefault = isDefault
)
