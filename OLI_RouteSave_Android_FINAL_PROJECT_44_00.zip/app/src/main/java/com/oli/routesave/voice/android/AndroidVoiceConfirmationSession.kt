package com.oli.routesave.voice.android

import android.content.Context
import com.oli.routesave.voice.ConfirmationPromptState
import com.oli.routesave.voice.ConfirmationUiState
import com.oli.routesave.voice.PendingVoiceAction
import com.oli.routesave.voice.VoiceConfirmationCoordinator

/**
 * Live microphone/TTS bridge for the explicit confirmation flow.
 * It only records the answer and updates the confirmation state. It never
 * executes the pending external action.
 */
class AndroidVoiceConfirmationSession(
    context: Context,
    private val coordinator: VoiceConfirmationCoordinator,
    private val onStateChanged: (ConfirmationPromptState) -> Unit
) {
    private val output = AndroidSpeechOutput(context) { ready ->
        if (!ready) {
            onStateChanged(
                coordinator.current.copy(message = "Hlasový výstup nie je pripravený; otázku si môžeš prečítať na obrazovke.")
            )
        }
    }

    private val input = AndroidSpeechInput(
        context = context,
        onPartialText = { text ->
            onStateChanged(
                coordinator.current.copy(message = "Počúvam odpoveď: $text")
            )
        },
        onFinalText = { text ->
            handleRecognizedAnswer(text, 0.75f)
        },
        onErrorMessage = { message ->
            onStateChanged(
                coordinator.current.copy(
                    state = ConfirmationUiState.NEEDS_CLARIFICATION,
                    prompt = "Nepodarilo sa rozpoznať odpoveď. Skús to znova a povedz jasne áno alebo nie.",
                    message = message
                )
            )
            output.speak("Nepočula som odpoveď. Skús to znova a povedz jasne áno alebo nie.", "sk-SK")
        },
        onFinalConfidence = { text, confidence ->
            handleRecognizedAnswer(text, confidence)
        }
    )

    private fun handleRecognizedAnswer(text: String, confidence: Float) {
        val state = coordinator.receiveAnswer(text, confidence)
        onStateChanged(state)
        if (state.state == ConfirmationUiState.NEEDS_CLARIFICATION) {
            output.speak(state.prompt, "sk-SK")
        } else {
            output.speak(state.message, "sk-SK")
        }
    }

    fun hasMicrophonePermission(): Boolean = input.hasMicrophonePermission()
    fun isRecognitionAvailable(): Boolean = input.isAvailable()

    fun ask(action: PendingVoiceAction) {
        val state = coordinator.requestConfirmation(action)
        onStateChanged(state)
        output.speak(state.prompt, "sk-SK")
    }

    fun startListeningForAnswer() {
        if (!input.hasMicrophonePermission()) {
            onStateChanged(
                coordinator.current.copy(message = "Najprv povoľ mikrofón.")
            )
            output.speak("Najprv povoľ mikrofón.", "sk-SK")
            return
        }
        coordinator.markPromptSpoken()
        onStateChanged(coordinator.current)
        input.start("sk-SK")
    }

    fun stopListening() {
        input.stop()
        onStateChanged(coordinator.current)
    }

    fun stopSpeaking() = output.stop()

    fun close() {
        input.stop()
        output.shutdown()
    }
}
