package com.oli.routesave.ui.compose

import com.oli.routesave.voice.android.AndroidVoiceConfirmationSession

import com.oli.routesave.voice.VoiceConfirmationCoordinator
import com.oli.routesave.voice.ConfirmationUiState
import com.oli.routesave.voice.PendingVoiceAction
import com.oli.routesave.voice.VoiceIntent

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.oli.routesave.voice.AndroidVoiceSession
import com.oli.routesave.voice.VoiceInteractionCoordinator
import com.oli.routesave.voice.VoiceInteractionState
import com.oli.routesave.voice.VoiceAssistantId
import com.oli.routesave.voice.VoiceInteractionEvent

import com.oli.routesave.voice.VoiceCommandPolicy

import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Subway
import androidx.compose.material.icons.filled.Tram
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.rememberCoroutineScope
import com.oli.routesave.travel.JourneyLegMode
import com.oli.routesave.travel.JourneyPreference
import com.oli.routesave.travel.JourneySearchRequest
import com.oli.routesave.travel.JourneySearchResult
import com.oli.routesave.travel.JourneyDataStatus
import com.oli.routesave.travel.JourneySearchService
import com.oli.routesave.travel.UnconfiguredJourneySearchProvider

import androidx.compose.material.icons.filled.Train
import kotlinx.coroutines.launch
import com.oli.routesave.travel.TransitDataFreshness
import com.oli.routesave.travel.TransitMode
import com.oli.routesave.travel.TransitSearchResult
import com.oli.routesave.travel.TransitSearchRequest
import com.oli.routesave.travel.UnconfiguredTransitSearchProvider
import com.oli.routesave.travel.TransitSearchService
import androidx.compose.material.icons.filled.CompareArrows
import com.oli.routesave.travel.TravelComparisonInput
import com.oli.routesave.travel.TravelModeComparisonService
import androidx.compose.material.icons.filled.AccountBalanceWallet
import com.oli.routesave.travel.BudgetStatus
import com.oli.routesave.travel.TravelBudgetService
import com.oli.routesave.travel.SharedPreferencesTravelBudgetRepository
import androidx.compose.material.icons.filled.Analytics
import com.oli.routesave.travel.TripStatisticsPeriod
import com.oli.routesave.travel.TripStatisticsService
import androidx.compose.material.icons.filled.History
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import com.oli.routesave.travel.TripHistoryRecord
import com.oli.routesave.travel.TripHistoryService
import com.oli.routesave.travel.SharedPreferencesTripHistoryRepository
import com.oli.routesave.travel.VehicleProfile as CostVehicleProfile
import com.oli.routesave.travel.TripCostResult
import com.oli.routesave.travel.TripCostInput
import com.oli.routesave.travel.TripCostCalculator
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Calculate
import com.oli.routesave.voice.assistant.VoiceAssistantSettingsManager
import com.oli.routesave.voice.assistant.SharedPreferencesVoiceAssistantSettingsStore
import com.oli.routesave.voice.assistant.AssistantProfileCatalog
import com.oli.routesave.data.store.SharedPreferencesVehicleStore
import com.oli.routesave.data.persistence.VehicleRepository
import com.oli.routesave.data.model.VehicleProfile
import androidx.compose.runtime.remember
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class AppTab(val label: String, val icon: ImageVector) {
    Home("Domov", Icons.Filled.Home),
    Route("Trasa", Icons.Filled.Explore),
    Drive("Jazda", Icons.Filled.DirectionsCar),
    Community("Komunita", Icons.Filled.People),
    More("Viac", Icons.Filled.Tune)
}

@Composable
fun RouteSaveComposeApp() {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.Home.name) }
    var driveRunning by rememberSaveable { mutableStateOf(false) }
    var assistantListening by rememberSaveable { mutableStateOf(false) }

    val context = LocalContext.current
    val vehicleRepository = remember(context) {
        VehicleRepository(SharedPreferencesVehicleStore(context.applicationContext))
    }
    val assistantSettingsManager = remember(context) {
        VoiceAssistantSettingsManager(
            SharedPreferencesVoiceAssistantSettingsStore(context.applicationContext)
        )
    }
    val tripHistoryRepository = remember(context) {
        SharedPreferencesTripHistoryRepository(context.applicationContext)
    }
    val tripHistoryService = remember(context) {
        TripHistoryService(tripHistoryRepository)
    }
    val tripStatisticsService = remember(context) {
        TripStatisticsService(tripHistoryRepository)
    }
    val travelBudgetService = remember(context) {
        TravelBudgetService(
            tripHistoryRepository,
            SharedPreferencesTravelBudgetRepository(context.applicationContext)
        )
    }
    var refreshCounter by rememberSaveable { mutableStateOf(0) }

    RouteSaveTheme {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF061321),
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    AppTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab.name,
                            onClick = { selectedTab = tab.name },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (AppTab.valueOf(selectedTab)) {
                    AppTab.Home -> HomeScreen(
                        vehicleRepository = vehicleRepository,
                        assistantListening = assistantListening,
                        onAssistantClick = { assistantListening = !assistantListening },
                        onStartDrive = {
                            driveRunning = true
                            selectedTab = AppTab.Drive.name
                        },
                        onRouteClick = { selectedTab = AppTab.Route.name },
                        onCommunityClick = { selectedTab = AppTab.Community.name },
                        onVehicleClick = { selectedTab = "Vehicle" }
                    )
                    AppTab.Route -> RouteScreen(onStartNavigation = {
                        driveRunning = true
                        selectedTab = AppTab.Drive.name
                    })
                    AppTab.Drive -> DriveScreen(
                        driveRunning = driveRunning,
                        onToggleDrive = { driveRunning = !driveRunning },
                        assistantListening = assistantListening,
                        onAssistantClick = { assistantListening = !assistantListening }
                    )
                    AppTab.Community -> CommunityScreen()
                    AppTab.More -> MoreScreen(
                        onVehicle = { selectedTab = "Vehicle" },
                        onAssistant = { selectedTab = "Assistant" },
                        onSettings = { selectedTab = "Settings" },
                        onHistory = { selectedTab = "History" },
                        onStatistics = { selectedTab = "Statistics" },
                        onBudget = { selectedTab = "Budget" },
                        onCompareTravel = { selectedTab = "CompareTravel" },
                        onTransitSearch = { selectedTab = "TransitSearch" },
                        onSmartContinuation = { selectedTab = "SmartContinuation" },
                        onVoiceCompanion = { selectedTab = "VoiceCompanion" },
                        onVoiceControl = { selectedTab = "VoiceControl" },
                        onVoiceConfirmation = { selectedTab = "VoiceConfirmation" }
                    )
                }
                // Lightweight destinations accessible from More.
                if (selectedTab in listOf("Vehicle", "Assistant", "Settings", "History", "Statistics", "Budget", "CompareTravel", "TransitSearch", "SmartContinuation", "VoiceCompanion", "VoiceControl", "VoiceConfirmation")) {
                    when (selectedTab) {
                        "Vehicle" -> VehicleProfileScreen(
                            repository = vehicleRepository,
                            refreshKey = refreshCounter,
                            onBack = { selectedTab = AppTab.More.name },
                            onSaved = { refreshCounter++ }
                        )
                        "Assistant" -> AssistantSettingsScreen(
                            manager = assistantSettingsManager,
                            onBack = { selectedTab = AppTab.More.name },
                            onSaved = { refreshCounter++ }
                        )
                        "History" -> TripHistoryScreen(
                            service = tripHistoryService,
                            refreshKey = refreshCounter,
                            onBack = { selectedTab = AppTab.More.name },
                            onDelete = { refreshCounter++ }
                        )
                        "Statistics" -> TripStatisticsScreen(
                            service = tripStatisticsService,
                            refreshKey = refreshCounter,
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "Budget" -> TravelBudgetScreen(
                            service = travelBudgetService,
                            refreshKey = refreshCounter,
                            onBack = { selectedTab = AppTab.More.name },
                            onSaved = { refreshCounter++ }
                        )
                        "CompareTravel" -> TravelModeComparisonScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "TransitSearch" -> TransitSearchScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "SmartContinuation" -> SmartContinuationScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "VoiceCompanion" -> VoiceCompanionScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "VoiceControl" -> VoiceControlScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        "VoiceConfirmation" -> VoiceConfirmationScreen(
                            onBack = { selectedTab = AppTab.More.name }
                        )
                        else -> DetailScreen("Nastavenia", "Jazyk", "Aplikácia", "Slovenčina", "Vzhľad", "Tmavomodrý")
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    vehicleRepository: VehicleRepository,
    assistantListening: Boolean,
    onAssistantClick: () -> Unit,
    onStartDrive: () -> Unit,
    onRouteClick: () -> Unit,
    onCommunityClick: () -> Unit,
    onVehicleClick: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("OLI RouteSave", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Save money. Travel smarter.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(46.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("OLI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
            }
        }
        MapPlaceholder("Tvoja mapa sa zobrazí tu", Modifier.fillMaxWidth().height(205.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("Trasa", Icons.Filled.Explore, Modifier.weight(1f), onRouteClick)
            QuickAction("Komunita", Icons.Filled.People, Modifier.weight(1f), onCommunityClick)
        }
        val savedVehicle = vehicleRepository.defaultVehicle()
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            onClick = onVehicleClick
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Tvoje vozidlo", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (savedVehicle == null) {
                    Text("Zatiaľ nemáš uložené predvolené vozidlo.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = onVehicleClick) { Text("Pridať vozidlo") }
                } else {
                    Text(
                        listOf(savedVehicle.brand, savedVehicle.model).filter { it.isNotBlank() }.joinToString(" ").ifBlank { savedVehicle.name },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(savedVehicle.averageConsumptionL100Km.toString(), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(" l/100 km", modifier = Modifier.padding(start = 5.dp, bottom = 4.dp))
                        Spacer(Modifier.weight(1f))
                        Text("${savedVehicle.fuelPricePerLiter} €/l", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onVehicleClick) { Text("Upraviť vozidlo") }
                }
            }
        }
        TripCostQuickCalculator(vehicle = savedVehicle, historyService = tripHistoryService)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Mic, contentDescription = "Hlas", tint = Color.White) }
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Tvoj AI spolujazdec", fontWeight = FontWeight.Bold)
                    Text(if (assistantListening) "Počúvam… (ukážkový režim)" else "Niko je pripravený pomôcť", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
                Button(onClick = onAssistantClick) { Text(if (assistantListening) "Stop" else "Hovoriť") }
            }
        }
        Button(
            onClick = onStartDrive,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("SPUSTIŤ JAZDU", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text("Ukážkový vzhľad aplikácie — navigácia a hlasové funkcie ešte potrebujú reálne služby.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
}


@Composable
private fun TripCostQuickCalculator(
    vehicle: com.oli.routesave.data.model.VehicleProfile?,
    historyService: TripHistoryService
) {
    var distanceText by rememberSaveable { mutableStateOf("100") }
    var originText by rememberSaveable { mutableStateOf("") }
    var destinationText by rememberSaveable { mutableStateOf("") }
    var tollText by rememberSaveable { mutableStateOf("0") }
    var parkingText by rememberSaveable { mutableStateOf("0") }
    var overrideText by rememberSaveable { mutableStateOf("") }
    var resultText by rememberSaveable { mutableStateOf("") }
    var lastSavedEstimate by remember { mutableStateOf<com.oli.routesave.travel.TripCostEstimate?>(null) }
    var lastSavedInput by remember { mutableStateOf<TripCostInput?>(null) }
    var saveMessage by rememberSaveable { mutableStateOf("") }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(8.dp))
                Text("Rýchly výpočet nákladov", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Text(
                "Odhad paliva, mýta a parkovania podľa uloženého vozidla.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            OutlinedTextField(
                value = originText,
                onValueChange = { originText = it; saveMessage = "" },
                label = { Text("Začiatok (voliteľné)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = destinationText,
                onValueChange = { destinationText = it; saveMessage = "" },
                label = { Text("Cieľ (voliteľné)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = distanceText,
                onValueChange = { distanceText = it; resultText = ""; lastSavedEstimate = null; saveMessage = "" },
                label = { Text("Vzdialenosť (km)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = overrideText,
                onValueChange = { overrideText = it; resultText = ""; lastSavedEstimate = null; saveMessage = "" },
                label = { Text("Spotreba pre túto cestu (voliteľné)") },
                supportingText = { Text("l/100 km; prázdne = spotreba z profilu") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = tollText,
                    onValueChange = { tollText = it; resultText = ""; lastSavedEstimate = null; saveMessage = "" },
                    label = { Text("Mýto (€)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = parkingText,
                    onValueChange = { parkingText = it; resultText = ""; lastSavedEstimate = null; saveMessage = "" },
                    label = { Text("Parkovanie (€)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Button(
                onClick = {
                    val currentVehicle = vehicle
                    if (currentVehicle == null) {
                        resultText = "Najprv ulož vozidlo v profile."
                    } else {
                        val distance = distanceText.trim().replace(',', '.').toDoubleOrNull()
                        val override = overrideText.trim().takeIf { it.isNotEmpty() }?.replace(',', '.')?.toDoubleOrNull()
                        val toll = tollText.trim().replace(',', '.').toDoubleOrNull()
                        val parking = parkingText.trim().replace(',', '.').toDoubleOrNull()
                        if (distance == null || toll == null || parking == null ||
                            (overrideText.isNotBlank() && override == null)) {
                            resultText = "Skontroluj zadané čísla."
                        } else {
                            val result = TripCostCalculator().estimate(
                                CostVehicleProfile(
                                    id = currentVehicle.id,
                                    displayName = currentVehicle.name,
                                    averageConsumptionLitresPer100Km = currentVehicle.averageConsumptionL100Km,
                                    defaultFuelPricePerLitre = currentVehicle.fuelPricePerLiter
                                ),
                                TripCostInput(
                                    distanceKm = distance,
                                    fuelPricePerLitre = currentVehicle.fuelPricePerLiter,
                                    consumptionOverrideLitresPer100Km = override,
                                    tollCost = toll,
                                    parkingCost = parking
                                )
                            )
                            resultText = when (result) {
                                is TripCostResult.Invalid -> {
                                    lastSavedEstimate = null
                                    lastSavedInput = null
                                    result.reasons.joinToString("\n")
                                }
                                is TripCostResult.Success -> {
                                    val e = result.estimate
                                    lastSavedEstimate = e
                                    lastSavedInput = TripCostInput(
                                        distanceKm = distance,
                                        fuelPricePerLitre = currentVehicle.fuelPricePerLiter,
                                        consumptionOverrideLitresPer100Km = override,
                                        tollCost = toll,
                                        parkingCost = parking
                                    )
                                    saveMessage = ""
                                    "Palivo: %.2f l • %.2f €\nMýto: %.2f € • Parkovanie: %.2f €\nSpolu: %.2f €".format(
                                        java.util.Locale.GERMANY,
                                        e.fuelLitres, e.fuelCost, e.tollCost, e.parkingCost, e.totalCost
                                    )
                                }
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Calculate, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Vypočítať náklady")
            }
            if (resultText.isNotBlank()) {
                Text(resultText, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
            }
            if (lastSavedEstimate != null && lastSavedInput != null && vehicle != null) {
                OutlinedButton(
                    onClick = {
                        try {
                            val costVehicle = CostVehicleProfile(
                                id = vehicle.id,
                                displayName = vehicle.name,
                                averageConsumptionLitresPer100Km = vehicle.averageConsumptionL100Km,
                                defaultFuelPricePerLitre = vehicle.fuelPricePerLiter
                            )
                            historyService.recordEstimate(
                                origin = originText.ifBlank { "Nezadaný začiatok" },
                                destination = destinationText.ifBlank { "Nezadaný cieľ" },
                                vehicle = costVehicle,
                                input = lastSavedInput!!,
                                estimate = lastSavedEstimate!!
                            )
                            saveMessage = "Cesta bola uložená do histórie."
                            lastSavedEstimate = null
                            lastSavedInput = null
                        } catch (e: Exception) {
                            saveMessage = "Cestu sa nepodarilo uložiť: ${e.message ?: "skús to znova"}"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.History, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Uložiť cestu do histórie")
                }
            }
            if (saveMessage.isNotBlank()) {
                Text(saveMessage, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RouteScreen(onStartNavigation: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Plánovanie trasy", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        InfoCard("Štart", "Myjava")
        InfoCard("Cieľ", "Piešťany")
        MapPlaceholder("Náhľad trasy", Modifier.fillMaxWidth().height(250.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Odhad cesty", fontWeight = FontWeight.Bold)
                Text("52 km  •  približne 48 min")
                Text("Palivo: orientačný odhad podľa nastavenej spotreby", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
        Button(onClick = onStartNavigation, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
            Text("Spustiť navigáciu")
        }
    }
}

@Composable
private fun DriveScreen(
    driveRunning: Boolean,
    onToggleDrive: () -> Unit,
    assistantListening: Boolean,
    onAssistantClick: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Jazda", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Pokračujte po trase", color = Color.White)
                Text("O 2,5 km odbočte doprava", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            }
        }
        MapPlaceholder("Živá mapa a poloha vozidla", Modifier.fillMaxWidth().weight(1f).height(180.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Zostáva", "52 km", Modifier.weight(1f))
            MetricCard("Príchod", "11:12", Modifier.weight(1f))
            MetricCard("Rýchlosť", "-- km/h", Modifier.weight(1f))
        }
        OutlinedButton(onClick = onAssistantClick, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
            Text(if (assistantListening) "Počúvam… (ukážkový režim)" else "Hlasový asistent: Niko")
        }
        Button(
            onClick = onToggleDrive,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (driveRunning) Color(0xFFE53935) else MaterialTheme.colorScheme.primary)
        ) {
            Text(if (driveRunning) "UKONČIŤ JAZDU" else "SPUSTIŤ UKÁŽKOVÚ JAZDU")
        }
    }
}

@Composable
private fun CommunityScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ľudia pomáhajú ľuďom", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Pomoc pre vodičov, motocyklistov, cyklistov aj chodcov.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        HelpCard("Vodič kamiónu", "Defekt na D1. Potrebujem pomoc.", "Pri Bratislave")
        HelpCard("Cyklista", "Potrebujem pumpu na bicykel.", "Myjava")
        HelpCard("Upozornenie na ceste", "Pred vami je prekážka na vozovke.", "Smer Česká republika")
        Text("Pred odoslaním žiadosti alebo zdieľaním polohy sa asistent vždy opýta na potvrdenie.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun MoreScreen(
    onVehicle: () -> Unit,
    onAssistant: () -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
    onStatistics: () -> Unit,
    onBudget: () -> Unit,
    onCompareTravel: () -> Unit,
    onTransitSearch: () -> Unit,
    onSmartContinuation: () -> Unit,
    onVoiceCompanion: () -> Unit,
    onVoiceControl: () -> Unit,
    onVoiceConfirmation: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Viac funkcií", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        QuickAction("Profil vozidla", Icons.Filled.DirectionsCar, Modifier.fillMaxWidth(), onVehicle)
        QuickAction("Hlasový asistent", Icons.Filled.Mic, Modifier.fillMaxWidth(), onAssistant)
        QuickAction("Nastavenia", Icons.Filled.Settings, Modifier.fillMaxWidth(), onSettings)
        QuickAction("História ciest", Icons.Filled.History, Modifier.fillMaxWidth(), onHistory)
        QuickAction("Štatistiky cestovania", Icons.Filled.Analytics, Modifier.fillMaxWidth(), onStatistics)
        QuickAction("Mesačný rozpočet", Icons.Filled.AccountBalanceWallet, Modifier.fillMaxWidth(), onBudget)
        QuickAction("Porovnať spôsob dopravy", Icons.Filled.CompareArrows, Modifier.fillMaxWidth(), onCompareTravel)
        QuickAction("Vlaky a autobusy", Icons.Filled.Train, Modifier.fillMaxWidth(), onTransitSearch)
        QuickAction("Inteligentné pokračovanie cesty", Icons.Filled.Route, Modifier.fillMaxWidth(), onSmartContinuation)
        QuickAction("Hlasový spolujazdec", Icons.Filled.RecordVoiceOver, Modifier.fillMaxWidth(), onVoiceCompanion)
        QuickAction("Ovládanie hlasom", Icons.Filled.Mic, Modifier.fillMaxWidth(), onVoiceControl)
        QuickAction("Potvrdenie hlasom", Icons.Filled.VerifiedUser, Modifier.fillMaxWidth(), onVoiceConfirmation)
        InfoCard("Ďalšie moduly", "História jázd • Obľúbené trasy • Parkovanie a mýto • Offline mapy")
    }
}







@Composable
private fun TransitSearchScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var origin by rememberSaveable { mutableStateOf("") }
    var destination by rememberSaveable { mutableStateOf("") }
    var mode by rememberSaveable { mutableStateOf("ALL") }
    var passengers by rememberSaveable { mutableStateOf("1") }
    var message by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var result by remember { mutableStateOf<TransitSearchResult?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Text("Späť")
            }
            Spacer(Modifier.width(12.dp))
            Text("Vlaky a autobusy", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Text("Priprav vyhľadávanie spojení. Zatiaľ nie je pripojený poskytovateľ živých cestovných dát.")
        OutlinedTextField(
            value = origin,
            onValueChange = { origin = it; result = null; message = "" },
            label = { Text("Odkiaľ") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = destination,
            onValueChange = { destination = it; result = null; message = "" },
            label = { Text("Kam") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ALL" to "Všetky", "TRAIN" to "Vlak", "BUS" to "Autobus").forEach { (key, label) ->
                FilterChip(selected = mode == key, onClick = { mode = key; result = null }, label = { Text(label) })
            }
        }
        OutlinedTextField(
            value = passengers,
            onValueChange = { passengers = it; result = null },
            label = { Text("Počet cestujúcich") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Button(
            onClick = {
                val count = passengers.toIntOrNull()
                val request = if (count == null) null else TransitSearchRequest(
                    origin = origin.trim(),
                    destination = destination.trim(),
                    mode = when (mode) {
                        "TRAIN" -> TransitMode.TRAIN
                        "BUS" -> TransitMode.BUS
                        else -> null
                    },
                    passengers = count
                )
                val errors = request?.validate() ?: listOf("Zadaj platný počet cestujúcich.")
                if (errors.isNotEmpty()) {
                    message = errors.joinToString(" ")
                    result = null
                } else {
                    searching = true
                    message = ""
                    scope.launch {
                        try {
                            result = TransitSearchService(UnconfiguredTransitSearchProvider()).search(request!!)
                            message = result?.providerMessage.orEmpty()
                        } catch (e: Exception) {
                            message = e.message ?: "Vyhľadávanie sa nepodarilo."
                            result = null
                        } finally {
                            searching = false
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !searching
        ) {
            Icon(Icons.Filled.Search, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (searching) "Vyhľadávam…" else "Vyhľadať spojenia")
        }
        if (message.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        when (result?.freshness ?: TransitDataFreshness.UNAVAILABLE) {
                            TransitDataFreshness.LIVE -> "Živé údaje"
                            TransitDataFreshness.CACHED -> "Uložené údaje"
                            TransitDataFreshness.SAMPLE -> "Ukážkové údaje"
                            TransitDataFreshness.UNAVAILABLE -> "Živé údaje nie sú dostupné"
                        },
                        fontWeight = FontWeight.Bold
                    )
                    Text(message)
                    result?.connections?.forEach { connection ->
                        Text("${connection.provider}: ${connection.origin} → ${connection.destination}")
                        Text(connection.price?.let { "%.2f %s".format(Locale.GERMANY, it, connection.currencyCode) } ?: "Cena nie je dostupná")
                    }
                }
            }
        }
        Text(
            "Táto obrazovka zatiaľ nepredstiera živé ceny ani odchody. Po výbere poskytovateľa API ju bude možné pripojiť k reálnym spojeniam.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TravelModeComparisonScreen(onBack: () -> Unit) {
    var distanceText by rememberSaveable { mutableStateOf("300") }
    var consumptionText by rememberSaveable { mutableStateOf("6.0") }
    var fuelPriceText by rememberSaveable { mutableStateOf("1.70") }
    var tollText by rememberSaveable { mutableStateOf("0") }
    var parkingText by rememberSaveable { mutableStateOf("0") }
    var trainText by rememberSaveable { mutableStateOf("") }
    var busText by rememberSaveable { mutableStateOf("") }
    var planeText by rememberSaveable { mutableStateOf("") }
    var trainExtraText by rememberSaveable { mutableStateOf("0") }
    var busExtraText by rememberSaveable { mutableStateOf("0") }
    var planeExtraText by rememberSaveable { mutableStateOf("0") }
    var result by remember { mutableStateOf<com.oli.routesave.travel.TravelComparisonResult?>(null) }
    var error by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Text("Späť")
            }
            Spacer(Modifier.width(12.dp))
            Text("Porovnanie dopravy", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Text("Porovnaj orientačné náklady na auto, vlak, autobus a lietadlo.")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Auto", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                ComparisonField(distanceText, { distanceText = it; result = null }, "Vzdialenosť (km)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ComparisonField(consumptionText, { consumptionText = it; result = null }, "Spotreba l/100 km", Modifier.weight(1f))
                    ComparisonField(fuelPriceText, { fuelPriceText = it; result = null }, "Cena paliva €/l", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ComparisonField(tollText, { tollText = it; result = null }, "Mýto €", Modifier.weight(1f))
                    ComparisonField(parkingText, { parkingText = it; result = null }, "Parkovanie €", Modifier.weight(1f))
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Vlak, autobus a lietadlo", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Zadaj cenu lístka, ktorú poznáš. Aplikácia zatiaľ nevyhľadáva živé ceny.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ComparisonField(trainText, { trainText = it; result = null }, "Vlak – cena lístka € (voliteľné)")
                ComparisonField(trainExtraText, { trainExtraText = it; result = null }, "Vlak – ďalšie náklady €")
                ComparisonField(busText, { busText = it; result = null }, "Autobus – cena lístka € (voliteľné)")
                ComparisonField(busExtraText, { busExtraText = it; result = null }, "Autobus – ďalšie náklady €")
                ComparisonField(planeText, { planeText = it; result = null }, "Lietadlo – cena lístka € (voliteľné)")
                ComparisonField(planeExtraText, { planeExtraText = it; result = null }, "Lietadlo – transfer/batožina €")
            }
        }
        Button(
            onClick = {
                fun number(s: String) = s.trim().replace(',', '.').toDoubleOrNull()
                val distance = number(distanceText)
                val consumption = number(consumptionText)
                val fuelPrice = number(fuelPriceText)
                val toll = number(tollText)
                val parking = number(parkingText)
                val train = if (trainText.isBlank()) null else number(trainText)
                val bus = if (busText.isBlank()) null else number(busText)
                val plane = if (planeText.isBlank()) null else number(planeText)
                val trainExtra = number(trainExtraText)
                val busExtra = number(busExtraText)
                val planeExtra = number(planeExtraText)
                if (distance == null || consumption == null || fuelPrice == null || toll == null ||
                    parking == null || trainExtra == null || busExtra == null || planeExtra == null ||
                    (trainText.isNotBlank() && train == null) || (busText.isNotBlank() && bus == null) ||
                    (planeText.isNotBlank() && plane == null)) {
                    error = "Skontroluj zadané čísla."
                    result = null
                } else {
                    try {
                        result = TravelModeComparisonService().compare(
                            TravelComparisonInput(
                                distanceKm = distance,
                                fuelConsumptionL100Km = consumption,
                                fuelPricePerLitre = fuelPrice,
                                carTollCost = toll,
                                carParkingCost = parking,
                                trainTicketCost = train,
                                busTicketCost = bus,
                                planeTicketCost = plane,
                                trainExtraCosts = trainExtra,
                                busExtraCosts = busExtra,
                                planeExtraCosts = planeExtra
                            )
                        )
                        error = ""
                    } catch (e: IllegalArgumentException) {
                        error = e.message ?: "Skontroluj zadané hodnoty."
                        result = null
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.CompareArrows, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Porovnať náklady")
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        result?.let { comparison ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Výsledok porovnania", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    comparison.options.forEach { option ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    when (option.mode) {
                                        TravelMode.CAR -> "Auto"
                                        TravelMode.TRAIN -> "Vlak"
                                        TravelMode.BUS -> "Autobus"
                                        TravelMode.PLANE -> "Lietadlo"
                                    },
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(option.totalCost?.let { "%.2f %s".format(Locale.GERMANY, it, option.currencyCode) } ?: "Cena nezadaná")
                            }
                            Text(option.notes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                    comparison.cheapestAvailable?.let {
                        Text("Najlacnejšia z nacenených možností: ${it.mode.name} — %.2f %s".format(Locale.GERMANY, it.totalCost, it.currencyCode), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    }
                    Text("Všetky zobrazené ceny sú orientačné, nie živé ponuky.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ComparisonField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier,
        singleLine = true
    )
}

@Composable
private fun TravelBudgetScreen(
    service: TravelBudgetService,
    refreshKey: Int,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    var limitText by rememberSaveable(refreshKey) {
        mutableStateOf(service.overview().budget?.monthlyLimit?.toString() ?: "")
    }
    var currency by rememberSaveable(refreshKey) {
        mutableStateOf(service.overview().budget?.currencyCode ?: "EUR")
    }
    var message by rememberSaveable { mutableStateOf("") }
    val overview = remember(refreshKey, message) { service.overview() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Text("Späť")
            }
            Spacer(Modifier.width(12.dp))
            Text("Mesačný rozpočet", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Text("Nastav si limit na cestovanie. Výdavky sa počítajú z ciest, ktoré uložíš do histórie.")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tvoj limit", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = it; message = "" },
                    label = { Text("Mesačný rozpočet") },
                    supportingText = { Text("Zadaj sumu v zvolenej mene") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("EUR", "CZK", "PLN", "HUF", "RON", "USD", "GBP").forEach { code ->
                        FilterChip(
                            selected = currency == code,
                            onClick = { currency = code; message = "" },
                            label = { Text(code) }
                        )
                    }
                }
                Button(
                    onClick = {
                        val limit = limitText.trim().replace(',', '.').toDoubleOrNull()
                        if (limit == null || !limit.isFinite() || limit < 0.0) {
                            message = "Zadaj platný nezáporný rozpočet."
                        } else {
                            try {
                                service.saveMonthlyBudget(limit, currency)
                                message = "Rozpočet bol uložený."
                                onSaved()
                            } catch (e: Exception) {
                                message = "Rozpočet sa nepodarilo uložiť."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Uložiť rozpočet") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.secondary)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Stav za tento mesiac", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                StatisticLine("Uložené cesty", overview.tripCount.toString())
                StatisticLine("Minuté", "%.2f %s".format(Locale.GERMANY, overview.spent, overview.currencyCode))
                overview.budget?.let { budget ->
                    StatisticLine("Rozpočet", "%.2f %s".format(Locale.GERMANY, budget.monthlyLimit, budget.currencyCode))
                    StatisticLine(
                        if ((overview.remaining ?: 0.0) >= 0) "Zostáva" else "Nad limitom",
                        "%.2f %s".format(Locale.GERMANY, kotlin.math.abs(overview.remaining ?: 0.0), overview.currencyCode),
                        emphasize = true
                    )
                    overview.percentUsed?.let { pct ->
                        LinearProgressIndicator(
                            progress = { (pct / 100.0).coerceIn(0.0, 1.0).toFloat() },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("%.0f %% rozpočtu".format(Locale.GERMANY, pct))
                    }
                } ?: Text("Rozpočet ešte nie je nastavený.")
                val statusText = when (overview.status) {
                    BudgetStatus.NO_BUDGET -> "Nastav si limit, aby si videl stav rozpočtu."
                    BudgetStatus.ON_TRACK -> "Si v rámci rozpočtu."
                    BudgetStatus.NEAR_LIMIT -> "Pozor, minul si aspoň 80 % rozpočtu."
                    BudgetStatus.OVER_LIMIT -> "Mesačný rozpočet je prekročený."
                }
                Text(statusText, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
            }
        }
        Text(
            "Upozornenie vychádza len z uložených odhadov ciest; nezaznamenané výdavky sa nezapočítavajú.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TripStatisticsScreen(
    service: TripStatisticsService,
    refreshKey: Int,
    onBack: () -> Unit
) {
    var period by rememberSaveable { mutableStateOf(TripStatisticsPeriod.THIS_MONTH.name) }
    val stats = remember(refreshKey, period) {
        service.calculate(TripStatisticsPeriod.valueOf(period))
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Text("Späť")
            }
            Spacer(Modifier.width(12.dp))
            Text("Štatistiky", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Text("Prehľad nákladov a vzdialeností z uložených ciest.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                TripStatisticsPeriod.THIS_MONTH to "Tento mesiac",
                TripStatisticsPeriod.LAST_30_DAYS to "30 dní",
                TripStatisticsPeriod.ALL_TIME to "Celé obdobie"
            ).forEach { (option, label) ->
                FilterChip(
                    selected = period == option.name,
                    onClick = { period = option.name },
                    label = { Text(label) }
                )
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Finančný prehľad", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                StatisticLine("Počet ciest", stats.tripCount.toString())
                StatisticLine("Najazdené kilometre", "%.1f km".format(Locale.GERMANY, stats.distanceKm))
                StatisticLine("Spotrebované palivo", "%.1f l".format(Locale.GERMANY, stats.fuelLitres))
                StatisticLine("Palivo", "%.2f %s".format(Locale.GERMANY, stats.fuelCost, stats.currencyCode))
                StatisticLine("Mýto", "%.2f %s".format(Locale.GERMANY, stats.tollCost, stats.currencyCode))
                StatisticLine("Parkovanie", "%.2f %s".format(Locale.GERMANY, stats.parkingCost, stats.currencyCode))
                if (stats.otherCosts > 0.0) {
                    StatisticLine("Ostatné náklady", "%.2f %s".format(Locale.GERMANY, stats.otherCosts, stats.currencyCode))
                }
                HorizontalDivider()
                StatisticLine("Spolu", "%.2f %s".format(Locale.GERMANY, stats.totalCost, stats.currencyCode), emphasize = true)
            }
        }
        if (stats.tripCount == 0) {
            Text("Za vybrané obdobie zatiaľ nemáš uložené cesty. Najprv vypočítaj náklady a ulož cestu do histórie.")
        }
        Text(
            "Poznámka: ide o súčet uložených odhadov. Ak sú záznamy v rôznych menách, štatistika ich nesčíta dokopy.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatisticLine(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (emphasize) FontWeight.ExtraBold else FontWeight.SemiBold)
    }
}

@Composable
private fun TripHistoryScreen(
    service: TripHistoryService,
    refreshKey: Int,
    onBack: () -> Unit,
    onDelete: () -> Unit
) {
    val records = remember(refreshKey) { service.history() }
    val summary = remember(refreshKey) { service.summary() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null); Text("Späť") }
            Spacer(Modifier.width(12.dp))
            Text("História ciest", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Súhrn histórie", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Uložené cesty: ${summary.tripCount}")
                Text("Celková vzdialenosť: %.1f km".format(Locale.GERMANY, summary.totalDistanceKm))
                Text("Spotrebované palivo: %.1f l".format(Locale.GERMANY, summary.totalFuelLitres))
                Text("Celkové náklady: %.2f %s".format(Locale.GERMANY, summary.totalCost, summary.currencyCode))
            }
        }
        if (records.isEmpty()) {
            Text("Zatiaľ nemáš uložené žiadne cesty. Po pripojení tlačidla „Uložiť cestu“ z kalkulačky sa tu zobrazia tvoje odhady.")
        } else {
            records.forEach { record ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("${record.origin} → ${record.destination}", fontWeight = FontWeight.Bold)
                        Text("%.1f km • %.2f %s".format(Locale.GERMANY, record.distanceKm, record.totalCost, record.currencyCode))
                        Text("Palivo: %.2f l (%.2f €) • Mýto: %.2f € • Parkovanie: %.2f €".format(
                            Locale.GERMANY, record.fuelLitres, record.fuelCost, record.tollCost, record.parkingCost
                        ), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        Text(
                            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(record.createdAtEpochMs)),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                        OutlinedButton(onClick = { service.delete(record.id); onDelete() }) { Text("Odstrániť") }
                    }
                }
            }
        }
    }
}

@Composable
private fun VehicleProfileScreen(
    repository: VehicleRepository,
    refreshKey: Int,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val existing = remember(refreshKey) { repository.defaultVehicle() ?: repository.all().firstOrNull() }
    var id by remember(refreshKey) { mutableStateOf(existing?.id ?: "vehicle-main") }
    var name by remember(refreshKey) { mutableStateOf(existing?.name ?: "") }
    var brand by remember(refreshKey) { mutableStateOf(existing?.brand ?: "") }
    var model by remember(refreshKey) { mutableStateOf(existing?.model ?: "") }
    var fuelType by remember(refreshKey) { mutableStateOf(existing?.fuelType ?: "DIESEL") }
    var consumption by remember(refreshKey) { mutableStateOf(existing?.averageConsumptionL100Km?.toString() ?: "6.0") }
    var price by remember(refreshKey) { mutableStateOf(existing?.fuelPricePerLiter?.toString() ?: "1.70") }
    var isDefault by remember(refreshKey) { mutableStateOf(existing?.isDefault ?: true) }
    var message by remember(refreshKey) { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null); Text("Späť") }
            Spacer(Modifier.width(12.dp))
            Text("Profil vozidla", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Text("Údaje sa ukladajú lokálne v tomto telefóne.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Názov vozidla") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Značka") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Text("Palivo", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("DIESEL", "PETROL", "LPG", "CNG", "HYBRID", "ELECTRIC").forEach { type ->
                if (fuelType == type) {
                    Button(onClick = { fuelType = type }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp)) { Text(type, fontSize = 11.sp) }
                } else {
                    OutlinedButton(onClick = { fuelType = type }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp)) { Text(type, fontSize = 11.sp) }
                }
            }
        }
        OutlinedTextField(value = consumption, onValueChange = { consumption = it }, label = { Text("Spotreba (l/100 km)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Cena paliva (€/l)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Predvolené vozidlo", modifier = Modifier.weight(1f))
            Switch(checked = isDefault, onCheckedChange = { isDefault = it })
        }
        Button(
            onClick = {
                val parsedConsumption = consumption.trim().replace(',', '.').toDoubleOrNull()
                val parsedPrice = price.trim().replace(',', '.').toDoubleOrNull()
                when {
                    name.isBlank() -> message = "Zadaj názov vozidla."
                    parsedConsumption == null || !parsedConsumption.isFinite() || parsedConsumption !in 0.0..100.0 ->
                        message = "Spotreba musí byť od 0 do 100 l/100 km."
                    parsedPrice == null || !parsedPrice.isFinite() || parsedPrice !in 0.0..20.0 ->
                        message = "Cena paliva musí byť od 0 do 20 €/l."
                    else -> {
                        try {
                            repository.save(
                                VehicleProfile(
                                    id = id.ifBlank { "vehicle-main" },
                                    name = name.trim(),
                                    brand = brand.trim(),
                                    model = model.trim(),
                                    fuelType = fuelType,
                                    averageConsumptionL100Km = parsedConsumption,
                                    fuelPricePerLiter = parsedPrice,
                                    isDefault = isDefault
                                )
                            )
                            message = "Vozidlo bolo uložené."
                            onSaved()
                        } catch (e: IllegalArgumentException) {
                            message = e.message ?: "Vozidlo sa nepodarilo uložiť."
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Uložiť vozidlo")
        }
        if (message.isNotBlank()) {
            Text(message, color = if (message.contains("uložené")) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error)
        }
        HorizontalDivider()
        Text("Uložené vozidlá", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        val vehicles = repository.all()
        if (vehicles.isEmpty()) {
            Text("Zatiaľ nemáš uložené žiadne vozidlo.")
        } else {
            vehicles.forEach { vehicle ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        id = vehicle.id
                        name = vehicle.name
                        brand = vehicle.brand
                        model = vehicle.model
                        fuelType = vehicle.fuelType
                        consumption = vehicle.averageConsumptionL100Km.toString()
                        price = vehicle.fuelPricePerLiter.toString()
                        isDefault = vehicle.isDefault
                        message = "Načítané: ${vehicle.name}"
                    }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(vehicle.name + if (vehicle.isDefault) " • Predvolené" else "", fontWeight = FontWeight.SemiBold)
                        Text("${vehicle.brand} ${vehicle.model}".trim())
                        Text("${vehicle.averageConsumptionL100Km} l/100 km • ${vehicle.fuelPricePerLiter} €/l")
                    }
                }
            }
        }
    }
}

@Composable
private fun AssistantSettingsScreen(
    manager: VoiceAssistantSettingsManager,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    var settings by remember { mutableStateOf(manager.current()) }
    var message by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null); Text("Späť") }
            Spacer(Modifier.width(12.dp))
            Text("Hlasový asistent", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Text("Vyber asistenta a uprav jeho nastavenia.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        AssistantProfileCatalog.all.forEach { profile ->
            val selected = settings.selectedAssistantId == profile.id
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    when (val result = manager.selectAssistant(profile.id)) {
                        is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> {
                            settings = result.settings
                            message = "Vybraný asistent: ${profile.officialName}."
                            onSaved()
                        }
                        is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
                    }
                }
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(profile.officialName, fontWeight = FontWeight.Bold)
                        Text("Oslovenie: ${profile.invocationName}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Vybraný")
                }
            }
        }
        HorizontalDivider()
        Text("Jazyk asistenta", fontWeight = FontWeight.SemiBold)
        val languages = listOf("sk-SK" to "Slovenčina", "cs-CZ" to "Čeština", "en-US" to "English", "de-DE" to "Deutsch", "pl-PL" to "Polski", "hu-HU" to "Magyar", "ro-RO" to "Română")
        languages.forEach { (tag, label) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f))
                if (settings.languageTag == tag) Text("Vybraný", color = MaterialTheme.colorScheme.secondary)
                else OutlinedButton(onClick = {
                    when (val result = manager.update(languageTag = tag)) {
                        is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> { settings = result.settings; message = "Jazyk: $label"; onSaved() }
                        is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
                    }
                }) { Text("Vybrať") }
            }
        }
        HorizontalDivider()
        PreferenceSwitch("Hands-free ovládanie", settings.handsFreeEnabled) { value ->
            when (val result = manager.update(handsFreeEnabled = value)) {
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> { settings = result.settings; message = "Nastavenie uložené."; onSaved() }
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
            }
        }
        PreferenceSwitch("Voliteľné oslovenie asistenta", settings.allowOptionalWakeWord) { value ->
            when (val result = manager.update(allowOptionalWakeWord = value)) {
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> { settings = result.settings; message = "Nastavenie uložené."; onSaved() }
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
            }
        }
        PreferenceSwitch("Stručné odpovede", settings.conciseResponses) { value ->
            when (val result = manager.update(conciseResponses = value)) {
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> { settings = result.settings; message = "Nastavenie uložené."; onSaved() }
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
            }
        }
        PreferenceSwitch("Romantický režim (iba na želanie)", settings.romanticModeEnabled) { value ->
            when (val result = manager.update(romanticModeEnabled = value)) {
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Saved -> { settings = result.settings; message = "Nastavenie uložené."; onSaved() }
                is com.oli.routesave.voice.assistant.AssistantSettingsResult.Rejected -> message = result.reason
            }
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.secondary)
        Text(
            "Zapnutie hands-free v nastaveniach samo osebe nespúšťa mikrofón ani neudeľuje oprávnenie. Pred volaním, SMS alebo zdieľaním polohy musí asistent vždy vyžiadať jasné potvrdenie.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun PreferenceSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DetailScreen(title: String, subtitle: String, label1: String, value1: String, label2: String, value2: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        InfoCard(label1, value1)
        InfoCard(label2, value2)
        Text("Tieto údaje sú v tejto fáze ukážkové. V plnej aplikácii sa budú načítavať a ukladať cez dátovú vrstvu.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun MapPlaceholder(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier.background(
            Brush.linearGradient(listOf(Color(0xFF0B3352), Color(0xFF0A2034), Color(0xFF173D4B))),
            RoundedCornerShape(20.dp)
        ).padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Filled.Explore, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
            Text(text, fontWeight = FontWeight.Bold)
            Text("MAPA / GPS – PRIPRAVENÉ NA INTEGRÁCIU", color = Color(0xFFB7C7D8), fontSize = 10.sp)
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        onClick = onClick
    ) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Text(label, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoCard(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun HelpCard(title: String, body: String, location: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body)
            Text("📍 $location", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Ponúknuť pomoc") }
                OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) { Text("Detaily") }
            }
        }
    }
}


@Composable
private fun SmartContinuationScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var origin by rememberSaveable { mutableStateOf("") }
    var destination by rememberSaveable { mutableStateOf("") }
    var passengers by rememberSaveable { mutableStateOf("1") }
    var preference by rememberSaveable { mutableStateOf(JourneyPreference.EARLIEST_ARRIVAL.name) }
    var selectedModes by rememberSaveable {
        mutableStateOf(setOf(
            JourneyLegMode.TRAIN.name, JourneyLegMode.BUS.name, JourneyLegMode.METRO.name,
            JourneyLegMode.TRAM.name, JourneyLegMode.FLIGHT.name, JourneyLegMode.TAXI.name,
            JourneyLegMode.WALK.name
        ))
    }
    var includeCar by rememberSaveable { mutableStateOf(true) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var result by remember { mutableStateOf<JourneySearchResult?>(null) }
    var message by rememberSaveable { mutableStateOf("") }

    fun modeLabel(mode: JourneyLegMode): String = when (mode) {
        JourneyLegMode.CAR -> "Auto"
        JourneyLegMode.WALK -> "Pešo"
        JourneyLegMode.TRAIN -> "Vlak"
        JourneyLegMode.BUS -> "Autobus"
        JourneyLegMode.METRO -> "Metro"
        JourneyLegMode.TRAM -> "Električka"
        JourneyLegMode.FLIGHT -> "Lietadlo"
        JourneyLegMode.TAXI -> "Taxi"
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Späť")
            }
            Spacer(Modifier.width(10.dp))
            Text("Pokračovanie cesty", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "Naplánuj cestu z viacerých úsekov: napríklad autom na stanicu, potom vlakom, autobusom alebo lietadlom a nakoniec pešo či taxíkom.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Trasa", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = origin,
                    onValueChange = { origin = it; result = null; message = "" },
                    label = { Text("Kde pokračuješ? (miesto alebo stanica)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it; result = null; message = "" },
                    label = { Text("Konečný cieľ") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = passengers,
                    onValueChange = { passengers = it; result = null },
                    label = { Text("Počet cestujúcich") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = includeCar, onCheckedChange = { includeCar = it; result = null })
                    Spacer(Modifier.width(8.dp))
                    Text("Povoliť úsek autom")
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Spôsoby dopravy", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Vyber, ktoré možnosti má budúce vyhľadávanie porovnávať.")
                val modes = listOf(
                    JourneyLegMode.TRAIN, JourneyLegMode.BUS, JourneyLegMode.METRO,
                    JourneyLegMode.TRAM, JourneyLegMode.FLIGHT, JourneyLegMode.TAXI, JourneyLegMode.WALK
                )
                modes.chunked(2).forEach { rowModes ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowModes.forEach { mode ->
                            FilterChip(
                                selected = selectedModes.contains(mode.name),
                                onClick = {
                                    selectedModes = if (selectedModes.contains(mode.name)) {
                                        selectedModes - mode.name
                                    } else {
                                        selectedModes + mode.name
                                    }
                                    result = null
                                },
                                label = { Text(modeLabel(mode)) }
                            )
                        }
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Čo je najdôležitejšie?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                listOf(
                    JourneyPreference.EARLIEST_ARRIVAL to "Najskorší príchod",
                    JourneyPreference.CHEAPEST to "Najnižšia cena",
                    JourneyPreference.FASTEST to "Najkratšie trvanie",
                    JourneyPreference.FEWEST_TRANSFERS to "Najmenej prestupov"
                ).forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(
                            selected = preference == value.name,
                            onClick = { preference = value.name; result = null }
                        )
                        Text(label)
                    }
                }
            }
        }
        Button(
            onClick = {
                val count = passengers.toIntOrNull()
                val request = if (count == null) null else JourneySearchRequest(
                    origin = origin.trim(),
                    destination = destination.trim(),
                    passengers = count,
                    modes = selectedModes.mapNotNull { name ->
                        JourneyLegMode.values().firstOrNull { it.name == name }
                    }.toSet(),
                    preference = JourneyPreference.values().firstOrNull { it.name == preference }
                        ?: JourneyPreference.EARLIEST_ARRIVAL,
                    includeCarLeg = includeCar
                )
                val errors = request?.validate() ?: listOf("Zadaj platný počet cestujúcich.")
                if (errors.isNotEmpty()) {
                    message = errors.joinToString(" ")
                    result = null
                } else {
                    searching = true
                    message = ""
                    scope.launch {
                        try {
                            result = JourneySearchService(UnconfiguredJourneySearchProvider()).search(request!!)
                            message = result?.providerMessage.orEmpty()
                        } catch (e: Exception) {
                            result = null
                            message = e.message ?: "Príprava trasy sa nepodarila."
                        } finally {
                            searching = false
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !searching
        ) {
            Icon(Icons.Filled.Search, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (searching) "Pripravujem…" else "Vyhľadať možnosti cesty")
        }
        if (message.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        when (result?.status ?: JourneyDataStatus.UNAVAILABLE) {
                            JourneyDataStatus.LIVE -> "Živé údaje"
                            JourneyDataStatus.CACHED -> "Uložené údaje"
                            JourneyDataStatus.SAMPLE -> "Ukážkové údaje"
                            JourneyDataStatus.UNAVAILABLE -> "Živé vyhľadávanie zatiaľ nie je pripojené"
                        },
                        fontWeight = FontWeight.Bold
                    )
                    Text(message)
                    Text(
                        "Po pripojení dátových služieb bude možné porovnať odchody, príchody, prestupy, cenu, čas a odkazy na rezerváciu.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Text(
            "Ochrana súkromia: v tejto verzii zadávaš miesto ručne. Aplikácia zatiaľ nezískava polohu GPS automaticky a nevytvára rezervácie ani nákupy.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


@Composable
private fun VoiceCompanionScreen(onBack: () -> Unit) {
    var selectedAssistant by rememberSaveable { mutableStateOf(VoiceAssistantId.NIKOLAS.name) }
    var sampleCommand by rememberSaveable { mutableStateOf("Niko, vypočítaj cenu cesty do Bratislavy") }
    var feedback by rememberSaveable { mutableStateOf("") }
    var lastRequiresConfirmation by rememberSaveable { mutableStateOf(false) }

    val assistant = VoiceAssistantId.values().firstOrNull { it.name == selectedAssistant }
        ?: VoiceAssistantId.NIKOLAS

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Späť")
            }
            Spacer(Modifier.width(10.dp))
            Text("Hlasový spolujazdec", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "Príprava ovládania bez rúk. Vyber si asistenta a vyskúšaj textový príklad príkazu.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Vybraný asistent", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                VoiceAssistantId.values().toList().chunked(2).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowItems.forEach { item ->
                            FilterChip(
                                selected = selectedAssistant == item.name,
                                onClick = {
                                    selectedAssistant = item.name
                                    sampleCommand = "${item.invocation}, vypočítaj cenu cesty do Bratislavy"
                                    feedback = ""
                                },
                                label = { Text("${item.displayName} (${item.invocation})") }
                            )
                        }
                    }
                }
                Text(
                    "Príklad oslovenia: ${assistant.invocation}. Názov aplikácie OLI RouteSave zostáva nezmenený.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Vyskúšaj príkaz", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = sampleCommand,
                    onValueChange = { sampleCommand = it; feedback = "" },
                    label = { Text("Text hlasového príkazu") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val normalized = sampleCommand.trim()
                        if (!VoiceCommandPolicy.invocationMatches(normalized, assistant)) {
                            feedback = "Príkaz sa nezačína oslovením ${assistant.invocation}. Uprav ho a skús znova."
                            lastRequiresConfirmation = false
                        } else {
                            val intent = when {
                                normalized.contains("zavolaj", ignoreCase = true) -> VoiceIntent.CALL_CONTACT
                                normalized.contains("správu", ignoreCase = true) ||
                                    normalized.contains("sms", ignoreCase = true) -> VoiceIntent.SEND_MESSAGE
                                normalized.contains("polohu", ignoreCase = true) -> VoiceIntent.SHARE_LOCATION
                                normalized.contains("lístok", ignoreCase = true) ||
                                    normalized.contains("listok", ignoreCase = true) -> VoiceIntent.PURCHASE_TICKET
                                normalized.contains("rezerv", ignoreCase = true) -> VoiceIntent.OPEN_BOOKING
                                normalized.contains("spoj", ignoreCase = true) -> VoiceIntent.SEARCH_TRANSIT
                                normalized.contains("cenu", ignoreCase = true) ||
                                    normalized.contains("náklady", ignoreCase = true) -> VoiceIntent.CALCULATE_TRIP_COST
                                else -> VoiceIntent.SET_DESTINATION
                            }
                            lastRequiresConfirmation = VoiceCommandPolicy.requiresConfirmation(intent)
                            feedback = if (lastRequiresConfirmation) {
                                "Rozpoznaný typ: $intent. Asistent sa musí najprv opýtať: „Mám vykonať túto akciu?“ Ak používateľ jasne nepotvrdí, akcia sa nesmie vykonať."
                            } else {
                                "Príklad príkazu je rozpoznaný ako $intent. Toto je len ukážka textového spracovania, nie skutočné hlasové rozpoznávanie."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Skontrolovať príkaz") }
                if (feedback.isNotBlank()) {
                    Text(feedback)
                }
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Stav funkcie", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Táto verzia pripravuje modely príkazov, vlastné oslovenia asistentov a pravidlá potvrdenia.")
                Text("Mikrofón, nepretržité počúvanie, Android SpeechRecognizer, TTS, hovory, SMS a skutočné vykonávanie príkazov ešte nie sú pripojené.")
                Text("Pri telefonáte, správe, zdieľaní polohy, otvorení rezervácie alebo nákupe lístka musí vybraný asistent vždy najprv požiadať o jasné potvrdenie.")
                Text("Hlasové ovládanie má byť navrhnuté tak, aby sa vodič nemusel pozerať na displej počas jazdy.")
            }
        }
    }
}


@Composable
private fun VoiceControlScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var voiceState by remember { mutableStateOf(VoiceInteractionState()) }
    var isReady by remember { mutableStateOf(false) }
    var session by remember { mutableStateOf<AndroidVoiceSession?>(null) }

    DisposableEffect(context) {
        val coordinator = VoiceInteractionCoordinator()
        val newSession = AndroidVoiceSession(context, coordinator) { state ->
            voiceState = state
        }
        session = newSession
        isReady = newSession.isSpeechRecognitionAvailable()
        onDispose {
            newSession.close()
            session = null
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            session?.startListening()
        } else {
            voiceState = voiceState.copy(
                listening = false,
                statusMessage = "Mikrofón nebol povolený",
                replyText = "Na hlasové ovládanie potrebuješ povoliť mikrofón."
            )
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Späť")
            }
            Spacer(Modifier.width(10.dp))
            Text("Ovládanie hlasom", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Hlasový spolujazdec", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Stav: ${voiceState.statusMessage}")
                Text("Asistent: ${voiceState.assistant.displayName} (${voiceState.assistant.invocation})")
                Text(
                    if (isReady) "Rozpoznávanie reči je dostupné v zariadení."
                    else "Rozpoznávanie reči nie je dostupné alebo ho systém nevie potvrdiť."
                )
                Button(
                    onClick = {
                        val hasPermission = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPermission) {
                            session?.startListening()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !voiceState.listening && session != null
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Začať počúvať")
                }
                OutlinedButton(
                    onClick = { session?.stopListening() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = voiceState.listening && session != null
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Zastaviť počúvanie")
                }
                OutlinedButton(
                    onClick = { session?.stopSpeaking() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = session != null
                ) {
                    Icon(Icons.Filled.VolumeOff, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Zastaviť hlasovú odpoveď")
                }
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Čo asistent počul", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(voiceState.lastRecognizedText.ifBlank { "Zatiaľ nebol rozpoznaný žiadny príkaz." })
                Text("Odpoveď asistenta", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(voiceState.replyText.ifBlank { "Odpoveď sa zobrazí po rozpoznaní príkazu." })
                if (voiceState.awaitingConfirmation != null) {
                    Text(
                        "Čaká sa na potvrdenie: ${voiceState.awaitingConfirmation?.summary}",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                    Text("V tejto verzii sa potvrdenie zobrazuje v stave; vykonávanie externých akcií nie je pripojené.")
                }
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Príklady", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("„Niko, vypočítaj cenu cesty do Bratislavy“")
                Text("„Naty, vyhľadaj vlak do Viedne“")
                Text("„Vany, zavolaj Jánovi“")
                Text(
                    "Počúvanie sa spúšťa tlačidlom a po rozpoznaní príkazu sa zastaví. Aplikácia nepočúva nepretržite na pozadí.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Toto je prvé prepojenie UI s Android hlasovými adaptérmi. Funkčnosť závisí od podpory reči a hlasu v telefóne; celý tok ešte nebol zostavený ani otestovaný.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}


@Composable
private fun VoiceConfirmationScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coordinator = remember { VoiceConfirmationCoordinator() }
    var uiState by remember { mutableStateOf(coordinator.current) }
    var answer by rememberSaveable { mutableStateOf("") }
    var confirmationSession by remember { mutableStateOf<AndroidVoiceConfirmationSession?>(null) }
    var micPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    DisposableEffect(context) {
        val liveSession = AndroidVoiceConfirmationSession(context, coordinator) { state ->
            uiState = state
        }
        confirmationSession = liveSession
        onDispose {
            liveSession.close()
            confirmationSession = null
        }
    }
    val confirmationMicLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        micPermissionGranted = granted
        if (granted) confirmationSession?.startListeningForAnswer()
        else uiState = uiState.copy(message = "Mikrofón nebol povolený; akcia zostáva nevykonaná.")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Späť")
            }
            Spacer(Modifier.width(10.dp))
            Text("Potvrdenie hlasom", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "Ukážka bezpečného toku pred telefonátom, odoslaním správy, zdieľaním polohy alebo nákupom lístka.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Vytvoriť ukážkovú akciu", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        val action = VoiceCommandPolicy.createConfirmationPrompt(
                            intent = VoiceIntent.CALL_CONTACT,
                            assistant = VoiceAssistantId.NIKOLAS,
                            summary = "zavolať vybranému kontaktu"
                        )
                        if (confirmationSession != null) {
                            confirmationSession?.ask(action)
                        } else {
                            uiState = coordinator.requestConfirmation(action)
                        }
                        answer = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Ukážka: telefonát") }
                Button(
                    onClick = {
                        val action = VoiceCommandPolicy.createConfirmationPrompt(
                            intent = VoiceIntent.SHARE_LOCATION,
                            assistant = VoiceAssistantId.NATALIA,
                            summary = "zdieľať aktuálnu polohu"
                        )
                        if (confirmationSession != null) {
                            confirmationSession?.ask(action)
                        } else {
                            uiState = coordinator.requestConfirmation(action)
                        }
                        answer = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Ukážka: zdieľanie polohy") }
                Button(
                    onClick = {
                        val action = VoiceCommandPolicy.createConfirmationPrompt(
                            intent = VoiceIntent.PURCHASE_TICKET,
                            assistant = VoiceAssistantId.VANESA,
                            summary = "pokračovať k nákupu lístka"
                        )
                        if (confirmationSession != null) {
                            confirmationSession?.ask(action)
                        } else {
                            uiState = coordinator.requestConfirmation(action)
                        }
                        answer = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Ukážka: nákup lístka") }
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Otázka asistenta", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(uiState.prompt.ifBlank { "Zatiaľ nie je pripravená žiadna otázka." })
                Text("Stav: ${uiState.state}")
                Text(uiState.message)
                if (uiState.pendingAction != null) {
                    Button(
                        onClick = {
                            if (micPermissionGranted) {
                                confirmationSession?.startListeningForAnswer()
                            } else {
                                confirmationMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = confirmationSession != null
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Odpovedať hlasom")
                    }
                    OutlinedButton(
                        onClick = { confirmationSession?.stopListening() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = confirmationSession != null
                    ) { Text("Zastaviť počúvanie odpovede") }
                    OutlinedTextField(
                        value = answer,
                        onValueChange = { answer = it },
                        label = { Text("Simulovaná odpoveď (áno / nie)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            uiState = coordinator.receiveAnswer(answer, 1.0f)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Vyhodnotiť odpoveď") }
                    OutlinedButton(
                        onClick = {
                            uiState = coordinator.receiveAnswer(answer, 0.4f)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Simulovať nejasnú odpoveď") }
                }
                if (uiState.state == ConfirmationUiState.CONFIRMED) {
                    Text(
                        "Potvrdené neznamená automaticky vykonané. V tejto verzii sa nevykonáva žiadny telefonát, nákup ani zdieľanie.",
                        color = MaterialTheme.colorScheme.error
                    )
                }
                OutlinedButton(
                    onClick = { uiState = coordinator.clear(); answer = "" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Zrušiť / vyčistiť") }
            }
        }
        Text(
            "Hlasovú odpoveď môžeš skúsiť cez mikrofón; textové pole zostáva ako záložná ukážka. Externé akcie sa ani po potvrdení nevykonávajú.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

