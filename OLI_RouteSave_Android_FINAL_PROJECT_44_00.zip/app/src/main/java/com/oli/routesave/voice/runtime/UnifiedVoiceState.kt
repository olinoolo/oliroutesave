package com.oli.routesave.voice.runtime

enum class UnifiedVoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    WAITING_CONFIRMATION,
    INTERRUPTED,
    PAUSED,
    ENDED
}
