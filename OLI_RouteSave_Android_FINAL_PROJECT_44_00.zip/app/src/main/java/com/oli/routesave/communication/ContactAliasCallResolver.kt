package com.oli.routesave.communication

/**
 * Resolves a spoken recipient using saved contact aliases before falling back
 * to the regular contacts resolver.
 *
 * This class only prepares a destination. It never starts a call and never
 * treats a successful match as user consent.
 */
class ContactAliasCallResolver(
    private val aliasRepository: ContactAliasRepository,
    private val contactsResolver: ContactNameResolver
) {
    suspend fun resolve(spokenRecipient: String): RecipientResolution {
        val cleaned = normalize(spokenRecipient)
        if (cleaned.isEmpty()) return RecipientResolution.InvalidInput

        val alias = aliasRepository.findByAlias(cleaned)
        if (alias != null) {
            return RecipientResolution.Resolved(
                contactId = alias.contactId,
                displayName = alias.displayName,
                matchedByAlias = true
            )
        }

        return when (val result = contactsResolver.resolve(cleaned)) {
            is ContactNameResolution.Found -> RecipientResolution.Resolved(
                contactId = result.contactId,
                displayName = result.displayName,
                matchedByAlias = false
            )
            ContactNameResolution.NotFound -> RecipientResolution.NotFound(cleaned)
            is ContactNameResolution.Ambiguous -> RecipientResolution.Ambiguous(
                query = cleaned,
                candidates = result.candidates
            )
            ContactNameResolution.PermissionRequired -> RecipientResolution.PermissionRequired
        }
    }

    private fun normalize(value: String): String =
        value.trim().replace(WHITESPACE, " ").lowercase()

    private companion object {
        val WHITESPACE = Regex("\\s+")
    }
}

interface ContactNameResolver {
    suspend fun resolve(query: String): ContactNameResolution
}

sealed interface ContactNameResolution {
    data class Found(val contactId: String, val displayName: String) : ContactNameResolution
    data object NotFound : ContactNameResolution
    data class Ambiguous(val candidates: List<ContactCandidate>) : ContactNameResolution
    data object PermissionRequired : ContactNameResolution
}

data class ContactCandidate(
    val contactId: String,
    val displayName: String
)

sealed interface RecipientResolution {
    data class Resolved(
        val contactId: String,
        val displayName: String,
        val matchedByAlias: Boolean
    ) : RecipientResolution

    data class NotFound(val query: String) : RecipientResolution
    data class Ambiguous(val query: String, val candidates: List<ContactCandidate>) : RecipientResolution
    data object PermissionRequired : RecipientResolution
    data object InvalidInput : RecipientResolution
}
