# OLI RouteSave 12.0 — Travel and savings foundation

## Included
- Vehicle profile with average fuel consumption in l/100 km.
- Per-trip consumption override.
- Estimated fuel litres and fuel cost based on trip distance, consumption and fuel price.
- Additional toll, parking and other costs included in total.
- Validation of invalid distances, consumption and costs.
- Comparison models for car, train, bus and plane.
- Provider interface for future train/bus/flight live searches. Missing providers are clearly marked as not connected; no fake live ticket prices are shown.

## Not yet connected
- No routing/geocoding provider is configured in this block.
- No current fuel-price, toll, parking, train, bus or flight API is connected.
- Trip distance must currently be supplied by the caller.
- Currency conversion, booking and ticket purchase are not implemented.
- UI integration and persistent vehicle profile storage are still needed.

## Example
For 600 km, 6.0 l/100 km and €1.70/l, estimated fuel use is 36 litres and fuel cost is €61.20 before toll, parking and other costs. A per-trip override takes precedence over the saved vehicle profile.

## Accuracy
All costs are estimates based on supplied inputs. Live prices must be obtained from an actual connected provider and identified with a source and timestamp.
