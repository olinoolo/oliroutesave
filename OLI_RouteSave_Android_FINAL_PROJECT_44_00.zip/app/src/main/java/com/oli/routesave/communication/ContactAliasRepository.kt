package com.oli.routesave.communication

/** Durable-storage boundary; production implementation should use Room/DataStore. */
interface ContactAliasRepository : ContactAliasStore {
    suspend fun allAliases(): List<ContactAlias>
}

/** In-memory fallback for tests/previews only; not durable across restarts. */
class InMemoryContactAliasRepository : ContactAliasRepository {
    private val aliases = linkedMapOf<String, ContactAlias>()
    override suspend fun find(alias: String): ContactAlias? = aliases[key(alias)]
    override suspend fun save(alias: ContactAlias) {
        val normalized = key(alias.alias)
        require(normalized.isNotBlank()) { "Alias nesmie byť prázdny." }
        aliases[normalized] = alias.copy(alias = alias.alias.trim())
    }
    override suspend fun remove(alias: String) { aliases.remove(key(alias)) }
    override suspend fun allAliases(): List<ContactAlias> = aliases.values.toList()
    private fun key(value: String) = value.trim().lowercase().replace(Regex("\\s+"), " ")
}
