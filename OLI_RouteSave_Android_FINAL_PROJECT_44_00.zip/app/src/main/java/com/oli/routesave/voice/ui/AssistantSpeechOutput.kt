package com.oli.routesave.voice.ui

/**
 * Small UI-facing contract. Android TTS implementation is injected separately.
 */
interface AssistantSpeechOutput {
    fun speak(text: String, languageTag: String)
    fun stop()
}
