package com.oli.routesave.presentation

data class VehicleScreenSpec(
    val title: String = "Profil vozidla",
    val name: String = "",
    val brand: String = "",
    val model: String = "",
    val fuelType: String = "",
    val consumptionL100Km: String = "",
    val fuelPricePerLiter: String = "",
    val saveLabel: String = "Uložiť vozidlo"
)
