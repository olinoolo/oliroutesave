package com.oli.routesave.android.runtime
class PermissionController(private val checker:PermissionChecker){
 fun state()=DrivePermissionState(
  fineLocation=checker.isGranted(AndroidPermission.LOCATION_FINE),
  coarseLocation=checker.isGranted(AndroidPermission.LOCATION_COARSE),
  microphone=checker.isGranted(AndroidPermission.MICROPHONE),
  notification=checker.isGranted(AndroidPermission.NOTIFICATION),
  phone=checker.isGranted(AndroidPermission.PHONE),
  contacts=checker.isGranted(AndroidPermission.CONTACTS))
 fun canStartDrive()=state().canStartNavigation
 fun canUseVoice()=state().canStartVoice
 fun canUseCalling()=state().canUseCalling
}
interface PermissionChecker{fun isGranted(permission:AndroidPermission):Boolean}
