package com.oli.routesave.voice.runtime

class UnifiedVoiceResponseFormatter {

    fun greeting(context: UnifiedVoiceContext): String =
        if (context.personalAddress.isNullOrBlank()) {
            "${context.assistantName} je pripravený."
        } else {
            "${context.assistantName} je pripravený, ${context.personalAddress}."
        }

    fun confirmationQuestion(
        context: UnifiedVoiceContext,
        actionDescription: String
    ): String =
        "${context.assistantName}: Chceš, aby som $actionDescription?"

    fun clarification(context: UnifiedVoiceContext): String =
        "${context.assistantName}: Nie som si istý, čo tým myslíš. Môžeš to prosím upresniť?"
}
