package com.oli.routesave.communication

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.os.Build

/**
 * Android ContactsContract adapter.
 *
 * The caller must request READ_CONTACTS at runtime before invoking lookup.
 * The adapter never initiates a call and does not log names or phone numbers.
 */
class AndroidContactsGatewayImpl(
    private val context: Context
) : AndroidContactsGateway {

    private val resolver: ContentResolver
        get() = context.contentResolver

    override fun permissionState(): ContactPermissionState {
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        return if (granted) ContactPermissionState.GRANTED else ContactPermissionState.NOT_GRANTED
    }

    override suspend fun searchByNameOrNickname(query: String): ContactLookupOutcome {
        if (permissionState() != ContactPermissionState.GRANTED) {
            return ContactLookupOutcome.PermissionRequired
        }
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) return ContactLookupOutcome.NoMatch

        val uri = Uri.withAppendedPath(
            ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
            Uri.encode(cleanQuery)
        )
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL
        )

        val contacts = linkedMapOf<String, ContactCandidate>()
        try {
            resolver.query(uri, projection, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")
                .useCursor { cursor ->
                    if (cursor != null) {
                        val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                        val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                        val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        val normalizedIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER)
                        val typeIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
                        val labelIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LABEL)

                        while (cursor.moveToNext()) {
                            val id = cursor.getString(idIdx) ?: continue
                            val name = cursor.getString(nameIdx)?.trim().orEmpty()
                            val number = cursor.getString(numberIdx)?.trim().orEmpty()
                            if (name.isBlank() || number.isBlank()) continue
                            val normalized = if (normalizedIdx >= 0) cursor.getString(normalizedIdx) else null
                            val type = if (typeIdx >= 0) cursor.getInt(typeIdx) else ContactsContract.CommonDataKinds.Phone.TYPE_OTHER
                            val customLabel = if (labelIdx >= 0) cursor.getString(labelIdx) else null
                            val label = customLabel?.takeIf { it.isNotBlank() }
                                ?: ContactsContract.CommonDataKinds.Phone.getTypeLabel(context.resources, type, customLabel).toString()

                            val phone = ContactPhoneNumber(label, number, normalized)
                            val old = contacts[id]
                            contacts[id] = if (old == null) {
                                ContactCandidate(id, name, listOf(phone))
                            } else if (old.phoneNumbers.none { it.number == number }) {
                                old.copy(phoneNumbers = old.phoneNumbers + phone)
                            } else old
                        }
                    }
                }
        } catch (security: SecurityException) {
            return ContactLookupOutcome.PermissionRequired
        } catch (exception: Exception) {
            return ContactLookupOutcome.Failed("Kontakty sa nepodarilo načítať.")
        }

        return if (contacts.isEmpty()) ContactLookupOutcome.NoMatch
        else ContactLookupOutcome.Found(contacts.values.toList())
    }

    override suspend fun getPhoneNumbers(contactId: String): ContactLookupOutcome {
        if (permissionState() != ContactPermissionState.GRANTED) {
            return ContactLookupOutcome.PermissionRequired
        }
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL
        )
        val phones = mutableListOf<ContactPhoneNumber>()
        var name = ""
        try {
            resolver.query(
                uri,
                projection,
                "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                arrayOf(contactId),
                null
            ).useCursor { cursor ->
                if (cursor != null) {
                    val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val normalizedIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER)
                    val typeIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
                    val labelIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LABEL)
                    while (cursor.moveToNext()) {
                        name = cursor.getString(nameIdx)?.trim().orEmpty()
                        val number = cursor.getString(numberIdx)?.trim().orEmpty()
                        if (number.isBlank()) continue
                        val normalized = if (normalizedIdx >= 0) cursor.getString(normalizedIdx) else null
                        val type = if (typeIdx >= 0) cursor.getInt(typeIdx) else ContactsContract.CommonDataKinds.Phone.TYPE_OTHER
                        val customLabel = if (labelIdx >= 0) cursor.getString(labelIdx) else null
                        val label = customLabel?.takeIf { it.isNotBlank() }
                            ?: ContactsContract.CommonDataKinds.Phone.getTypeLabel(context.resources, type, customLabel).toString()
                        val phone = ContactPhoneNumber(label, number, normalized)
                        if (phones.none { it.number == phone.number }) phones += phone
                    }
                }
            }
        } catch (security: SecurityException) {
            return ContactLookupOutcome.PermissionRequired
        } catch (exception: Exception) {
            return ContactLookupOutcome.Failed("Čísla kontaktu sa nepodarilo načítať.")
        }
        if (phones.isEmpty()) return ContactLookupOutcome.NoMatch
        return ContactLookupOutcome.Found(listOf(ContactCandidate(contactId, name, phones)))
    }

    private inline fun <T> Cursor?.useCursor(block: (Cursor?) -> T): T {
        if (this == null) return block(null)
        return use { block(it) }
    }
}
