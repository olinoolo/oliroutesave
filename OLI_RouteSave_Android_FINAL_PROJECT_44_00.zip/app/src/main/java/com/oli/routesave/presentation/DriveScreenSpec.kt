package com.oli.routesave.presentation

data class DriveScreenSpec(
    val mapVisible: Boolean = true,
    val assistantName: String,
    val destination: String,
    val eta: String,
    val remainingDistance: String,
    val primaryAction: String
)
