package com.oli.routesave.communication

/**
 * Provider abstraction for external communication apps.
 * A provider should only be called after CommunicationConfirmationResult.Confirmed
 * and must report whether the requested capability is actually available.
 */
data class CommunicationCapability(
    val channel: CommunicationChannel,
    val audioCall: Boolean,
    val videoCall: Boolean,
    val textMessage: Boolean,
    val explanation: String? = null
)

sealed interface CommunicationLaunchResult {
    data object Launched : CommunicationLaunchResult
    data class Unavailable(val explanation: String) : CommunicationLaunchResult
    data class Failed(val explanation: String) : CommunicationLaunchResult
}

interface CommunicationProvider {
    fun capability(): CommunicationCapability
    fun launchConfirmed(request: CommunicationRequest): CommunicationLaunchResult
}

/**
 * Safe dispatcher: rejects unconfirmed or mismatched requests. Actual Android
 * intents and third-party integrations belong in platform-specific providers.
 */
class ConfirmedCommunicationDispatcher(
    private val providers: Map<CommunicationChannel, CommunicationProvider>
) {
    fun dispatch(
        result: CommunicationConfirmationResult,
        expectedRequest: CommunicationRequest
    ): CommunicationLaunchResult {
        val confirmed = result as? CommunicationConfirmationResult.Confirmed
            ?: return CommunicationLaunchResult.Failed("Akcia nebola potvrdená.")
        if (confirmed.request != expectedRequest) {
            return CommunicationLaunchResult.Failed("Potvrdená požiadavka sa nezhoduje s požiadavkou na spustenie.")
        }
        val provider = providers[confirmed.request.channel]
            ?: return CommunicationLaunchResult.Unavailable("Pre tento komunikačný kanál nie je dostupný poskytovateľ.")
        val capability = provider.capability()
        val supported = when (confirmed.request.mode) {
            CommunicationMode.AUDIO_CALL -> capability.audioCall
            CommunicationMode.VIDEO_CALL -> capability.videoCall
            CommunicationMode.TEXT_MESSAGE -> capability.textMessage
        }
        if (!supported) {
            return CommunicationLaunchResult.Unavailable(
                capability.explanation ?: "Tento spôsob komunikácie nie je podporovaný."
            )
        }
        return provider.launchConfirmed(confirmed.request)
    }
}
