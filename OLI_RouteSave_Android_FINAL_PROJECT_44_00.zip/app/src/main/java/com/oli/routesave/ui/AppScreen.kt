package com.oli.routesave.ui

enum class AppScreen {
    HOME,
    ROUTE,
    VEHICLE,
    ASSISTANT,
    COMMUNITY,
    TRIP_HISTORY,
    SETTINGS
}
