package com.oli.routesave.android.runtime

sealed interface DriveRuntimeEvent {
    data object Start : DriveRuntimeEvent
    data object Pause : DriveRuntimeEvent
    data object Resume : DriveRuntimeEvent
    data object Stop : DriveRuntimeEvent
    data class Error(val message: String) : DriveRuntimeEvent
}
