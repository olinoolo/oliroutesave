package com.oli.routesave.presentation

import com.oli.routesave.data.model.VehicleProfile
import com.oli.routesave.data.persistence.VehicleRepository

/**
 * UI-facing controller. Compose or another UI can observe the returned
 * state/results and render validation messages without touching storage.
 */
class VehicleProfileScreenController(
    private val repository: VehicleRepository
) {
    fun loadVehicles(): List<VehicleProfile> = repository.all()

    fun loadDefaultVehicle(): VehicleProfile? = repository.defaultVehicle()

    fun save(form: VehicleProfileFormState): VehicleSaveResult {
        return when (val conversion = form.toVehicleProfile()) {
            is VehicleFormResult.Invalid -> VehicleSaveResult.Invalid(conversion.errors)
            is VehicleFormResult.Valid -> {
                repository.save(conversion.vehicle)
                VehicleSaveResult.Saved(conversion.vehicle)
            }
        }
    }

    fun delete(vehicleId: String): VehicleSaveResult {
        if (vehicleId.isBlank()) {
            return VehicleSaveResult.Invalid(listOf("Chýba ID vozidla."))
        }
        repository.delete(vehicleId)
        return VehicleSaveResult.Deleted(vehicleId)
    }
}

sealed interface VehicleSaveResult {
    data class Saved(val vehicle: VehicleProfile) : VehicleSaveResult
    data class Deleted(val vehicleId: String) : VehicleSaveResult
    data class Invalid(val errors: List<String>) : VehicleSaveResult
}
