package com.oli.routesave.voice.assistant

import com.oli.routesave.voice.android.VoiceInputOutputListener
import com.oli.routesave.voice.android.VoiceInputProvider
import com.oli.routesave.voice.android.VoiceInputState
import com.oli.routesave.voice.android.VoiceOutputProvider
import com.oli.routesave.voice.android.VoiceRecognitionResult

/**
 * Connects recognition callbacks to the assistant coordinator and speech output.
 *
 * This is an orchestration layer, not a background always-on wake-word engine.
 * The host app must explicitly start/stop listening and handle Android runtime
 * permissions. External actions are emitted to the host and never executed here.
 */
class VoiceAssistantSessionCoordinator(
    private val settings: VoiceAssistantSettingsManager,
    private val assistantCoordinator: VoiceAssistantCoordinator,
    private val input: VoiceInputProvider,
    private val output: VoiceOutputProvider,
    private val listener: SessionListener
) : VoiceInputOutputListener {

    private var listening = false
    private var released = false
    private var awaitingExternalConfirmation = false

    fun startListening() {
        if (released) return
        val profile = settings.selectedAssistant()
        listening = true
        input.startListening(profile.languageTag)
        listener.onListeningChanged(true)
    }

    fun stopListening() {
        if (released) return
        listening = false
        input.stopListening()
        listener.onListeningChanged(false)
    }

    fun cancelPendingAction() {
        awaitingExternalConfirmation = false
        assistantCoordinator.cancelPendingAction()
        output.stop()
        listener.onPendingConfirmationChanged(false)
    }

    override fun onInputStateChanged(state: VoiceInputState) {
        if (!released) listener.onInputStateChanged(state)
    }

    override fun onRecognition(result: VoiceRecognitionResult) {
        if (released) return
        val profile = settings.selectedAssistant()
        val spoken = result.text.trim()
        if (spoken.isEmpty()) {
            listener.onAssistantOutcome(
                AssistantOutcome.NeedsClarification(
                    "Nerozumel som. Skús to, prosím, ešte raz.",
                    profile.languageTag
                )
            )
            return
        }

        val outcome = if (awaitingExternalConfirmation) {
            when (normalize(spoken)) {
                "ano", "ano prosim", "potvrdzujem" -> {
                    awaitingExternalConfirmation = false
                    listener.onPendingConfirmationChanged(false)
                    assistantCoordinator.confirmExternalAction(true, profile)
                }
                "nie", "nie dakujem", "zrus", "zrus to" -> {
                    awaitingExternalConfirmation = false
                    listener.onPendingConfirmationChanged(false)
                    assistantCoordinator.confirmExternalAction(false, profile)
                }
                else -> AssistantOutcome.NeedsClarification(
                    "${profile.invocationName}: Potrebujem jasné áno alebo nie. Zatiaľ nič nevykonám.",
                    profile.languageTag
                )
            }
        } else {
            assistantCoordinator.handleSpeech(spoken, profile)
        }

        when (outcome) {
            is AssistantOutcome.AwaitingConfirmation -> {
                awaitingExternalConfirmation = true
                listener.onPendingConfirmationChanged(true)
                output.speak(outcome.prompt, outcome.languageTag)
            }
            is AssistantOutcome.Speak ->
                output.speak(outcome.text, outcome.languageTag)
            is AssistantOutcome.NeedsClarification ->
                output.speak(outcome.text, outcome.languageTag)
            is AssistantOutcome.RouteRequested,
            is AssistantOutcome.FuelEstimateRequested,
            is AssistantOutcome.ExternalActionApproved,
            AssistantOutcome.NoPendingConfirmation -> Unit
        }
        listener.onAssistantOutcome(outcome)
    }

    override fun onInputError(message: String) {
        if (!released) listener.onInputError(message)
    }

    fun release() {
        if (released) return
        stopListening()
        cancelPendingAction()
        released = true
        input.release()
        output.release()
    }

    private fun normalize(value: String): String =
        java.text.Normalizer.normalize(value.trim().lowercase(), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("[.!?,;:]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
}

interface SessionListener {
    fun onListeningChanged(listening: Boolean)
    fun onInputStateChanged(state: VoiceInputState)
    fun onInputError(message: String)
    fun onPendingConfirmationChanged(pending: Boolean)
    fun onAssistantOutcome(outcome: AssistantOutcome)
}
