package com.oli.routesave.data.store

import com.oli.routesave.data.model.TripRecord

interface TripStore {
    fun save(trip: TripRecord)
    fun get(id: String): TripRecord?
    fun getRecent(limit: Int = 20): List<TripRecord>
    fun delete(id: String)
}
