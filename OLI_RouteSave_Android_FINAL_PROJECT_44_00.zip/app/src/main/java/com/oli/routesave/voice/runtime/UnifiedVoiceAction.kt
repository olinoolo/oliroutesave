package com.oli.routesave.voice.runtime

data class UnifiedVoiceAction(
    val description: String,
    val confirmation: UnifiedVoiceConfirmation,
    val external: Boolean
)
