package com.oli.routesave.voice.android

/**
 * Provider-neutral voice input/output contracts.
 * Android-specific implementations live in the adapter classes.
 */
enum class VoiceInputState {
    IDLE, LISTENING, PROCESSING, ERROR
}

data class VoiceRecognitionResult(
    val text: String,
    val confidence: Float? = null,
    val languageTag: String = "sk-SK"
)

interface VoiceInputOutputListener {
    fun onInputStateChanged(state: VoiceInputState)
    fun onRecognition(result: VoiceRecognitionResult)
    fun onInputError(message: String)
}

interface VoiceInputProvider {
    fun startListening(languageTag: String = "sk-SK")
    fun stopListening()
    fun release()
}

interface VoiceOutputProvider {
    fun speak(text: String, languageTag: String = "sk-SK")
    fun stop()
    fun release()
}
