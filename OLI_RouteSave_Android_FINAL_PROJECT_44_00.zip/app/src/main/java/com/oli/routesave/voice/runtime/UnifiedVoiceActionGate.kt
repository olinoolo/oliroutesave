package com.oli.routesave.voice.runtime

class UnifiedVoiceActionGate {

    fun canExecute(action: UnifiedVoiceAction): Boolean {
        if (!action.external) return true

        return action.confirmation == UnifiedVoiceConfirmation.CONFIRMED
    }
}
