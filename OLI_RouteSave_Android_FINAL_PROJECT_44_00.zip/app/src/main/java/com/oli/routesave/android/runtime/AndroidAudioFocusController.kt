package com.oli.routesave.android.runtime
class AndroidAudioFocusController(private val delegate:AudioFocusDelegate):AudioFocusController{
 override fun request(){delegate.requestNavigationFocus()}
 override fun abandon(){delegate.abandonFocus()}
}
interface AudioFocusDelegate{fun requestNavigationFocus();fun abandonFocus()}
