package com.oli.routesave.messaging

enum class ReplyState {
    IDLE, DRAFT_READY, WAITING_FOR_CONFIRMATION, SENT, CANCELLED, UNAVAILABLE
}

data class ReplyPrompt(
    val recipientLabel: String,
    val text: String,
    val spokenPrompt: String
)

/**
 * Confirmation-first message reply flow. No provider is called until the
 * user explicitly confirms the final recipient and text.
 */
class VoiceMessageReplyCoordinator(
    private val provider: NotificationReplyProvider
) {
    var state: ReplyState = ReplyState.IDLE
        private set
    private var pending: PreparedMessageReply? = null

    fun prepareReply(
        notificationKey: String,
        packageName: String,
        recipientLabel: String,
        dictatedText: String
    ): ReplyPrompt? {
        val cleanText = dictatedText.trim()
        if (cleanText.isBlank()) return null
        if (!provider.canReply(notificationKey)) {
            state = ReplyState.UNAVAILABLE
            pending = null
            return null
        }
        pending = PreparedMessageReply(notificationKey, packageName, recipientLabel, cleanText)
        state = ReplyState.WAITING_FOR_CONFIRMATION
        return ReplyPrompt(
            recipientLabel = recipientLabel,
            text = cleanText,
            spokenPrompt = "Odpovedať kontaktu $recipientLabel správou: $cleanText. Mám ju odoslať?"
        )
    }

    fun confirm(yes: Boolean): MessageReplyResult? {
        val reply = pending ?: return null
        pending = null
        if (!yes) {
            state = ReplyState.CANCELLED
            return MessageReplyResult.Unavailable("Používateľ zrušil odoslanie.")
        }
        val result = provider.sendConfirmedReply(reply)
        state = if (result == MessageReplyResult.Sent) ReplyState.SENT else ReplyState.UNAVAILABLE
        return result
    }

    fun cancel() {
        pending = null
        state = ReplyState.CANCELLED
    }
}
