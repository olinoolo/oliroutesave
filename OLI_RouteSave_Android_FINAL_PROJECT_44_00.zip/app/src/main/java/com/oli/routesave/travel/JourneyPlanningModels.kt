package com.oli.routesave.travel

/**
 * Domain model for planning a journey made of multiple transport legs.
 * This model does not imply that a live data provider is connected.
 */
enum class JourneyLegMode {
    CAR, WALK, TRAIN, BUS, METRO, TRAM, FLIGHT, TAXI
}

enum class JourneyPreference {
    EARLIEST_ARRIVAL, CHEAPEST, FASTEST, FEWEST_TRANSFERS
}

enum class JourneyDataStatus {
    LIVE, CACHED, SAMPLE, UNAVAILABLE
}

data class JourneySearchRequest(
    val origin: String,
    val destination: String,
    val passengers: Int = 1,
    val modes: Set<JourneyLegMode> = setOf(
        JourneyLegMode.TRAIN, JourneyLegMode.BUS, JourneyLegMode.METRO,
        JourneyLegMode.TRAM, JourneyLegMode.FLIGHT, JourneyLegMode.TAXI, JourneyLegMode.WALK
    ),
    val preference: JourneyPreference = JourneyPreference.EARLIEST_ARRIVAL,
    val includeCarLeg: Boolean = true,
    val useCurrentLocation: Boolean = false
) {
    fun validate(): List<String> = buildList {
        if (origin.isBlank()) add("Zadaj miesto, kde sa cesta začína alebo pokračuje.")
        if (destination.isBlank()) add("Zadaj konečný cieľ.")
        if (origin.trim().equals(destination.trim(), ignoreCase = true)) {
            add("Začiatočné miesto a cieľ musia byť rozdielne.")
        }
        if (passengers !in 1..20) add("Počet cestujúcich musí byť od 1 do 20.")
        if (modes.isEmpty()) add("Vyber aspoň jeden spôsob dopravy.")
    }
}

data class JourneyLeg(
    val mode: JourneyLegMode,
    val origin: String,
    val destination: String,
    val departureEpochMs: Long? = null,
    val arrivalEpochMs: Long? = null,
    val price: Double? = null,
    val currencyCode: String = "EUR",
    val provider: String? = null,
    val bookingUrl: String? = null,
    val notes: String = ""
) {
    fun validate(): List<String> = buildList {
        if (origin.isBlank() || destination.isBlank()) add("Každý úsek musí mať začiatok aj cieľ.")
        if (price != null && (!price.isFinite() || price < 0.0)) add("Cena úseku musí byť nezáporná.")
        if (currencyCode !in setOf("EUR", "CZK", "USD", "GBP", "PLN", "HUF", "RON")) {
            add("Nepodporovaná mena: $currencyCode.")
        }
        if (departureEpochMs != null && arrivalEpochMs != null && arrivalEpochMs < departureEpochMs) {
            add("Príchod úseku nemôže byť pred odchodom.")
        }
        if (bookingUrl != null && !bookingUrl.startsWith("https://")) {
            add("Odkaz na rezerváciu musí používať HTTPS.")
        }
    }
}

data class JourneyPlan(
    val id: String,
    val legs: List<JourneyLeg>,
    val totalPrice: Double? = null,
    val currencyCode: String = "EUR",
    val totalDurationMinutes: Int? = null,
    val transfers: Int? = null,
    val dataStatus: JourneyDataStatus = JourneyDataStatus.UNAVAILABLE,
    val explanation: String = ""
) {
    fun validate(): List<String> = buildList {
        if (id.isBlank()) add("Plán cesty nemá identifikátor.")
        if (legs.isEmpty()) add("Plán cesty musí obsahovať aspoň jeden úsek.")
        if (totalPrice != null && (!totalPrice.isFinite() || totalPrice < 0.0)) add("Celková cena nie je platná.")
        if (totalDurationMinutes != null && totalDurationMinutes < 0) add("Trvanie nemôže byť záporné.")
        if (transfers != null && transfers < 0) add("Počet prestupov nemôže byť záporný.")
        legs.forEach { addAll(it.validate()) }
    }
}

data class JourneySearchResult(
    val request: JourneySearchRequest,
    val plans: List<JourneyPlan>,
    val status: JourneyDataStatus,
    val providerMessage: String
)

interface JourneySearchProvider {
    suspend fun search(request: JourneySearchRequest): JourneySearchResult
}

class UnconfiguredJourneySearchProvider : JourneySearchProvider {
    override suspend fun search(request: JourneySearchRequest): JourneySearchResult =
        JourneySearchResult(
            request = request,
            plans = emptyList(),
            status = JourneyDataStatus.UNAVAILABLE,
            providerMessage = "Živý poskytovateľ spojení zatiaľ nie je pripojený. Zatiaľ môžeš pripraviť trasu; reálne odchody, ceny a dostupnosť sa zobrazia až po integrácii dátových služieb."
        )
}

class JourneySearchService(private val provider: JourneySearchProvider) {
    suspend fun search(request: JourneySearchRequest): JourneySearchResult {
        val errors = request.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        return provider.search(request)
    }
}
