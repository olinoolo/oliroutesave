package com.oli.routesave.data.model

data class AppSettings(
    val languageTag: String = "sk-SK",
    val unitsMetric: Boolean = true,
    val truckModeEnabled: Boolean = false,
    val communityEnabled: Boolean = true,
    val voiceEnabled: Boolean = true
)
