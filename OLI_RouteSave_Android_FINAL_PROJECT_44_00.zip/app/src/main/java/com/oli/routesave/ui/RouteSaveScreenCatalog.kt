package com.oli.routesave.ui

data class RouteSaveScreenSpec(
    val section: HomeSection,
    val title: String,
    val description: String,
    val primaryActionLabel: String? = null
)

object RouteSaveScreenCatalog {
    val screens = listOf(
        RouteSaveScreenSpec(
            HomeSection.HOME,
            "OLI RouteSave",
            "Naplánuj cestu, porovnaj náklady a cestuj výhodnejšie.",
            "Naplánovať trasu"
        ),
        RouteSaveScreenSpec(
            HomeSection.VEHICLE,
            "Profil vozidla",
            "Ulož spotrebu, cenu paliva a predvolené vozidlo.",
            "Uložiť vozidlo"
        ),
        RouteSaveScreenSpec(
            HomeSection.ASSISTANT_SETTINGS,
            "Hlasový asistent",
            "Vyber hlas, jazyk a možnosti hands-free ovládania.",
            "Uložiť nastavenia"
        ),
        RouteSaveScreenSpec(
            HomeSection.TRAVEL_COMPARE,
            "Porovnanie dopravy",
            "Porovnaj auto, vlak, autobus a lietadlo; dostupnosť cien závisí od pripojených poskytovateľov.",
            "Porovnať možnosti"
        ),
        RouteSaveScreenSpec(
            HomeSection.COMMUNITY_HELP,
            "Komunitná pomoc",
            "Ľudia pomáhajú ľuďom. Pred zverejnením požiadavky sa vždy vyžaduje výslovné potvrdenie.",
            "Vytvoriť žiadosť"
        )
    )

    fun find(section: HomeSection): RouteSaveScreenSpec =
        screens.first { it.section == section }
}
