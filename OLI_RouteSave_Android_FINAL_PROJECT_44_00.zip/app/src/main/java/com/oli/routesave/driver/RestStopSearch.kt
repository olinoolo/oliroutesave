package com.oli.routesave.driver

data class RestStop(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val distanceKm: Double? = null,
    val hasTruckParking: Boolean? = null,
    val hasCarParking: Boolean? = null,
    val hasToilets: Boolean? = null,
    val hasFood: Boolean? = null,
    val source: String? = null,
    val lastUpdatedAtMillis: Long? = null
) {
    fun validate(): List<String> = buildList {
        if (id.isBlank()) add("Odpočívadlo nemá ID.")
        if (name.isBlank()) add("Odpočívadlo nemá názov.")
        if (!latitude.isFinite() || latitude !in -90.0..90.0) add("Neplatná zemepisná šírka.")
        if (!longitude.isFinite() || longitude !in -180.0..180.0) add("Neplatná zemepisná dĺžka.")
        if (distanceKm != null && (!distanceKm.isFinite() || distanceKm < 0.0)) add("Neplatná vzdialenosť.")
    }
}

interface RestStopProvider {
    suspend fun searchNearby(latitude: Double, longitude: Double, radiusKm: Double): List<RestStop>
}

sealed interface RestStopSearchResult {
    data class Success(val stops: List<RestStop>) : RestStopSearchResult
    data class Invalid(val reason: String) : RestStopSearchResult
    data class Failed(val reason: String) : RestStopSearchResult
}

class RestStopSearchService(
    private val provider: RestStopProvider
) {
    suspend fun search(latitude: Double, longitude: Double, radiusKm: Double): RestStopSearchResult {
        if (!latitude.isFinite() || latitude !in -90.0..90.0 ||
            !longitude.isFinite() || longitude !in -180.0..180.0
        ) return RestStopSearchResult.Invalid("Poloha nie je platná.")
        if (!radiusKm.isFinite() || radiusKm !in 1.0..200.0) {
            return RestStopSearchResult.Invalid("Okruh vyhľadávania musí byť 1 až 200 km.")
        }
        return try {
            val valid = provider.searchNearby(latitude, longitude, radiusKm)
                .filter { it.validate().isEmpty() }
                .sortedBy { it.distanceKm ?: Double.MAX_VALUE }
            RestStopSearchResult.Success(valid)
        } catch (_: Exception) {
            RestStopSearchResult.Failed("Odpočívadlá sa teraz nepodarilo vyhľadať.")
        }
    }
}
