package com.oli.routesave.data.store

import com.oli.routesave.data.model.AppSettings
import com.oli.routesave.data.model.AssistantSettings

class InMemorySettingsStore : SettingsStore {
    private var app = AppSettings()
    private var assistant: AssistantSettings? = null

    override fun getAppSettings(): AppSettings = app

    override fun saveAppSettings(settings: AppSettings) {
        app = settings
    }

    override fun getAssistantSettings(): AssistantSettings? = assistant

    override fun saveAssistantSettings(settings: AssistantSettings) {
        assistant = settings
    }
}
