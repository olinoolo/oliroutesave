package com.oli.routesave.travel

data class TripHistoryRecord(
    val id: String,
    val origin: String,
    val destination: String,
    val distanceKm: Double,
    val consumptionL100Km: Double,
    val fuelPricePerLitre: Double,
    val fuelLitres: Double,
    val fuelCost: Double,
    val tollCost: Double,
    val parkingCost: Double,
    val otherCosts: Double,
    val totalCost: Double,
    val currencyCode: String = "EUR",
    val vehicleId: String? = null,
    val createdAtEpochMs: Long
) {
    fun validate(): List<String> = buildList {
        if (id.isBlank()) add("ID cesty je povinné.")
        if (origin.isBlank()) add("Začiatok cesty je povinný.")
        if (destination.isBlank()) add("Cieľ cesty je povinný.")
        if (!distanceKm.isFinite() || distanceKm < 0.0 || distanceKm > 2_000_000.0) add("Neplatná vzdialenosť.")
        if (!consumptionL100Km.isFinite() || consumptionL100Km !in 0.0..100.0) add("Neplatná spotreba.")
        if (!fuelPricePerLitre.isFinite() || fuelPricePerLitre !in 0.0..20.0) add("Neplatná cena paliva.")
        listOf(fuelLitres, fuelCost, tollCost, parkingCost, otherCosts, totalCost).forEach {
            if (!it.isFinite() || it < 0.0 || it > 10_000_000.0) add("Náklad cesty je mimo povoleného rozsahu.")
        }
        if (currencyCode !in setOf("EUR", "CZK", "USD", "GBP", "PLN", "HUF", "RON")) add("Nepodporovaná mena.")
        if (createdAtEpochMs < 0) add("Neplatný čas vytvorenia.")
    }
}

data class TripHistorySummary(
    val tripCount: Int,
    val totalDistanceKm: Double,
    val totalFuelLitres: Double,
    val totalCost: Double,
    val currencyCode: String
)
