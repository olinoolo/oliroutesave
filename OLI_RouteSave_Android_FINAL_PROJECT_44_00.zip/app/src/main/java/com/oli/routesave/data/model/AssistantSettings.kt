package com.oli.routesave.data.model

data class AssistantSettings(
    val assistantId: String,
    val invocationName: String,
    val personalAddress: String,
    val conciseResponses: Boolean = true,
    val proactiveSuggestions: Boolean = true,
    val romanceEnabled: Boolean = false,
    val romanceIntensity: String = "OFF"
)
