package com.oli.routesave.android.ui

data class ComposeScreenSpec(
    val route: String,
    val title: String,
    val showMap: Boolean = false,
    val showVoiceButton: Boolean = false,
    val primaryButton: String? = null
)

object ComposeScreenCatalog {
    val home = ComposeScreenSpec(
        route = "home",
        title = "OLI RouteSave",
        showMap = true,
        showVoiceButton = true,
        primaryButton = "Spustiť jazdu"
    )

    val drive = ComposeScreenSpec(
        route = "drive",
        title = "Jazda",
        showMap = true,
        showVoiceButton = true,
        primaryButton = "Ukončiť jazdu"
    )

    val vehicle = ComposeScreenSpec(
        route = "vehicle",
        title = "Profil vozidla"
    )

    val assistant = ComposeScreenSpec(
        route = "assistant",
        title = "Hlasový asistent",
        showVoiceButton = true
    )

    val community = ComposeScreenSpec(
        route = "community",
        title = "Ľudia pomáhajú ľuďom"
    )

    val settings = ComposeScreenSpec(
        route = "settings",
        title = "Nastavenia"
    )
}
