package com.oli.routesave.data.store

import com.oli.routesave.data.model.VehicleProfile

class InMemoryVehicleStore : VehicleStore {
    private val items = linkedMapOf<String, VehicleProfile>()

    override fun save(vehicle: VehicleProfile) {
        if (vehicle.isDefault) {
            items.replaceAll { _, value -> value.copy(isDefault = false) }
        }
        items[vehicle.id] = vehicle
    }

    override fun get(id: String): VehicleProfile? = items[id]

    override fun getAll(): List<VehicleProfile> = items.values.toList()

    override fun getDefault(): VehicleProfile? = items.values.firstOrNull { it.isDefault }

    override fun delete(id: String) {
        items.remove(id)
    }
}
