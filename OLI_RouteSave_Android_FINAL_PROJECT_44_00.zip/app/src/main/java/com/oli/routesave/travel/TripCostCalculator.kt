package com.oli.routesave.travel

/**
 * Estimates direct car trip costs using the saved vehicle consumption or a
 * per-trip override. This is an estimate, not a live quote for fuel/tolls.
 */
class TripCostCalculator(
    private val currencyCode: String = "EUR"
) {
    fun estimate(
        vehicle: VehicleProfile,
        input: TripCostInput
    ): TripCostResult {
        val errors = vehicle.validate().toMutableList()
        if (!input.distanceKm.isFinite() || input.distanceKm < 0.0 || input.distanceKm > 2_000_000.0) {
            errors.add("Vzdialenosť musí byť v rozsahu 0 až 2 000 000 km.")
        }
        if (!input.fuelPricePerLitre.isFinite() || input.fuelPricePerLitre < 0.0 || input.fuelPricePerLitre > 20.0) {
            errors.add("Cena paliva musí byť v rozsahu 0 až 20 za liter.")
        }
        input.consumptionOverrideLitresPer100Km?.let {
            if (!it.isFinite() || it < 0.0 || it > 100.0) {
                errors.add("Spotreba pre túto cestu musí byť v rozsahu 0 až 100 l/100 km.")
            }
        }
        listOf(
            "Mýto" to input.tollCost,
            "Parkovanie" to input.parkingCost,
            "Ďalšie náklady" to input.otherCosts
        ).forEach { (label, value) ->
            if (!value.isFinite() || value < 0.0 || value > 1_000_000.0) {
                errors.add("$label musia byť nezáporné a v povolenom rozsahu.")
            }
        }
        if (errors.isNotEmpty()) return TripCostResult.Invalid(errors.distinct())

        val consumption = input.consumptionOverrideLitresPer100Km
            ?: vehicle.averageConsumptionLitresPer100Km
        val litres = input.distanceKm * consumption / 100.0
        val fuelCost = litres * input.fuelPricePerLitre
        val total = fuelCost + input.tollCost + input.parkingCost + input.otherCosts

        return TripCostResult.Success(
            TripCostEstimate(
                distanceKm = input.distanceKm,
                consumptionLitresPer100Km = consumption,
                fuelLitres = litres,
                fuelCost = fuelCost,
                tollCost = input.tollCost,
                parkingCost = input.parkingCost,
                otherCosts = input.otherCosts,
                totalCost = total,
                currencyCode = currencyCode
            )
        )
    }
}
