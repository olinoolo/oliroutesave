package com.oli.routesave.navigation
import com.oli.routesave.ui.*
class MapboxMapAdapter(private val engine:MapboxMapEngine):MapProvider{
 override fun initialize()=engine.initialize()
 override fun setCamera(camera:MapCamera)=engine.setCamera(camera)
 override fun showUserLocation(enabled:Boolean)=engine.showUserLocation(enabled)
 override fun drawRoute(points:List<Pair<Double,Double>>)=engine.drawRoute(points)
 override fun clearRoute()=engine.clearRoute()
}
interface MapboxMapEngine{
 fun initialize()
 fun setCamera(camera:MapCamera)
 fun showUserLocation(enabled:Boolean)
 fun drawRoute(points:List<Pair<Double,Double>>)
 fun clearRoute()
}
