package com.oli.routesave.voice.assistant

import com.oli.routesave.voice.intent.ConfirmationRequirement
import com.oli.routesave.voice.intent.ExternalActionConfirmationGate
import com.oli.routesave.voice.intent.ExternalActionType
import com.oli.routesave.voice.intent.ParsedVoiceIntent
import com.oli.routesave.voice.intent.PendingExternalAction
import com.oli.routesave.voice.intent.VoiceIntentParser
import com.oli.routesave.voice.intent.VoiceIntentType

sealed class AssistantOutcome {
    data class Speak(val text: String, val languageTag: String) : AssistantOutcome()
    data class RouteRequested(val destination: String?, val assistant: AssistantProfile) : AssistantOutcome()
    data class FuelEstimateRequested(val assistant: AssistantProfile) : AssistantOutcome()
    data class NeedsClarification(val text: String, val languageTag: String) : AssistantOutcome()
    data class AwaitingConfirmation(val prompt: String, val languageTag: String) : AssistantOutcome()
    data class ExternalActionApproved(val action: PendingExternalAction, val assistant: AssistantProfile) : AssistantOutcome()
    object NoPendingConfirmation : AssistantOutcome()
}

class VoiceAssistantCoordinator(
    private val parser: VoiceIntentParser = VoiceIntentParser(),
    private val confirmationGate: ExternalActionConfirmationGate = ExternalActionConfirmationGate(),
    private val nowMillis: () -> Long = { System.currentTimeMillis() }
) {
    fun handleSpeech(text: String, assistant: AssistantProfile): AssistantOutcome {
        val parsed = parser.parse(text)
        return when (parsed.type) {
            VoiceIntentType.PLAN_ROUTE -> {
                if (parsed.argument.isNullOrBlank()) {
                    AssistantOutcome.NeedsClarification(
                        addressed(assistant, "Kam chceš ísť? Povedz mi cieľ cesty."),
                        assistant.languageTag
                    )
                } else AssistantOutcome.RouteRequested(parsed.argument, assistant)
            }
            VoiceIntentType.FUEL_ESTIMATE ->
                AssistantOutcome.FuelEstimateRequested(assistant)
            VoiceIntentType.REPORT_BREAKDOWN ->
                askExternal(
                    assistant,
                    ExternalActionType.COMMUNITY_HELP_REQUEST,
                    "Požiadať ľudí v okolí o pomoc. Zatiaľ sa nič neodošle."
                )
            VoiceIntentType.CALL_CONTACT ->
                if (parsed.argument.isNullOrBlank()) {
                    AssistantOutcome.NeedsClarification(addressed(assistant, "Komu chceš zavolať?"), assistant.languageTag)
                } else askExternal(assistant, ExternalActionType.CALL, "Zavolať kontaktu: ${parsed.argument}.")
            VoiceIntentType.SEND_MESSAGE ->
                if (parsed.argument.isNullOrBlank()) {
                    AssistantOutcome.NeedsClarification(addressed(assistant, "Komu chceš poslať správu?"), assistant.languageTag)
                } else askExternal(assistant, ExternalActionType.SEND_MESSAGE, "Pripraviť správu pre: ${parsed.argument}.")
            VoiceIntentType.SHARE_LOCATION ->
                askExternal(assistant, ExternalActionType.SHARE_LOCATION, "Zdieľať tvoju polohu.")
            VoiceIntentType.UNKNOWN ->
                AssistantOutcome.NeedsClarification(
                    addressed(assistant, "Tomuto príkazu zatiaľ nerozumiem. Skús ho povedať inak."),
                    assistant.languageTag
                )
        }
    }

    fun confirmExternalAction(yes: Boolean, assistant: AssistantProfile): AssistantOutcome {
        val approved = confirmationGate.confirm(yes)
        if (approved == null) {
            return AssistantOutcome.Speak(
                addressed(assistant, if (yes) "Nemám žiadnu čakajúcu akciu." else "Dobre, akciu som zrušil."),
                assistant.languageTag
            )
        }
        return AssistantOutcome.ExternalActionApproved(approved, assistant)
    }

    fun cancelPendingAction() {
        confirmationGate.cancel()
    }

    private fun askExternal(
        assistant: AssistantProfile,
        actionType: ExternalActionType,
        summary: String
    ): AssistantOutcome.AwaitingConfirmation {
        val prompt = confirmationGate.requestConfirmation(
            PendingExternalAction(actionType, summary, nowMillis())
        )
        return AssistantOutcome.AwaitingConfirmation(
            addressed(assistant, prompt),
            assistant.languageTag
        )
    }

    private fun addressed(assistant: AssistantProfile, text: String): String {
        val name = assistant.personalAddress?.takeIf { it.isNotBlank() }
        return if (name != null) "$name, $text" else text
    }
}
