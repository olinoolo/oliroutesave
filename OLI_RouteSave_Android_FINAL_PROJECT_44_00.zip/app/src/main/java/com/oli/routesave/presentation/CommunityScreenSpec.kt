package com.oli.routesave.presentation

data class CommunityScreenSpec(
    val title: String = "Ľudia pomáhajú ľuďom",
    val nearbyHelp: String = "Pomoc v okolí",
    val reportHelp: String = "Požiadať o pomoc",
    val offerHelp: String = "Ponúknuť pomoc",
    val trustInfo: String = "Bezpečnosť a dôvera"
)
