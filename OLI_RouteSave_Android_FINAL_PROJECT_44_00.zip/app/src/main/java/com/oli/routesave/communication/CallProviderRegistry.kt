package com.oli.routesave.communication

/** Runtime registry for installed/available call-channel adapters. */
class CallProviderRegistry(providers: Collection<CommunicationCallProvider>) {
    private val byChannel = providers.associateBy { it.channel }

    fun providerFor(channel: CallChannel): CommunicationCallProvider? = byChannel[channel]

    suspend fun availableChannels(mode: CallMode): Map<CallChannel, CallCapability> {
        val result = linkedMapOf<CallChannel, CallCapability>()
        for ((channel, provider) in byChannel) {
            result[channel] = provider.capability(mode)
        }
        return result
    }
}
