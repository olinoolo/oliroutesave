package com.oli.routesave.presentation

data class HomeScreenSpec(
    val primaryButton: String,
    val voiceButton: String,
    val routeButton: String,
    val vehicleButton: String,
    val assistantButton: String,
    val communityButton: String
)

object HomeScreenSpecFactory {
    fun create(model: MainUiModel): HomeScreenSpec = HomeScreenSpec(
        primaryButton = if (model.driving) "Ukončiť jazdu" else "Spustiť jazdu",
        voiceButton = if (model.listening) "Počúvam…" else "Hlasový asistent",
        routeButton = "Trasa",
        vehicleButton = model.vehicleName,
        assistantButton = model.assistantInvocation,
        communityButton = "Pomoc v okolí"
    )
}
