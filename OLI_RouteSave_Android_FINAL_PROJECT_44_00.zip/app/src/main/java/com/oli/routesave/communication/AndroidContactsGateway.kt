package com.oli.routesave.communication

/**
 * Boundary for a future Android ContentResolver adapter.
 *
 * This interface deliberately contains no fake phonebook access. A real
 * implementation should query ContactsContract only after runtime permission
 * is granted, return candidates for disambiguation, and avoid logging numbers.
 */
interface AndroidContactsGateway {
    fun permissionState(): ContactPermissionState

    suspend fun searchByNameOrNickname(query: String): ContactLookupOutcome

    suspend fun getPhoneNumbers(contactId: String): ContactLookupOutcome
}

sealed interface ContactSelectionOutcome {
    data class Selected(val contact: ContactCandidate, val phoneNumber: ContactPhoneNumber) : ContactSelectionOutcome
    data class AskWhichContact(val candidates: List<ContactCandidate>) : ContactSelectionOutcome
    data class AskWhichNumber(val contact: ContactCandidate, val numbers: List<ContactPhoneNumber>) : ContactSelectionOutcome
    data class CannotProceed(val reason: String) : ContactSelectionOutcome
}

/** Selects only when the result is unambiguous; never chooses a random match. */
object ContactSelectionPolicy {
    fun select(
        outcome: ContactLookupOutcome,
        requestedNumberIndex: Int? = null
    ): ContactSelectionOutcome = when (outcome) {
        ContactLookupOutcome.PermissionRequired ->
            ContactSelectionOutcome.CannotProceed("Na vyhľadanie kontaktov je potrebné povoliť prístup ku kontaktom.")
        ContactLookupOutcome.NoMatch ->
            ContactSelectionOutcome.CannotProceed("Kontakt sa nenašiel. Môžeš nadiktovať telefónne číslo.")
        is ContactLookupOutcome.Failed ->
            ContactSelectionOutcome.CannotProceed(outcome.reason)
        is ContactLookupOutcome.Found -> when (outcome.contacts.size) {
            0 -> ContactSelectionOutcome.CannotProceed("Kontakt sa nenašiel. Môžeš nadiktovať telefónne číslo.")
            1 -> {
                val contact = outcome.contacts.first()
                when {
                    contact.phoneNumbers.isEmpty() ->
                        ContactSelectionOutcome.CannotProceed("Tento kontakt nemá uložené telefónne číslo.")
                    contact.phoneNumbers.size == 1 ->
                        ContactSelectionOutcome.Selected(contact, contact.phoneNumbers.first())
                    requestedNumberIndex != null &&
                        requestedNumberIndex in contact.phoneNumbers.indices ->
                        ContactSelectionOutcome.Selected(contact, contact.phoneNumbers[requestedNumberIndex])
                    else -> ContactSelectionOutcome.AskWhichNumber(contact, contact.phoneNumbers)
                }
            }
            else -> ContactSelectionOutcome.AskWhichContact(outcome.contacts)
        }
    }
}
