package com.oli.routesave.travel

import java.util.Calendar
import java.util.TimeZone

data class TripStatistics(
    val tripCount: Int,
    val distanceKm: Double,
    val fuelLitres: Double,
    val fuelCost: Double,
    val tollCost: Double,
    val parkingCost: Double,
    val otherCosts: Double,
    val totalCost: Double,
    val currencyCode: String,
    val fromEpochMs: Long?,
    val toEpochMs: Long?
)

enum class TripStatisticsPeriod { ALL_TIME, THIS_MONTH, LAST_30_DAYS }

class TripStatisticsService(
    private val repository: TripHistoryRepository,
    private val timeZone: TimeZone = TimeZone.getDefault()
) {
    fun calculate(
        period: TripStatisticsPeriod,
        nowEpochMs: Long = System.currentTimeMillis()
    ): TripStatistics {
        val all = repository.all().sortedByDescending { it.createdAtEpochMs }
        val selected = all.filter { record ->
            when (period) {
                TripStatisticsPeriod.ALL_TIME -> true
                TripStatisticsPeriod.LAST_30_DAYS ->
                    record.createdAtEpochMs in (nowEpochMs - THIRTY_DAYS_MS)..nowEpochMs
                TripStatisticsPeriod.THIS_MONTH -> isSameMonth(record.createdAtEpochMs, nowEpochMs)
            }
        }
        // Do not combine unlike currencies. The displayed statistics use the
        // newest currency represented in the selected period.
        val currency = selected.firstOrNull()?.currencyCode ?: "EUR"
        val records = selected.filter { it.currencyCode == currency }
        return TripStatistics(
            tripCount = records.size,
            distanceKm = records.sumOf { it.distanceKm },
            fuelLitres = records.sumOf { it.fuelLitres },
            fuelCost = records.sumOf { it.fuelCost },
            tollCost = records.sumOf { it.tollCost },
            parkingCost = records.sumOf { it.parkingCost },
            otherCosts = records.sumOf { it.otherCosts },
            totalCost = records.sumOf { it.totalCost },
            currencyCode = currency,
            fromEpochMs = records.minOfOrNull { it.createdAtEpochMs },
            toEpochMs = records.maxOfOrNull { it.createdAtEpochMs }
        )
    }

    private fun isSameMonth(timestamp: Long, reference: Long): Boolean {
        val a = Calendar.getInstance(timeZone).apply { timeInMillis = timestamp }
        val b = Calendar.getInstance(timeZone).apply { timeInMillis = reference }
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.MONTH) == b.get(Calendar.MONTH)
    }

    companion object {
        private const val THIRTY_DAYS_MS = 30L * 24L * 60L * 60L * 1000L
    }
}
