package com.oli.routesave.data.store

import com.oli.routesave.data.model.VehicleProfile

interface VehicleStore {
    fun save(vehicle: VehicleProfile)
    fun get(id: String): VehicleProfile?
    fun getAll(): List<VehicleProfile>
    fun getDefault(): VehicleProfile?
    fun delete(id: String)
}
