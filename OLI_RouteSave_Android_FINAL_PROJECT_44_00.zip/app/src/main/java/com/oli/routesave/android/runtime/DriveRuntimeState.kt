package com.oli.routesave.android.runtime

enum class DriveRuntimeState {
    STOPPED,
    STARTING,
    RUNNING,
    PAUSED,
    STOPPING,
    ERROR
}
