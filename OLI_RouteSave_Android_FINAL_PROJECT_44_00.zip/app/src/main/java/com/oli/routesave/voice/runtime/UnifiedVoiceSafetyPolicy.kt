package com.oli.routesave.voice.runtime

class UnifiedVoiceSafetyPolicy {

    fun canSpeak(context: UnifiedVoiceContext): Boolean {
        if (context.emergencyActive) return false
        if (context.activeCall) return false
        return true
    }

    fun canContinueConversation(context: UnifiedVoiceContext): Boolean {
        if (context.emergencyActive) return false
        if (context.activeCall) return false
        return true
    }

    fun shouldSuppressNonEssential(context: UnifiedVoiceContext): Boolean =
        context.navigationCritical
}
