package com.oli.routesave.presentation

import com.oli.routesave.ui.AndroidUiIntegrationBoundary
import com.oli.routesave.ui.*

/**
 * Toolkit-neutral host.
 * Connect this boundary to Jetpack Compose or XML in the Android module.
 */
interface AndroidScreenRenderer {
    fun showHome(model: MainUiModel)
    fun showDrive(spec: DriveScreenSpec)
    fun showVehicle(spec: VehicleScreenSpec)
    fun showAssistant(spec: AssistantScreenSpec)
    fun showCommunity(spec: CommunityScreenSpec)
    fun showSettings(spec: SettingsScreenSpec)
}

class AndroidUiHost(
    private val renderer: AndroidScreenRenderer
) : AndroidUiIntegrationBoundary {
    override fun renderHome(state: HomeUiState) {
        renderer.showHome(MainUiModel(
            assistantInvocation = state.assistantName,
            vehicleName = state.vehicleName
        ))
    }

    override fun renderDrive(state: DriveUiState) {
        renderer.showDrive(
            DriveScreenSpec(
                assistantName = state.assistantInvocation,
                destination = state.destination,
                eta = state.etaText,
                remainingDistance = state.remainingKm?.let { "%.1f km".format(it) }.orEmpty(),
                primaryAction = if (state.isDriving) "Ukončiť jazdu" else "Spustiť jazdu"
            )
        )
    }

    override fun renderRoute(state: RouteUiState) = Unit

    override fun renderVehicle(state: VehicleUiState) = Unit

    override fun renderAssistant(state: AssistantUiState) {
        renderer.showAssistant(
            AssistantScreenSpec(
                officialName = state.officialName,
                invocationName = state.invocationName,
                personalAddress = state.personalAddress,
                conciseResponses = state.conciseResponses,
                proactiveSuggestions = state.proactiveSuggestions,
                romanceEnabled = state.romanceEnabled
            )
        )
    }

    override fun renderCommunity(state: CommunityUiState) {
        renderer.showCommunity(CommunityScreenSpec())
    }

    override fun renderSettings(state: SettingsUiState) {
        renderer.showSettings(
            SettingsScreenSpec(
                language = state.languageTag,
                metricUnits = state.metricUnits,
                truckMode = state.truckMode,
                communityEnabled = state.communityEnabled,
                voiceEnabled = state.voiceEnabled
            )
        )
    }
}
