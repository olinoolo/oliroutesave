package com.oli.routesave.voice

/**
 * Platform-neutral voice workflow foundation.
 *
 * This class models a safe interaction. Android microphone / SpeechRecognizer,
 * TextToSpeech, Contacts, Telecom and SMS integrations must be connected by
 * platform-specific adapters in a later milestone.
 */
enum class VoiceReplyKind {
    SPOKEN_INFORMATION, ASK_FOR_CONFIRMATION, CLARIFY, ERROR
}

data class VoiceReply(
    val text: String,
    val kind: VoiceReplyKind,
    val pendingAction: PendingVoiceAction? = null
)

data class ContactMatch(
    val displayName: String,
    val phoneNumber: String
)

data class VoiceContactRequest(
    val spokenReference: String,
    val availableMatches: List<ContactMatch>
)

object VoiceConversationEngine {
    /**
     * Builds an assistant reply from a parsed command. This does not perform
     * external actions; it only returns the safe next response for the UI/TTS.
     */
    fun respond(command: VoiceCommand): VoiceReply {
        if (command.confidence < 0.60f) {
            return VoiceReply(
                "Nerozumela som úplne. Môžeš to, prosím, zopakovať?",
                VoiceReplyKind.CLARIFY
            )
        }
        return when (command.intent) {
            VoiceIntent.SET_DESTINATION ->
                VoiceReply("Rozumiem. Pripravím nastavenie cieľa: ${command.entities["destination"] ?: "cieľ"}.", VoiceReplyKind.SPOKEN_INFORMATION)
            VoiceIntent.SEARCH_TRANSIT ->
                VoiceReply("Pripravím vyhľadanie spojenia. Živé údaje musia byť dostupné od pripojeného poskytovateľa.", VoiceReplyKind.SPOKEN_INFORMATION)
            VoiceIntent.CALCULATE_TRIP_COST ->
                VoiceReply("Pripravím výpočet nákladov na cestu.", VoiceReplyKind.SPOKEN_INFORMATION)
            VoiceIntent.CALL_CONTACT,
            VoiceIntent.SEND_MESSAGE,
            VoiceIntent.SHARE_LOCATION,
            VoiceIntent.OPEN_BOOKING,
            VoiceIntent.PURCHASE_TICKET -> {
                val summary = command.entities["summary"]
                    ?: command.entities["contact"]
                    ?: command.entities["destination"]
                    ?: command.rawText
                val pending = VoiceCommandPolicy.createConfirmationPrompt(
                    intent = command.intent,
                    assistant = command.assistant,
                    summary = summary
                )
                VoiceReply(pending.confirmationPrompt, VoiceReplyKind.ASK_FOR_CONFIRMATION, pending)
            }
            VoiceIntent.UNKNOWN ->
                VoiceReply("Tomuto príkazu zatiaľ nerozumiem. Skús ho povedať inak.", VoiceReplyKind.CLARIFY)
        }
    }

    /**
     * Resolves a spoken contact reference only if there is exactly one match.
     * Ambiguous/no matches must be clarified; this does not start a call.
     */
    fun resolveContact(request: VoiceContactRequest): ContactResolution {
        val needle = request.spokenReference.trim()
        if (needle.isBlank()) return ContactResolution.NeedClarification("Koho chceš zavolať?")
        val matches = request.availableMatches.filter {
            it.displayName.contains(needle, ignoreCase = true)
        }
        return when (matches.size) {
            0 -> ContactResolution.NotFound("V kontaktoch som nenašla jednoznačný kontakt. Skús celé meno.")
            1 -> ContactResolution.Single(matches.first())
            else -> ContactResolution.Multiple(matches.take(5))
        }
    }
}

sealed class ContactResolution {
    data class Single(val contact: ContactMatch) : ContactResolution()
    data class Multiple(val contacts: List<ContactMatch>) : ContactResolution()
    data class NotFound(val message: String) : ContactResolution()
    data class NeedClarification(val message: String) : ContactResolution()
}

enum class ConfirmationDecision { CONFIRMED, REJECTED, UNCLEAR, NO_PENDING_ACTION }

object VoiceConfirmationFlow {
    fun interpret(
        pending: PendingVoiceAction?,
        recognizedText: String,
        confidence: Float
    ): ConfirmationDecision {
        if (pending == null) return ConfirmationDecision.NO_PENDING_ACTION
        if (confidence < 0.85f) return ConfirmationDecision.UNCLEAR
        val text = recognizedText.trim().lowercase()
        return when (text) {
            "áno", "ano", "potvrdzujem", "áno potvrď", "ano potvrd", "yes", "confirm", "ja" ->
                ConfirmationDecision.CONFIRMED
            "nie", "ne", "zruš", "zrus", "nepotvrdzujem", "no", "nein" ->
                ConfirmationDecision.REJECTED
            else -> ConfirmationDecision.UNCLEAR
        }
    }
}
