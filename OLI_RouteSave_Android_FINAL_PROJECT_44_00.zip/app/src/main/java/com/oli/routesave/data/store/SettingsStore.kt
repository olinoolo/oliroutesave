package com.oli.routesave.data.store

import com.oli.routesave.data.model.AppSettings
import com.oli.routesave.data.model.AssistantSettings

interface SettingsStore {
    fun getAppSettings(): AppSettings
    fun saveAppSettings(settings: AppSettings)
    fun getAssistantSettings(): AssistantSettings?
    fun saveAssistantSettings(settings: AssistantSettings)
}
