package com.oli.routesave.android.ui

data class VoiceButtonSpec(
    val label: String,
    val active: Boolean,
    val enabled: Boolean = true
)
