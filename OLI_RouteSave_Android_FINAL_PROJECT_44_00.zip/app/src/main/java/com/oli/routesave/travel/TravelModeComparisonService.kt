package com.oli.routesave.travel

class TravelModeComparisonService {
    fun compare(input: TravelComparisonInput): TravelComparisonResult {
        require(input.distanceKm.isFinite() && input.distanceKm >= 0.0) { "Vzdialenosť musí byť nezáporná." }
        require(input.fuelConsumptionL100Km.isFinite() && input.fuelConsumptionL100Km in 0.0..100.0) { "Neplatná spotreba." }
        require(input.fuelPricePerLitre.isFinite() && input.fuelPricePerLitre in 0.0..20.0) { "Neplatná cena paliva." }
        listOf(input.carTollCost, input.carParkingCost, input.trainExtraCosts, input.busExtraCosts, input.planeExtraCosts)
            .forEach { require(it.isFinite() && it >= 0.0) { "Dodatočné náklady musia byť nezáporné." } }

        val fuelCost = input.distanceKm * input.fuelConsumptionL100Km / 100.0 * input.fuelPricePerLitre
        val options = listOf(
            TravelOptionQuote(
                mode = TravelMode.CAR,
                providerName = "Auto — odhad",
                distanceKm = input.distanceKm,
                durationMinutes = null,
                ticketOrEnergyCost = fuelCost,
                extraCosts = input.carTollCost + input.carParkingCost,
                currencyCode = input.currencyCode,
                notes = "Palivo, mýto a parkovanie. Bez opotrebenia vozidla a ďalších neznámych nákladov."
            ),
            TravelOptionQuote(
                mode = TravelMode.TRAIN,
                providerName = "Vlak — zadaj cenu lístka",
                distanceKm = null,
                durationMinutes = input.trainDurationMinutes,
                ticketOrEnergyCost = input.trainTicketCost,
                extraCosts = input.trainExtraCosts,
                currencyCode = input.currencyCode,
                status = if (input.trainTicketCost == null) TravelQuoteStatus.UNAVAILABLE else TravelQuoteStatus.ESTIMATE,
                notes = "Cena lístka sa zadáva ručne; nejde o živú ponuku."
            ),
            TravelOptionQuote(
                mode = TravelMode.BUS,
                providerName = "Autobus — zadaj cenu lístka",
                distanceKm = null,
                durationMinutes = input.busDurationMinutes,
                ticketOrEnergyCost = input.busTicketCost,
                extraCosts = input.busExtraCosts,
                currencyCode = input.currencyCode,
                status = if (input.busTicketCost == null) TravelQuoteStatus.UNAVAILABLE else TravelQuoteStatus.ESTIMATE,
                notes = "Cena lístka sa zadáva ručne; nejde o živú ponuku."
            ),
            TravelOptionQuote(
                mode = TravelMode.PLANE,
                providerName = "Lietadlo — zadaj cenu lístka",
                distanceKm = null,
                durationMinutes = input.planeDurationMinutes,
                ticketOrEnergyCost = input.planeTicketCost,
                extraCosts = input.planeExtraCosts,
                currencyCode = input.currencyCode,
                status = if (input.planeTicketCost == null) TravelQuoteStatus.UNAVAILABLE else TravelQuoteStatus.ESTIMATE,
                notes = "Cena lístka sa zadáva ručne; nezahŕňa nezadané transfery a batožinu."
            )
        )
        val priced = options.filter { it.totalCost != null && it.currencyCode == input.currencyCode }
        return TravelComparisonResult(
            options = options,
            cheapestAvailable = priced.minByOrNull { it.totalCost!! },
            fastestAvailable = options.filter { it.totalCost != null && it.durationMinutes != null }
                .minByOrNull { it.durationMinutes!! },
            allPricesAreEstimates = true
        )
    }
}
