package com.oli.routesave.travel

/**
 * Ranking utilities for real journey plans returned by a configured provider.
 * This class does not create or estimate live connections.
 */
object JourneyPlanRanker {
    fun rank(
        plans: List<JourneyPlan>,
        preference: JourneyPreference
    ): List<JourneyPlan> {
        val valid = plans.filter { it.validate().isEmpty() }
        return when (preference) {
            JourneyPreference.CHEAPEST -> valid.sortedWith(
                compareBy<JourneyPlan> { it.totalPrice == null }
                    .thenBy { it.totalPrice ?: Double.MAX_VALUE }
                    .thenBy { it.totalDurationMinutes ?: Int.MAX_VALUE }
            )
            JourneyPreference.FASTEST -> valid.sortedWith(
                compareBy<JourneyPlan> { it.totalDurationMinutes == null }
                    .thenBy { it.totalDurationMinutes ?: Int.MAX_VALUE }
                    .thenBy { it.totalPrice ?: Double.MAX_VALUE }
            )
            JourneyPreference.FEWEST_TRANSFERS -> valid.sortedWith(
                compareBy<JourneyPlan> { it.transfers == null }
                    .thenBy { it.transfers ?: Int.MAX_VALUE }
                    .thenBy { it.totalDurationMinutes ?: Int.MAX_VALUE }
            )
            JourneyPreference.EARLIEST_ARRIVAL -> valid.sortedWith(
                compareBy<JourneyPlan> {
                    it.legs.lastOrNull()?.arrivalEpochMs == null
                }.thenBy { it.legs.lastOrNull()?.arrivalEpochMs ?: Long.MAX_VALUE }
                    .thenBy { it.totalDurationMinutes ?: Int.MAX_VALUE }
            )
        }
    }
}

/** Small helper to keep any external action behind a clear, explicit user confirmation. */
enum class ExternalActionType {
    OPEN_BOOKING_LINK, SEND_MESSAGE, SHARE_LOCATION, PLACE_CALL, PURCHASE_TICKET
}

data class ExternalActionConfirmation(
    val actionType: ExternalActionType,
    val spokenPrompt: String,
    val requiresExplicitConfirmation: Boolean = true
)

object ExternalActionGuard {
    fun mayProceed(
        confirmation: ExternalActionConfirmation,
        userSaidYesClearly: Boolean
    ): Boolean = confirmation.requiresExplicitConfirmation && userSaidYesClearly
}
