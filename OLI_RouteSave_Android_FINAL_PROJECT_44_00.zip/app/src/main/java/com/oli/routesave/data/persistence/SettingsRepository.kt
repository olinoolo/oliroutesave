package com.oli.routesave.data.persistence
import com.oli.routesave.data.model.AppSettings
import com.oli.routesave.data.model.AssistantSettings
class SettingsRepository(private val store:KeyValueStore){
    fun loadAppSettings()=AppSettings(
        languageTag=store.getString("app.language","sk-SK"),
        unitsMetric=store.getBoolean("app.metric",true),
        truckModeEnabled=store.getBoolean("app.truck",false),
        communityEnabled=store.getBoolean("app.community",true),
        voiceEnabled=store.getBoolean("app.voice",true))
    fun saveAppSettings(s:AppSettings){
        store.putString("app.language",s.languageTag); store.putBoolean("app.metric",s.unitsMetric)
        store.putBoolean("app.truck",s.truckModeEnabled); store.putBoolean("app.community",s.communityEnabled)
        store.putBoolean("app.voice",s.voiceEnabled)
    }
    fun loadAssistantSettings():AssistantSettings?{
        val id=store.getString("assistant.id"); if(id.isBlank()) return null
        return AssistantSettings(id,store.getString("assistant.invocation"),
            store.getString("assistant.address"),store.getBoolean("assistant.concise",true),
            store.getBoolean("assistant.proactive",true),store.getBoolean("assistant.romance",false),
            store.getString("assistant.romance_intensity","OFF"))
    }
    fun saveAssistantSettings(s:AssistantSettings){
        store.putString("assistant.id",s.assistantId); store.putString("assistant.invocation",s.invocationName)
        store.putString("assistant.address",s.personalAddress); store.putBoolean("assistant.concise",s.conciseResponses)
        store.putBoolean("assistant.proactive",s.proactiveSuggestions); store.putBoolean("assistant.romance",s.romanceEnabled)
        store.putString("assistant.romance_intensity",s.romanceIntensity)
    }
}
