package com.oli.routesave.ui

class VoiceUiController(
    private val driveUi: DriveUiController
) {
    fun pressAssistantButton() {
        driveUi.setVoiceListening(true)
    }

    fun finishListening() {
        driveUi.setVoiceListening(false)
    }

    fun interrupt() {
        driveUi.setVoiceListening(false)
    }
}
