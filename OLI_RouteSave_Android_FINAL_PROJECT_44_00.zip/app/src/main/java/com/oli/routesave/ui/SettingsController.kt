package com.oli.routesave.ui
import com.oli.routesave.data.model.*
import com.oli.routesave.data.persistence.SettingsRepository
data class SettingsState(val app:AppSettings=AppSettings(),val assistant:AssistantSettings?=null)
class SettingsController(private val repo:SettingsRepository){
    fun load()=SettingsState(repo.loadAppSettings(),repo.loadAssistantSettings())
    fun updateApp(s:AppSettings)=s.also{repo.saveAppSettings(it)}.let{load()}
    fun updateAssistant(s:AssistantSettings)=s.also{repo.saveAssistantSettings(it)}.let{load()}
}
