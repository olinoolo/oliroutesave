package com.oli.routesave.communication

/**
 * User-defined relationship/nickname aliases such as "manželka", "brat",
 * "šéf" or "servis". No relationship is guessed automatically.
 */
data class ContactAlias(
    val alias: String,
    val contactId: String,
    val displayName: String
)

interface ContactAliasStore {
    suspend fun find(alias: String): ContactAlias?
    suspend fun save(alias: ContactAlias)
    suspend fun remove(alias: String)
}

class InMemoryContactAliasStore : ContactAliasStore {
    private val aliases = linkedMapOf<String, ContactAlias>()

    override suspend fun find(alias: String): ContactAlias? =
        aliases[normalize(alias)]

    override suspend fun save(alias: ContactAlias) {
        val key = normalize(alias.alias)
        require(key.isNotBlank()) { "Alias nesmie byť prázdny." }
        aliases[key] = alias.copy(alias = alias.alias.trim())
    }

    override suspend fun remove(alias: String) {
        aliases.remove(normalize(alias))
    }

    private fun normalize(value: String): String =
        value.trim().lowercase().replace(Regex("\\s+"), " ")
}
