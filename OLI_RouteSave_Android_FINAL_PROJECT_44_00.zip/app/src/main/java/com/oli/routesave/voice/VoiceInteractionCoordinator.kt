package com.oli.routesave.voice

/**
 * Coordinates a single voice interaction from recognized text to an assistant
 * response. Android speech adapters are injected by the app layer; this class
 * does not open the microphone or execute external actions itself.
 */
data class VoiceInteractionState(
    val assistant: VoiceAssistantId = VoiceAssistantId.NIKOLAS,
    val listening: Boolean = false,
    val lastRecognizedText: String = "",
    val replyText: String = "",
    val awaitingConfirmation: PendingVoiceAction? = null,
    val statusMessage: String = "Pripravený"
)

sealed class VoiceInteractionEvent {
    data class PartialSpeech(val text: String) : VoiceInteractionEvent()
    data class FinalSpeech(val text: String, val confidence: Float = 0.8f) : VoiceInteractionEvent()
    data class RecognitionError(val message: String) : VoiceInteractionEvent()
    data class SelectAssistant(val assistant: VoiceAssistantId) : VoiceInteractionEvent()
    object StartListening : VoiceInteractionEvent()
    object StopListening : VoiceInteractionEvent()
    data class ConfirmationSpeech(val text: String, val confidence: Float) : VoiceInteractionEvent()
}

class VoiceInteractionCoordinator(
    initialState: VoiceInteractionState = VoiceInteractionState()
) {
    var state: VoiceInteractionState = initialState
        private set

    fun dispatch(event: VoiceInteractionEvent): VoiceInteractionState {
        state = when (event) {
            is VoiceInteractionEvent.SelectAssistant ->
                state.copy(
                    assistant = event.assistant,
                    statusMessage = "Vybraný asistent: ${event.assistant.displayName}",
                    replyText = "",
                    awaitingConfirmation = null
                )
            VoiceInteractionEvent.StartListening ->
                state.copy(listening = true, statusMessage = "Počúvam…")
            VoiceInteractionEvent.StopListening ->
                state.copy(listening = false, statusMessage = "Počúvanie zastavené")
            is VoiceInteractionEvent.PartialSpeech ->
                state.copy(lastRecognizedText = event.text, statusMessage = "Rozpoznávam…")
            is VoiceInteractionEvent.RecognitionError ->
                state.copy(
                    listening = false,
                    statusMessage = event.message,
                    replyText = "Nerozumela som. Skús to znova."
                )
            is VoiceInteractionEvent.FinalSpeech -> handleFinal(event.text, event.confidence)
            is VoiceInteractionEvent.ConfirmationSpeech -> handleConfirmation(event.text, event.confidence)
        }
        return state
    }

    private fun handleFinal(text: String, confidence: Float): VoiceInteractionState {
        if (text.isBlank()) {
            return state.copy(
                listening = false,
                statusMessage = "Nerozpoznala sa žiadna reč",
                replyText = "Nepočula som príkaz. Skús to znova."
            )
        }
        if (state.awaitingConfirmation != null) {
            return handleConfirmation(text, confidence)
        }
        if (!VoiceCommandPolicy.invocationMatches(text, state.assistant)) {
            return state.copy(
                listening = false,
                lastRecognizedText = text,
                statusMessage = "Oslovenie asistenta sa nezhoduje",
                replyText = "Oslov ma menom ${state.assistant.invocation} a zopakuj príkaz."
            )
        }

        val intent = classifyIntent(text)
        val command = VoiceCommand(
            rawText = text,
            assistant = state.assistant,
            intent = intent,
            entities = mapOf("summary" to text.removePrefix(state.assistant.invocation).trim().trimStart(',', ':')),
            confidence = confidence
        )
        val reply = VoiceConversationEngine.respond(command)
        return state.copy(
            listening = false,
            lastRecognizedText = text,
            replyText = reply.text,
            awaitingConfirmation = reply.pendingAction,
            statusMessage = if (reply.pendingAction != null) "Čakám na potvrdenie" else "Príkaz spracovaný"
        )
    }

    private fun handleConfirmation(text: String, confidence: Float): VoiceInteractionState {
        val pending = state.awaitingConfirmation
            ?: return state.copy(statusMessage = "Nie je čakajúca akcia")
        return when (VoiceConfirmationFlow.interpret(pending, text, confidence)) {
            ConfirmationDecision.CONFIRMED ->
                state.copy(
                    listening = false,
                    lastRecognizedText = text,
                    replyText = "Potvrdenie prijaté. Akcia môže pokračovať do ďalšej bezpečnej fázy.",
                    awaitingConfirmation = pending.copy(isConfirmed = true),
                    statusMessage = "Potvrdené; vykonanie ešte musí zabezpečiť aplikácia"
                )
            ConfirmationDecision.REJECTED ->
                state.copy(
                    listening = false,
                    lastRecognizedText = text,
                    replyText = "Dobre, akciu nevykonám.",
                    awaitingConfirmation = null,
                    statusMessage = "Akcia odmietnutá"
                )
            ConfirmationDecision.UNCLEAR ->
                state.copy(
                    listening = false,
                    lastRecognizedText = text,
                    replyText = "Nepočula som jasné áno alebo nie. Chceš túto akciu vykonať?",
                    statusMessage = "Potrebujem jasné potvrdenie"
                )
            ConfirmationDecision.NO_PENDING_ACTION ->
                state.copy(
                    listening = false,
                    replyText = "Nie je čo potvrdzovať.",
                    statusMessage = "Bez čakajúcej akcie"
                )
        }
    }

    private fun classifyIntent(text: String): VoiceIntent {
        val lower = text.lowercase()
        return when {
            lower.contains("zavolaj") || lower.contains("volaj") -> VoiceIntent.CALL_CONTACT
            lower.contains("pošli sms") || lower.contains("pošli správu") ||
                lower.contains("odoslať správu") -> VoiceIntent.SEND_MESSAGE
            lower.contains("zdieľaj polohu") || lower.contains("pošli polohu") -> VoiceIntent.SHARE_LOCATION
            lower.contains("kúp lístok") || lower.contains("kúp lístok") ||
                lower.contains("kúpiť lístok") -> VoiceIntent.PURCHASE_TICKET
            lower.contains("rezerváciu") || lower.contains("rezervácia") -> VoiceIntent.OPEN_BOOKING
            lower.contains("spoj") || lower.contains("vlak") || lower.contains("autobus") ||
                lower.contains("let") -> VoiceIntent.SEARCH_TRANSIT
            lower.contains("cenu") || lower.contains("náklady") || lower.contains("spotrebu") ->
                VoiceIntent.CALCULATE_TRIP_COST
            lower.contains("cieľ") || lower.contains("naviguj") || lower.contains("do ") ->
                VoiceIntent.SET_DESTINATION
            else -> VoiceIntent.UNKNOWN
        }
    }
}
