package com.oli.routesave.ui

data class ScreenContentSpec(
    val screen: AppScreen,
    val title: String,
    val primaryAction: String? = null,
    val secondaryActions: List<String> = emptyList()
)

object ScreenContentCatalog {
    fun forScreen(screen: AppScreen): ScreenContentSpec = when (screen) {
        AppScreen.HOME -> ScreenContentSpec(
            screen, "OLI RouteSave",
            primaryAction = "Spustiť jazdu",
            secondaryActions = listOf("Trasa", "Vozidlo", "Asistent")
        )
        AppScreen.ROUTE -> ScreenContentSpec(
            screen, "Trasa",
            primaryAction = "Naplánovať trasu",
            secondaryActions = listOf("Náklady", "Mýto", "Parkovanie")
        )
        AppScreen.VEHICLE -> ScreenContentSpec(
            screen, "Profil vozidla",
            primaryAction = "Uložiť vozidlo",
            secondaryActions = listOf("Spotreba", "Cena paliva")
        )
        AppScreen.ASSISTANT -> ScreenContentSpec(
            screen, "Hlasový asistent",
            primaryAction = "Nastaviť asistenta",
            secondaryActions = listOf("Oslovenie", "Hlas", "Proaktivita")
        )
        AppScreen.COMMUNITY -> ScreenContentSpec(
            screen, "Ľudia pomáhajú ľuďom",
            primaryAction = "Nájsť pomoc",
            secondaryActions = listOf("Upozornenia", "Dôvera", "Pomoc v okolí")
        )
        AppScreen.TRIP_HISTORY -> ScreenContentSpec(
            screen, "História jázd",
            secondaryActions = listOf("Náklady", "Trasy")
        )
        AppScreen.SETTINGS -> ScreenContentSpec(
            screen, "Nastavenia",
            secondaryActions = listOf("Jazyk", "Hlas", "Truck režim", "Komunita")
        )
    }
}
