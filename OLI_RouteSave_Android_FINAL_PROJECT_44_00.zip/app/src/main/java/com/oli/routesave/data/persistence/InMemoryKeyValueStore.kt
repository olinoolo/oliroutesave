package com.oli.routesave.data.persistence
class InMemoryKeyValueStore:KeyValueStore {
    private val values=mutableMapOf<String,String>()
    override fun getString(key:String,default:String)=values[key]?:default
    override fun putString(key:String,value:String){values[key]=value}
    override fun getBoolean(key:String,default:Boolean)=values[key]?.toBooleanStrictOrNull()?:default
    override fun putBoolean(key:String,value:Boolean){values[key]=value.toString()}
    override fun remove(key:String){values.remove(key)}
}
