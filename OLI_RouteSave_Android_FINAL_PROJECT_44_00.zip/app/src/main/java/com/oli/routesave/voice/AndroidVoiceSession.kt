package com.oli.routesave.voice

import android.content.Context
import com.oli.routesave.voice.android.AndroidSpeechInput
import com.oli.routesave.voice.android.AndroidSpeechOutput

/**
 * Lifecycle-aware bridge between Android speech adapters and the voice
 * coordinator. The owning Activity/Composable must call startListening only
 * after permission has been granted and must call close() when disposed.
 *
 * The bridge does not execute phone, SMS, location, purchase or booking actions.
 */
class AndroidVoiceSession(
    context: Context,
    private val coordinator: VoiceInteractionCoordinator,
    private val onStateChanged: (VoiceInteractionState) -> Unit
) {
    private val speechOutput = AndroidSpeechOutput(context) { ready ->
        if (!ready) {
            val updated = coordinator.dispatch(
                VoiceInteractionEvent.RecognitionError("Hlasový výstup nie je na tomto zariadení pripravený.")
            )
            onStateChanged(updated)
        }
    }

    private val speechInput = AndroidSpeechInput(
        context = context,
        onPartialText = { text ->
            onStateChanged(coordinator.dispatch(VoiceInteractionEvent.PartialSpeech(text)))
        },
        onFinalText = { text ->
            val state = coordinator.dispatch(VoiceInteractionEvent.FinalSpeech(text))
            onStateChanged(state)
            if (state.replyText.isNotBlank()) {
                speechOutput.speak(state.replyText, "sk-SK")
            }
        },
        onErrorMessage = { message ->
            val state = coordinator.dispatch(VoiceInteractionEvent.RecognitionError(message))
            onStateChanged(state)
            if (state.replyText.isNotBlank()) speechOutput.speak(state.replyText, "sk-SK")
        }
    )

    fun isSpeechRecognitionAvailable(): Boolean = speechInput.isAvailable()
    fun hasMicrophonePermission(): Boolean = speechInput.hasMicrophonePermission()

    fun startListening() {
        if (!speechInput.hasMicrophonePermission()) {
            val state = coordinator.dispatch(
                VoiceInteractionEvent.RecognitionError("Najprv povoľ mikrofón v nastaveniach aplikácie.")
            )
            onStateChanged(state)
            speechOutput.speak(state.replyText, "sk-SK")
            return
        }
        onStateChanged(coordinator.dispatch(VoiceInteractionEvent.StartListening))
        speechInput.start("sk-SK")
    }

    fun stopListening() {
        speechInput.stop()
        onStateChanged(coordinator.dispatch(VoiceInteractionEvent.StopListening))
    }

    fun stopSpeaking() {
        speechOutput.stop()
    }

    fun close() {
        speechInput.stop()
        speechOutput.shutdown()
    }
}
