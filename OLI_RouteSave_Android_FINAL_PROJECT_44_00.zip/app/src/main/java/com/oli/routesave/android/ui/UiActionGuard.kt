package com.oli.routesave.android.ui

/**
 * UI guard only. External actions still require the assistant-first confirmation
 * policy in the domain/runtime layer.
 */
class UiActionGuard {
    fun canStartDrive(locationReady: Boolean): Boolean = locationReady
    fun canUseVoice(microphoneGranted: Boolean): Boolean = microphoneGranted
}
