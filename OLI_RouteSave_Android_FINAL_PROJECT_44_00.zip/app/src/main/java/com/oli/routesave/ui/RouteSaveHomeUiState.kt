package com.oli.routesave.ui

data class RouteSaveHomeUiState(
    val appName: String = "OLI RouteSave",
    val slogan: String = "Save money. Travel smarter.",
    val origin: String = "",
    val destination: String = "",
    val selectedAssistantName: String = "Nikolas",
    val selectedAssistantInvocation: String = "Niko",
    val voiceStatus: String = "Hlasový asistent je pripravený po zapnutí.",
    val isVoiceEnabled: Boolean = false,
    val estimatedTripCostText: String = "Zadaj trasu a vozidlo na výpočet nákladov.",
    val vehicleSummary: String = "Vozidlo zatiaľ nie je vybrané.",
    val activeSection: HomeSection = HomeSection.HOME
)

enum class HomeSection {
    HOME, VEHICLE, ASSISTANT_SETTINGS, TRAVEL_COMPARE, COMMUNITY_HELP
}

sealed interface HomeActionResult {
    data class Updated(val state: RouteSaveHomeUiState) : HomeActionResult
    data class Rejected(val reason: String) : HomeActionResult
}
