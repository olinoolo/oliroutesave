package com.oli.routesave.communication

/**
 * Requested channel for a call. VIDEO is a call mode, not a separate provider:
 * a provider may or may not support it.
 */
enum class CallChannel {
    PHONE,
    WHATSAPP,
    MESSENGER
}

enum class CallMode {
    AUDIO,
    VIDEO
}

data class CallRequest(
    val destination: CallDestination,
    val channel: CallChannel,
    val mode: CallMode
)

sealed interface CallDestination {
    data class Contact(val displayName: String, val canonicalId: String? = null) : CallDestination
    data class PhoneNumber(val normalizedNumber: String) : CallDestination
}

data class CallCapability(
    val available: Boolean,
    val supportsAudio: Boolean,
    val supportsVideo: Boolean,
    val explanation: String? = null
)

sealed interface CallPreparationResult {
    data class Ready(val launchToken: String) : CallPreparationResult
    data class Unavailable(val reason: String) : CallPreparationResult
    data class NeedsClarification(val question: String) : CallPreparationResult
}

sealed interface CallLaunchResult {
    data object Started : CallLaunchResult
    data class Failed(val reason: String) : CallLaunchResult
}
