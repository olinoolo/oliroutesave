package com.oli.routesave.ui

data class MapCamera(
    val latitude: Double,
    val longitude: Double,
    val zoom: Double = 14.0
)

interface MapProvider {
    fun initialize()
    fun setCamera(camera: MapCamera)
    fun showUserLocation(enabled: Boolean)
    fun drawRoute(points: List<Pair<Double, Double>>)
    fun clearRoute()
}
