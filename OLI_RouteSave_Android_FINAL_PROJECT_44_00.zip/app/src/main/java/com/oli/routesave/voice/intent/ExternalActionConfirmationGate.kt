package com.oli.routesave.voice.intent

enum class ExternalActionType {
    CALL, SEND_MESSAGE, SHARE_LOCATION, COMMUNITY_HELP_REQUEST, CONTACT_SERVICE
}

data class PendingExternalAction(
    val actionType: ExternalActionType,
    val spokenSummary: String,
    val createdAtEpochMillis: Long
)

/**
 * Small pure gate: an external action cannot be authorized without explicit
 * confirmation for that specific pending action.
 */
class ExternalActionConfirmationGate {
    private var pending: PendingExternalAction? = null

    fun requestConfirmation(action: PendingExternalAction): String {
        pending = action
        return "Chceš pokračovať? ${action.spokenSummary} Povedz áno alebo nie."
    }

    fun confirm(affirmative: Boolean): PendingExternalAction? {
        val action = pending ?: return null
        pending = null
        return if (affirmative) action else null
    }

    fun cancel() {
        pending = null
    }

    fun hasPendingAction(): Boolean = pending != null
}
