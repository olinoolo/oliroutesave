package com.oli.routesave.data

import com.oli.routesave.data.model.TripRecord
import com.oli.routesave.data.store.TripStore
import com.oli.routesave.data.store.VehicleStore

class VehicleTripService(
    private val vehicleStore: VehicleStore,
    private val tripStore: TripStore
) {
    fun calculateAndSaveTrip(
        id: String,
        origin: String,
        destination: String,
        distanceKm: Double,
        vehicleId: String?,
        consumptionOverrideL100Km: Double? = null,
        fuelPriceOverride: Double? = null,
        tollCost: Double = 0.0,
        parkingCost: Double = 0.0,
        createdAtEpochMs: Long
    ): TripRecord {
        val vehicle = vehicleId?.let(vehicleStore::get)
        val consumption = consumptionOverrideL100Km
            ?: vehicle?.averageConsumptionL100Km
            ?: 0.0
        val fuelPrice = fuelPriceOverride
            ?: vehicle?.fuelPricePerLiter
            ?: 0.0

        val fuelCost = TripCostCalculator.fuelCost(
            distanceKm, consumption, fuelPrice
        )

        val trip = TripRecord(
            id = id,
            vehicleId = vehicleId,
            origin = origin,
            destination = destination,
            distanceKm = distanceKm,
            consumptionL100Km = consumption,
            fuelPricePerLiter = fuelPrice,
            fuelCost = fuelCost,
            tollCost = tollCost,
            parkingCost = parkingCost,
            createdAtEpochMs = createdAtEpochMs
        )
        tripStore.save(trip)
        return trip
    }
}
