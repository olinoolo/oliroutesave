package com.oli.routesave.ui

import com.oli.routesave.data.model.VehicleProfile
import com.oli.routesave.data.persistence.VehicleRepository
import com.oli.routesave.voice.assistant.AssistantProfileCatalog
import com.oli.routesave.voice.assistant.VoiceAssistantSettingsController

/**
 * UI state controller for the first OLI RouteSave home screen.
 * It is framework-independent and can be connected to Compose later.
 */
class RouteSaveHomeController(
    private val vehicleRepository: VehicleRepository,
    private val assistantSettings: VoiceAssistantSettingsController
) {
    private var state = RouteSaveHomeUiState()

    fun currentState(): RouteSaveHomeUiState = state

    fun refresh(): RouteSaveHomeUiState {
        val settings = assistantSettings.current()
        val profile = AssistantProfileCatalog.byId(settings.selectedAssistantId)
        val vehicle = vehicleRepository.defaultVehicle()
        state = state.copy(
            selectedAssistantName = profile?.displayName ?: "Nikolas",
            selectedAssistantInvocation = profile?.invocationName ?: "Niko",
            isVoiceEnabled = settings.handsFreeEnabled,
            voiceStatus = if (settings.handsFreeEnabled) {
                "Hands-free je zapnuté; mikrofón a oprávnenia sa overia pri spustení."
            } else {
                "Hlasový asistent je vypnutý."
            },
            vehicleSummary = vehicle?.let(::formatVehicle)
                ?: "Vozidlo zatiaľ nie je vybrané."
        )
        return state
    }

    fun setRoute(origin: String, destination: String): HomeActionResult {
        val cleanOrigin = origin.trim()
        val cleanDestination = destination.trim()
        if (cleanOrigin.length > MAX_LOCATION_LENGTH || cleanDestination.length > MAX_LOCATION_LENGTH) {
            return HomeActionResult.Rejected("Názov miesta je príliš dlhý.")
        }
        state = state.copy(origin = cleanOrigin, destination = cleanDestination)
        return HomeActionResult.Updated(state)
    }

    fun navigateTo(section: HomeSection): RouteSaveHomeUiState {
        state = state.copy(activeSection = section)
        return state
    }

    fun setEstimatedTripCost(text: String): HomeActionResult {
        if (text.length > MAX_COST_TEXT_LENGTH) {
            return HomeActionResult.Rejected("Text odhadu je príliš dlhý.")
        }
        state = state.copy(estimatedTripCostText = text)
        return HomeActionResult.Updated(state)
    }

    private fun formatVehicle(vehicle: VehicleProfile): String {
        val name = listOf(vehicle.brand, vehicle.model).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { vehicle.name }
        return "$name • ${vehicle.averageConsumptionL100Km} l/100 km"
    }

    companion object {
        private const val MAX_LOCATION_LENGTH = 120
        private const val MAX_COST_TEXT_LENGTH = 240
    }
}
