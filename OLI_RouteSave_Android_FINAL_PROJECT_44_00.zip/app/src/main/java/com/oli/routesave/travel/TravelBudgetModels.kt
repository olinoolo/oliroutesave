package com.oli.routesave.travel

data class TravelBudget(
    val monthlyLimit: Double,
    val currencyCode: String = "EUR",
    val updatedAtEpochMs: Long = System.currentTimeMillis()
) {
    fun validate(): List<String> = buildList {
        if (!monthlyLimit.isFinite() || monthlyLimit < 0.0 || monthlyLimit > 100_000_000.0) {
            add("Mesačný rozpočet musí byť od 0 do 100 000 000.")
        }
        if (currencyCode !in setOf("EUR", "CZK", "USD", "GBP", "PLN", "HUF", "RON")) {
            add("Nepodporovaná mena.")
        }
        if (updatedAtEpochMs < 0) add("Neplatný dátum úpravy rozpočtu.")
    }
}

enum class BudgetStatus {
    NO_BUDGET, ON_TRACK, NEAR_LIMIT, OVER_LIMIT
}

data class TravelBudgetOverview(
    val budget: TravelBudget?,
    val spent: Double,
    val remaining: Double?,
    val percentUsed: Double?,
    val status: BudgetStatus,
    val tripCount: Int,
    val currencyCode: String
)
