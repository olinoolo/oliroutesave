package com.oli.routesave.ui

class AppNavigator(initial: AppScreen = AppScreen.HOME) {
    private var current = initial
    private val history = ArrayDeque<AppScreen>()

    fun current(): AppScreen = current

    fun navigate(to: AppScreen) {
        if (to == current) return
        history.addLast(current)
        current = to
    }

    fun back(): AppScreen {
        if (history.isNotEmpty()) current = history.removeLast()
        return current
    }
}
