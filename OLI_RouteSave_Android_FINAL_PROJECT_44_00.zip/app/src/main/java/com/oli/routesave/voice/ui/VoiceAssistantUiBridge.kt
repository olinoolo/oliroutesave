package com.oli.routesave.voice.ui

import com.oli.routesave.voice.assistant.AssistantOutcome
import com.oli.routesave.voice.assistant.AssistantProfile
import com.oli.routesave.voice.assistant.VoiceAssistantCoordinator
import com.oli.routesave.voice.intent.ExternalActionType
import com.oli.routesave.voice.intent.PendingExternalAction

/**
 * Bridges voice input to UI state and assistant speech.
 * It deliberately does not execute phone, SMS, location-sharing or community actions.
 */
class VoiceAssistantUiBridge(
    private val coordinator: VoiceAssistantCoordinator,
    private val speechOutput: AssistantSpeechOutput,
    private val onRouteRequested: (String?) -> Unit = {},
    private val onFuelEstimateRequested: () -> Unit = {},
    private val onApprovedExternalAction: (PendingExternalAction) -> Unit = {},
    private val onStateChanged: (AssistantUiState) -> Unit = {}
) {
    var state: AssistantUiState = AssistantUiState()
        private set

    fun onListeningStarted() {
        speechOutput.stop()
        update(AssistantUiState(AssistantUiPhase.LISTENING, "Počúvam…"))
    }

    fun onProcessingStarted() {
        update(state.copy(phase = AssistantUiPhase.PROCESSING, statusText = "Spracúvam príkaz…"))
    }

    fun onRecognition(text: String, assistant: AssistantProfile) {
        update(state.copy(
            phase = AssistantUiPhase.PROCESSING,
            statusText = "Rozumiem, vyhodnocujem príkaz…",
            lastRecognizedText = text,
            errorMessage = null
        ))
        when (val outcome = coordinator.handleSpeech(text, assistant)) {
            is AssistantOutcome.Speak -> speak(outcome.text, outcome.languageTag)
            is AssistantOutcome.NeedsClarification -> speak(outcome.text, outcome.languageTag)
            is AssistantOutcome.AwaitingConfirmation -> {
                val type = when {
                    outcome.prompt.contains("Zavolať kontaktu") -> ExternalActionType.CALL
                    outcome.prompt.contains("správu pre") -> ExternalActionType.SEND_MESSAGE
                    outcome.prompt.contains("Zdieľať tvoju polohu") -> ExternalActionType.SHARE_LOCATION
                    else -> ExternalActionType.COMMUNITY_HELP_REQUEST
                }
                update(AssistantUiState(
                    phase = AssistantUiPhase.WAITING_FOR_CONFIRMATION,
                    statusText = "Čakám na tvoje potvrdenie",
                    lastRecognizedText = text,
                    lastResponse = outcome.prompt,
                    pendingAction = type
                ))
                speechOutput.speak(outcome.prompt, outcome.languageTag)
            }
            is AssistantOutcome.RouteRequested -> {
                onRouteRequested(outcome.destination)
                speak("Pripravujem trasu do ${outcome.destination}.", outcome.assistant.languageTag)
            }
            is AssistantOutcome.FuelEstimateRequested -> {
                onFuelEstimateRequested()
                speak("Pripravujem odhad ceny paliva.", outcome.assistant.languageTag)
            }
            is AssistantOutcome.ExternalActionApproved -> {
                onApprovedExternalAction(outcome.action)
                speak("Potvrdenie prijaté. Pripravujem ďalší krok.", outcome.assistant.languageTag)
            }
            AssistantOutcome.NoPendingConfirmation -> {
                speak("Nie je pripravená žiadna akcia na potvrdenie.", assistant.languageTag)
            }
        }
    }

    fun confirm(yes: Boolean, assistant: AssistantProfile) {
        if (!state.needsConfirmation) {
            speak("Momentálne nemám žiadnu akciu na potvrdenie.", assistant.languageTag)
            return
        }
        update(state.copy(
            phase = AssistantUiPhase.PROCESSING,
            statusText = if (yes) "Potvrdzuješ akciu…" else "Ruším akciu…",
            pendingAction = null
        ))
        when (val outcome = coordinator.confirmExternalAction(yes, assistant)) {
            is AssistantOutcome.ExternalActionApproved -> {
                update(state.copy(
                    phase = AssistantUiPhase.READY,
                    statusText = "Akcia potvrdená",
                    lastResponse = "Potvrdenie prijaté."
                ))
                onApprovedExternalAction(outcome.action)
                speechOutput.speak("Potvrdenie prijaté. Akcia bude pripravená na vykonanie.", assistant.languageTag)
            }
            is AssistantOutcome.Speak -> {
                update(state.copy(
                    phase = AssistantUiPhase.READY,
                    statusText = if (yes) "Pripravené" else "Akcia zrušená",
                    lastResponse = outcome.text,
                    pendingAction = null
                ))
                speechOutput.speak(outcome.text, outcome.languageTag)
            }
            else -> {
                update(AssistantUiState())
            }
        }
    }

    fun onError(message: String) {
        speechOutput.stop()
        update(state.copy(
            phase = AssistantUiPhase.ERROR,
            statusText = "Hlasové ovládanie potrebuje pozornosť",
            errorMessage = message
        ))
    }

    fun reset() {
        coordinator.cancelPendingAction()
        speechOutput.stop()
        update(AssistantUiState())
    }

    private fun speak(text: String, languageTag: String) {
        update(state.copy(phase = AssistantUiPhase.SPEAKING, statusText = text, lastResponse = text))
        speechOutput.speak(text, languageTag)
    }

    private fun update(newState: AssistantUiState) {
        state = newState
        onStateChanged(newState)
    }
}
