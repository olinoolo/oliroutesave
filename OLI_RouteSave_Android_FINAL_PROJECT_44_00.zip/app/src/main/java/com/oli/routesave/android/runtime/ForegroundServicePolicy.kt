package com.oli.routesave.android.runtime
class ForegroundServicePolicy{
 fun shouldRunForegroundService(driveActive:Boolean,navigationActive:Boolean,locationActive:Boolean)=driveActive&&(navigationActive||locationActive)
 fun shouldStopForegroundService(driveActive:Boolean,emergencyFinished:Boolean)=!driveActive||emergencyFinished
}
