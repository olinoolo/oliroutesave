package com.oli.routesave.communication

/**
 * Creates a pending communication action and requires an explicit, time-limited
 * confirmation. This layer prepares the request only; a provider/launcher must
 * separately verify confirmation before opening another app or starting a call.
 */
class CommunicationConfirmationFlow(
    private val timeoutMillis: Long = 30_000L,
    private val nowMillis: () -> Long = { System.currentTimeMillis() }
) {
    private var pending: PendingCommunication? = null

    @Synchronized
    fun request(request: CommunicationRequest): CommunicationConfirmationResult {
        when (val validation = request.validate()) {
            is CommunicationValidation.Invalid ->
                return CommunicationConfirmationResult.Rejected(validation.reason)
            CommunicationValidation.Valid -> Unit
        }

        val confirmation = CommunicationConfirmation(
            token = nextToken(),
            prompt = promptFor(request),
            expiresAtMillis = nowMillis() + timeoutMillis
        )
        pending = PendingCommunication(confirmation, request)
        return CommunicationConfirmationResult.Awaiting(confirmation)
    }

    @Synchronized
    fun respond(token: String, answer: String): CommunicationConfirmationResult {
        val current = pending
            ?: return CommunicationConfirmationResult.Rejected("Nie je žiadna čakajúca akcia.")
        if (current.confirmation.token != token) {
            return CommunicationConfirmationResult.Rejected("Potvrdenie už nie je platné.")
        }
        if (nowMillis() > current.confirmation.expiresAtMillis) {
            pending = null
            return CommunicationConfirmationResult.Rejected("Čas na potvrdenie vypršal. Požiadaj znova.")
        }

        return when (normalize(answer)) {
            "ano", "ano potvrdzujem", "potvrdzujem" -> {
                pending = null
                CommunicationConfirmationResult.Confirmed(current.request)
            }
            "nie", "zrus", "zrus to", "nie dakujem" -> {
                pending = null
                CommunicationConfirmationResult.Cancelled
            }
            else -> CommunicationConfirmationResult.Awaiting(
                current.confirmation.copy(
                    prompt = "Prosím, povedz jasne áno alebo nie. ${current.confirmation.prompt}"
                )
            )
        }
    }

    @Synchronized
    fun cancel() {
        pending = null
    }

    private fun promptFor(request: CommunicationRequest): String {
        val recipient = request.recipientDisplayName.trim()
            .ifEmpty { request.destinationNumber?.trim().orEmpty() }
        val channel = when (request.channel) {
            CommunicationChannel.PHONE -> "telefonicky"
            CommunicationChannel.WHATSAPP -> "cez WhatsApp"
            CommunicationChannel.MESSENGER -> "cez Messenger"
            CommunicationChannel.SMS -> "cez SMS"
        }
        val action = when (request.mode) {
            CommunicationMode.AUDIO_CALL -> "uskutočniť hlasový hovor"
            CommunicationMode.VIDEO_CALL -> "spustiť videohovor"
            CommunicationMode.TEXT_MESSAGE -> "odoslať správu"
        }
        val message = request.messageText?.let { " s textom: ${it.trim()}" }.orEmpty()
        return "Mám $action pre $recipient $channel$message? Povedz áno alebo nie."
    }

    private fun normalize(value: String): String =
        java.text.Normalizer.normalize(value.trim().lowercase(), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("[.!?,;:]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()

    private fun nextToken(): String = "comm-${nowMillis()}-${counter++}"

    private data class PendingCommunication(
        val confirmation: CommunicationConfirmation,
        val request: CommunicationRequest
    )

    companion object {
        private var counter: Long = 1L
    }
}

data class CommunicationConfirmation(
    val token: String,
    val prompt: String,
    val expiresAtMillis: Long
)

sealed interface CommunicationConfirmationResult {
    data class Awaiting(val confirmation: CommunicationConfirmation) : CommunicationConfirmationResult
    data class Confirmed(val request: CommunicationRequest) : CommunicationConfirmationResult
    data object Cancelled : CommunicationConfirmationResult
    data class Rejected(val reason: String) : CommunicationConfirmationResult
}
