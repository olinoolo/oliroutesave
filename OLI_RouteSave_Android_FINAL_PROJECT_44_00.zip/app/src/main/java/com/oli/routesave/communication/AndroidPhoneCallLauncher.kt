package com.oli.routesave.communication

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

/**
 * Android phone adapter. OPEN_DIALER is the default safe route.
 * DIRECT_CALL is only attempted after confirmation and when CALL_PHONE is
 * already granted. This class does not request permissions itself.
 */
class AndroidPhoneCallLauncher(
    private val context: Context
) : PhoneCallLauncher {

    override suspend fun launch(request: PhoneLaunchRequest): PhoneLaunchOutcome {
        if (!request.confirmedByUser) {
            return PhoneLaunchOutcome.Rejected("Pred telefonovaním je potrebné jasné potvrdenie.")
        }
        if (!PhoneNumberSanitizer.looksPlausible(request.normalizedNumber)) {
            return PhoneLaunchOutcome.Rejected("Telefónne číslo nie je dostatočne platné.")
        }

        val uri = Uri.fromParts("tel", request.normalizedNumber, null)
        val intent = when (request.mode) {
            PhoneLaunchMode.OPEN_DIALER -> Intent(Intent.ACTION_DIAL, uri)
            PhoneLaunchMode.DIRECT_CALL -> {
                val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                } else true
                if (!granted) return PhoneLaunchOutcome.PermissionRequired(Manifest.permission.CALL_PHONE)
                Intent(Intent.ACTION_CALL, uri)
            }
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        return try {
            if (intent.resolveActivity(context.packageManager) == null) {
                PhoneLaunchOutcome.Rejected("V zariadení sa nenašla aplikácia na telefonovanie.")
            } else {
                context.startActivity(intent)
                when (request.mode) {
                    PhoneLaunchMode.OPEN_DIALER -> PhoneLaunchOutcome.DialerOpened
                    PhoneLaunchMode.DIRECT_CALL -> PhoneLaunchOutcome.CallRequested
                }
            }
        } catch (security: SecurityException) {
            PhoneLaunchOutcome.PermissionRequired(
                if (request.mode == PhoneLaunchMode.DIRECT_CALL) Manifest.permission.CALL_PHONE
                else "android.intent.action.DIAL"
            )
        } catch (exception: Exception) {
            PhoneLaunchOutcome.Rejected("Telefonickú aplikáciu sa nepodarilo spustiť.")
        }
    }
}
