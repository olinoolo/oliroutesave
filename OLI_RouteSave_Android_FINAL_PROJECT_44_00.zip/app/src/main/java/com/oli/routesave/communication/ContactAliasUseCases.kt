package com.oli.routesave.communication

/** Validates and manages user-created aliases such as "manželka" or "brat". */
class ContactAliasUseCases(private val repository: ContactAliasRepository) {
    sealed interface SaveResult {
        data class Saved(val alias: ContactAlias) : SaveResult
        data class Rejected(val reason: String) : SaveResult
    }
    suspend fun saveAlias(aliasText: String, contact: ContactCandidate): SaveResult {
        val cleanAlias = aliasText.trim().replace(Regex("\\s+"), " ")
        if (cleanAlias.isBlank()) return SaveResult.Rejected("Zadaj pomenovanie kontaktu.")
        if (cleanAlias.length > 40) return SaveResult.Rejected("Pomenovanie môže mať najviac 40 znakov.")
        if (contact.contactId.isBlank() || contact.displayName.isBlank())
            return SaveResult.Rejected("Vybraný kontakt nie je platný.")
        val alias = ContactAlias(cleanAlias, contact.contactId, contact.displayName)
        repository.save(alias)
        return SaveResult.Saved(alias)
    }
    suspend fun listAliases(): List<ContactAlias> = repository.allAliases()
    suspend fun deleteAlias(aliasText: String) = repository.remove(aliasText)
}
