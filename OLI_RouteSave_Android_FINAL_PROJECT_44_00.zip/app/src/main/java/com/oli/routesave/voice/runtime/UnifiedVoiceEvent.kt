package com.oli.routesave.voice.runtime

data class UnifiedVoiceEvent(
    val type: UnifiedVoiceEventType,
    val text: String? = null,
    val requiresConfirmation: Boolean = false
)
