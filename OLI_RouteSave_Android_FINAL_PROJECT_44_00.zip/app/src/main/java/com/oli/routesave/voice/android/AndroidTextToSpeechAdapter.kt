package com.oli.routesave.voice.android

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Android TextToSpeech output adapter.
 * The UI should expose readiness/errors and always stop speech for urgent alerts.
 */
class AndroidTextToSpeechAdapter(
    context: Context,
    private val onReady: (Boolean) -> Unit = {}
) : VoiceOutputProvider, TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(appContext, this)
    private var ready = false
    private var pending: Pair<String, String>? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        onReady(ready)
        if (ready) {
            pending?.let { (text, languageTag) -> speak(text, languageTag) }
            pending = null
        }
    }

    override fun speak(text: String, languageTag: String) {
        val engine = tts ?: return
        if (!ready) {
            pending = text to languageTag
            return
        }
        val locale = Locale.forLanguageTag(languageTag)
        val languageResult = engine.setLanguage(locale)
        if (languageResult == TextToSpeech.LANG_MISSING_DATA ||
            languageResult == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            onReady(false)
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "oli-routesave-${System.nanoTime()}")
    }

    override fun stop() {
        tts?.stop()
    }

    override fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        pending = null
    }
}
