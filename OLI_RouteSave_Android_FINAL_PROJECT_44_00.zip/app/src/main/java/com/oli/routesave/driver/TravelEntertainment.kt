package com.oli.routesave.driver

enum class EntertainmentType {
    MUSIC, PODCAST, AUDIOBOOK, QUIZ, WORD_GAME, TRAVEL_FACT
}

data class EntertainmentItem(
    val id: String,
    val title: String,
    val type: EntertainmentType,
    val description: String? = null,
    val durationMinutes: Int? = null,
    val sourceUrl: String? = null
)

data class DrivingSafetyContext(
    val driving: Boolean,
    val navigationCritical: Boolean,
    val activeCall: Boolean,
    val emergencyActive: Boolean
)

enum class EntertainmentAction {
    PLAY_AUDIO,
    START_VOICE_QUIZ,
    START_WORD_GAME,
    READ_TRAVEL_FACT,
    PAUSE_OR_DEFER
}

object EntertainmentSafetyPolicy {
    /**
     * Keeps attention-heavy interactions out of critical moments. The app
     * should prefer audio-only interaction while moving.
     */
    fun chooseAction(
        type: EntertainmentType,
        context: DrivingSafetyContext
    ): EntertainmentAction {
        if (context.emergencyActive || context.activeCall || context.navigationCritical) {
            return EntertainmentAction.PAUSE_OR_DEFER
        }
        if (context.driving) {
            return when (type) {
                EntertainmentType.MUSIC,
                EntertainmentType.PODCAST,
                EntertainmentType.AUDIOBOOK,
                EntertainmentType.TRAVEL_FACT -> EntertainmentAction.PLAY_AUDIO
                EntertainmentType.QUIZ -> EntertainmentAction.START_VOICE_QUIZ
                EntertainmentType.WORD_GAME -> EntertainmentAction.PAUSE_OR_DEFER
            }
        }
        return when (type) {
            EntertainmentType.MUSIC,
            EntertainmentType.PODCAST,
            EntertainmentType.AUDIOBOOK -> EntertainmentAction.PLAY_AUDIO
            EntertainmentType.QUIZ -> EntertainmentAction.START_VOICE_QUIZ
            EntertainmentType.WORD_GAME -> EntertainmentAction.START_WORD_GAME
            EntertainmentType.TRAVEL_FACT -> EntertainmentAction.READ_TRAVEL_FACT
        }
    }
}
