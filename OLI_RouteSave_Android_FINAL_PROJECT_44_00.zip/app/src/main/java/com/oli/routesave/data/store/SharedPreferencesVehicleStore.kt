package com.oli.routesave.data.store

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import com.oli.routesave.data.model.VehicleProfile

/**
 * Durable, app-private vehicle storage.
 *
 * Stores only vehicle profile fields needed by OLI RouteSave. This adapter is
 * intentionally synchronous to match VehicleStore; for a large fleet/database,
 * replace it with Room and a coroutine-based repository.
 */
class SharedPreferencesVehicleStore(
    context: Context,
    preferencesName: String = DEFAULT_PREFERENCES_NAME
) : VehicleStore {

    private val preferences: SharedPreferences =
        context.applicationContext.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
    private val lock = Any()

    override fun save(vehicle: VehicleProfile) {
        require(vehicle.id.isNotBlank()) { "Vehicle ID is required." }
        require(vehicle.name.isNotBlank()) { "Vehicle name is required." }
        require(vehicle.averageConsumptionL100Km.isFinite() &&
            vehicle.averageConsumptionL100Km in 0.0..100.0) {
            "Consumption must be between 0 and 100 l/100 km."
        }
        require(vehicle.fuelPricePerLiter.isFinite() &&
            vehicle.fuelPricePerLiter in 0.0..20.0) {
            "Fuel price must be between 0 and 20 per litre."
        }

        synchronized(lock) {
            val values = readAllUnlocked().toMutableMap()
            if (vehicle.isDefault) {
                values.replaceAll { _, value -> value.copy(isDefault = false) }
            }
            values[vehicle.id] = vehicle
            val editor = preferences.edit().clear()
            values.values.forEach { item ->
                editor.putString(KEY_PREFIX + item.id, encode(item))
            }
            editor.apply()
        }
    }

    override fun get(id: String): VehicleProfile? = synchronized(lock) {
        preferences.getString(KEY_PREFIX + id, null)?.let(::decodeOrNull)
    }

    override fun getAll(): List<VehicleProfile> = synchronized(lock) {
        readAllUnlocked().values.sortedBy { it.name.lowercase() }
    }

    override fun getDefault(): VehicleProfile? = synchronized(lock) {
        readAllUnlocked().values.firstOrNull { it.isDefault }
    }

    override fun delete(id: String) {
        synchronized(lock) {
            preferences.edit().remove(KEY_PREFIX + id).apply()
        }
    }

    private fun readAllUnlocked(): Map<String, VehicleProfile> =
        preferences.all.entries
            .asSequence()
            .filter { it.key.startsWith(KEY_PREFIX) }
            .mapNotNull { entry ->
                val raw = entry.value as? String ?: return@mapNotNull null
                decodeOrNull(raw)?.let { it.id to it }
            }
            .toMap()

    private fun encode(vehicle: VehicleProfile): String =
        JSONObject()
            .put("id", vehicle.id)
            .put("name", vehicle.name)
            .put("brand", vehicle.brand)
            .put("model", vehicle.model)
            .put("fuelType", vehicle.fuelType)
            .put("averageConsumptionL100Km", vehicle.averageConsumptionL100Km)
            .put("fuelPricePerLiter", vehicle.fuelPricePerLiter)
            .put("isDefault", vehicle.isDefault)
            .toString()

    private fun decodeOrNull(raw: String): VehicleProfile? = try {
        val json = JSONObject(raw)
        val id = json.optString("id").trim()
        val name = json.optString("name").trim()
        val consumption = json.optDouble("averageConsumptionL100Km", Double.NaN)
        val price = json.optDouble("fuelPricePerLiter", Double.NaN)
        if (id.isEmpty() || name.isEmpty() ||
            !consumption.isFinite() || consumption !in 0.0..100.0 ||
            !price.isFinite() || price !in 0.0..20.0) {
            null
        } else {
            VehicleProfile(
                id = id,
                name = name,
                brand = json.optString("brand"),
                model = json.optString("model"),
                fuelType = json.optString("fuelType", "PETROL"),
                averageConsumptionL100Km = consumption,
                fuelPricePerLiter = price,
                isDefault = json.optBoolean("isDefault", false)
            )
        }
    } catch (_: Exception) {
        null
    }

    companion object {
        const val DEFAULT_PREFERENCES_NAME = "oli_routesave_vehicle_profiles"
        private const val KEY_PREFIX = "vehicle:"
    }
}
