package com.oli.routesave.voice.assistant

/**
 * UI-facing controller for assistant preferences. It uses the existing
 * settings manager, so validation and supported-language checks stay in
 * one place.
 */
class VoiceAssistantSettingsController(
    private val manager: VoiceAssistantSettingsManager
) {
    fun current(): VoiceAssistantSettings = manager.current()

    fun availableAssistants(): List<AssistantProfile> = AssistantProfileCatalog.all()

    fun selectAssistant(id: String): AssistantSettingsResult = manager.selectAssistant(id)

    fun update(
        handsFreeEnabled: Boolean? = null,
        allowOptionalWakeWord: Boolean? = null,
        conciseResponses: Boolean? = null,
        romanticModeEnabled: Boolean? = null,
        languageTag: String? = null
    ): AssistantSettingsResult = manager.update(
        handsFreeEnabled = handsFreeEnabled,
        allowOptionalWakeWord = allowOptionalWakeWord,
        conciseResponses = conciseResponses,
        romanticModeEnabled = romanticModeEnabled,
        languageTag = languageTag
    )
}
