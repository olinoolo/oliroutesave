package com.oli.routesave.communication

/**
 * Builds a short spoken read-back so the selected assistant can ask for clear
 * confirmation before a phone call is launched.
 */
object CallConfirmationReadback {
    fun contactAudioCall(displayName: String, assistantInvocation: String): String {
        val safeName = displayName.trim().ifEmpty { "vybranému kontaktu" }
        val safeInvocation = assistantInvocation.trim().ifEmpty { "Asistent" }
        return "$safeInvocation: Mám zavolať kontaktu $safeName? Povedz áno alebo nie."
    }

    fun contactVideoCall(displayName: String, channelLabel: String, assistantInvocation: String): String {
        val safeName = displayName.trim().ifEmpty { "vybranému kontaktu" }
        val safeChannel = channelLabel.trim().ifEmpty { "vybranou aplikáciou" }
        val safeInvocation = assistantInvocation.trim().ifEmpty { "Asistent" }
        return "$safeInvocation: Mám spustiť videohovor s kontaktom $safeName cez $safeChannel? Povedz áno alebo nie."
    }

    fun phoneNumberCall(maskedNumber: String, assistantInvocation: String): String {
        val safeNumber = maskedNumber.trim().ifEmpty { "nadiktované číslo" }
        val safeInvocation = assistantInvocation.trim().ifEmpty { "Asistent" }
        return "$safeInvocation: Mám zavolať na číslo $safeNumber? Povedz áno alebo nie."
    }
}
