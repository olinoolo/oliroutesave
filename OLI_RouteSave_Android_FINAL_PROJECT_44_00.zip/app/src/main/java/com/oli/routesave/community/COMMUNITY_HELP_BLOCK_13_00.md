# OLI RouteSave 13.0 — Community help foundation

## Included
- Community help request models for drivers, cyclists, pedestrians and other users.
- Categories for vehicle breakdown, flat tire, out of fuel, medical assistance, safety concern, directions and other.
- Radius and coordinate validation.
- Preview wording for the selected help category, urgency, radius and whether exact location will be attached.
- Consent flow requiring a clear spoken/textual yes or no before a request changes to `PUBLISHED`.
- Publisher boundary that refuses draft, pending, expired or invalid requests.
- Unit-test source.

## Not yet connected
- No backend/server, user accounts, nearby-user discovery or push notifications are configured.
- This block does not acquire GPS coordinates or publish anything to a network.
- UI, map view, reporting/moderation, blocking, abuse controls and server-side access policies remain to be integrated.
- Emergency/medical help must not replace local emergency services. The app should clearly direct users to emergency services for immediate danger.

## Privacy and safety
- Location is optional in the request model; exact coordinates are not added automatically by this component.
- Show a preview of location sharing before asking for confirmation.
- Never publish a request merely because location permission was granted.
- Requests should expire and be cancellable, and the production server must verify consent state and user identity.
- Source-only; not compiled or device-tested.
