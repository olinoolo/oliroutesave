package com.oli.routesave.android.ui

import com.oli.routesave.presentation.MainUiModel

interface RouteSaveUiHost {
    fun render(model: MainUiModel)
    fun navigate(screen: String)
    fun showMessage(message: String)
}
