package com.oli.routesave.core

import com.oli.routesave.android.runtime.*
import com.oli.routesave.data.persistence.SettingsRepository
import com.oli.routesave.data.persistence.VehicleRepository
import com.oli.routesave.runtime.DriveSessionOrchestrator
import com.oli.routesave.ui.*

class RouteSaveRuntime(
    private val settingsRepository: SettingsRepository,
    private val vehicleRepository: VehicleRepository,
    private val permissions: PermissionController,
    private val readiness: DriveReadinessChecker,
    private val navigator: AppNavigator,
    private val drive: DriveSessionOrchestrator,
    private val driveUi: DriveUiController
) {
    private var state = RouteSaveApplicationState()

    fun initialize(): RouteSaveApplicationState {
        val assistant = settingsRepository.loadAssistantSettings()
        val vehicle = vehicleRepository.defaultVehicle()

        if (assistant != null) {
            driveUi.setAssistant(
                assistant.invocationName,
                assistant.personalAddress
            )
        }
        if (vehicle != null) {
            driveUi.setVehicle(vehicle.name)
        }

        state = state.copy(
            screen = navigator.current(),
            drive = driveUi.state(),
            readyForDrive = readiness.check().ready
        )
        return state
    }

    fun open(screen: AppScreen): RouteSaveApplicationState {
        navigator.navigate(screen)
        state = state.copy(
            screen = navigator.current(),
            drive = driveUi.state()
        )
        return state
    }

    fun startDrive(): RouteSaveApplicationState {
        val check = readiness.check()
        if (!check.ready) {
            state = state.copy(
                readyForDrive = false,
                lastError = check.reason ?: "Jazdu nie je možné spustiť."
            )
            return state
        }

        drive.start()
        state = state.copy(
            drive = driveUi.state(),
            readyForDrive = true,
            lastError = null
        )
        return state
    }

    fun stopDrive(): RouteSaveApplicationState {
        drive.stop()
        state = state.copy(
            drive = driveUi.state()
        )
        return state
    }

    fun pauseDrive(): RouteSaveApplicationState {
        drive.pause()
        state = state.copy(drive = driveUi.state())
        return state
    }

    fun resumeDrive(): RouteSaveApplicationState {
        drive.resume()
        state = state.copy(drive = driveUi.state())
        return state
    }

    fun currentState(): RouteSaveApplicationState = state
}
