package com.oli.routesave.communication

/**
 * Parses a voice-transcribed phone number without guessing a country code.
 * Full international validation should be provided by a region-aware library.
 */
sealed interface PhoneNumberEntryResult {
    data class AcceptedForReview(val dialableNumber: String) : PhoneNumberEntryResult
    data class NeedsClarification(val prompt: String) : PhoneNumberEntryResult
    data class Rejected(val reason: String) : PhoneNumberEntryResult
}

class PhoneNumberEntryParser {
    fun parse(transcribedText: String): PhoneNumberEntryResult {
        val number = PhoneNumberSanitizer.keepDialableCharacters(transcribedText)
        if (number.isBlank()) {
            return PhoneNumberEntryResult.NeedsClarification("Nerozpoznal som číslo. Povedz ho, prosím, ešte raz.")
        }
        if (!PhoneNumberSanitizer.looksPlausible(number)) {
            return PhoneNumberEntryResult.Rejected("Číslo vyzerá neúplné. Skontroluj ho alebo ho nadiktuj znova.")
        }
        return PhoneNumberEntryResult.AcceptedForReview(number)
    }
}
