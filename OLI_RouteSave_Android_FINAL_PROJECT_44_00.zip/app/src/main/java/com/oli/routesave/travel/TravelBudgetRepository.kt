package com.oli.routesave.travel

interface TravelBudgetRepository {
    fun get(): TravelBudget?
    fun save(budget: TravelBudget)
    fun clear()
}

class InMemoryTravelBudgetRepository : TravelBudgetRepository {
    private var value: TravelBudget? = null
    override fun get(): TravelBudget? = value
    override fun save(budget: TravelBudget) {
        val errors = budget.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        value = budget
    }
    override fun clear() { value = null }
}
