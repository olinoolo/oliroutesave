package com.oli.routesave.ui
import com.oli.routesave.data.model.VehicleProfile
import com.oli.routesave.data.persistence.VehicleRepository
class VehicleProfileController(private val repo:VehicleRepository){
    fun save(id:String,name:String,brand:String,model:String,fuelType:String,
             consumptionL100Km:Double,fuelPricePerLiter:Double,isDefault:Boolean):VehicleProfile{
        require(name.isNotBlank()); require(consumptionL100Km>=0); require(fuelPricePerLiter>=0)
        return VehicleProfile(id,name.trim(),brand.trim(),model.trim(),fuelType,
            consumptionL100Km,fuelPricePerLiter,isDefault).also{repo.save(it)}
    }
}
