package com.oli.routesave.voice.assistant

/**
 * Canonical list of built-in assistants. Names and invocation words are kept
 * separate so the app can display a full name while listening for a short name.
 */
object AssistantProfileCatalog {
    val all: List<AssistantProfile> = listOf(
        AssistantProfile(
            id = "marek",
            officialName = "Marek",
            invocationName = "Marek",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "branislav",
            officialName = "Branislav",
            invocationName = "Brandži",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "nikolas",
            officialName = "Nikolas",
            invocationName = "Niko",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "tanya",
            officialName = "Tanya",
            invocationName = "Tanya",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "vanesa",
            officialName = "Vanesa",
            invocationName = "Vany",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "natalia",
            officialName = "Natália",
            invocationName = "Naty",
            languageTag = "sk-SK"
        ),
        AssistantProfile(
            id = "katerina",
            officialName = "Kateřina",
            invocationName = "Kateřina",
            languageTag = "cs-CZ"
        )
    )

    fun byId(id: String): AssistantProfile? =
        all.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }

    fun byInvocation(invocation: String): AssistantProfile? {
        val normalized = normalize(invocation)
        return all.firstOrNull { normalize(it.invocationName) == normalized }
    }

    private fun normalize(value: String): String =
        java.text.Normalizer.normalize(value.trim().lowercase(), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("\\s+".toRegex(), " ")
}
