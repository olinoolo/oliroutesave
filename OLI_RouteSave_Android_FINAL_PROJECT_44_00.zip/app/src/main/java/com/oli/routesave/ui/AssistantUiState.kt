package com.oli.routesave.ui

data class AssistantUiState(
    val officialName: String = "",
    val invocationName: String = "",
    val personalAddress: String = "",
    val conciseResponses: Boolean = true,
    val proactiveSuggestions: Boolean = true,
    val romanceEnabled: Boolean = false,
    val romanceIntensity: String = "OFF"
)
