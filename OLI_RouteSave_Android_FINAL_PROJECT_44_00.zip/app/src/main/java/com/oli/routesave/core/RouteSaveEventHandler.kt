package com.oli.routesave.core

import com.oli.routesave.ui.AppScreen

class RouteSaveEventHandler(
    private val runtime: RouteSaveRuntime
) {
    fun handle(event: RouteSaveEvent): RouteSaveApplicationState {
        return when (event) {
            RouteSaveEvent.AppStarted -> runtime.initialize()
            RouteSaveEvent.StartDrive -> runtime.startDrive()
            RouteSaveEvent.StopDrive -> runtime.stopDrive()
            RouteSaveEvent.PauseDrive -> runtime.pauseDrive()
            RouteSaveEvent.ResumeDrive -> runtime.resumeDrive()
            is RouteSaveEvent.OpenScreen ->
                runtime.open(
                    runCatching { AppScreen.valueOf(event.screenName) }
                        .getOrDefault(AppScreen.HOME)
                )
            RouteSaveEvent.Emergency -> runtime.stopDrive()
        }
    }
}
