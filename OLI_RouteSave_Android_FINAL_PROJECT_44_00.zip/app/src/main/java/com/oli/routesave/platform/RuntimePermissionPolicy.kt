package com.oli.routesave.platform

/**
 * Central policy for deciding when to ask for Android permissions.
 *
 * This is a pure policy model; Activity Result API launchers must be wired
 * by the Android UI layer. Permission grant never implies consent to perform
 * an external action such as calling, sending an SMS, or sharing location.
 */
enum class RouteSavePermission {
    LOCATION_COARSE,
    LOCATION_FINE,
    MICROPHONE,
    NOTIFICATIONS,
    CONTACTS,
    PHONE_CALL,
    SMS,
    BACKGROUND_LOCATION
}

enum class PermissionUseCase {
    VIEW_ROUTE,
    START_NAVIGATION,
    ACTIVATE_VOICE,
    ENABLE_DRIVE_NOTIFICATION,
    CALL_CONTACT,
    SEND_MESSAGE,
    SHARE_LOCATION,
    COMMUNITY_HELP_REQUEST,
    BACKGROUND_NAVIGATION
}

data class PermissionRequestDecision(
    val permissions: Set<RouteSavePermission>,
    val explanation: String,
    val shouldAskNow: Boolean
)

object RuntimePermissionPolicy {
    fun decisionFor(useCase: PermissionUseCase): PermissionRequestDecision =
        when (useCase) {
            PermissionUseCase.VIEW_ROUTE -> PermissionRequestDecision(
                setOf(RouteSavePermission.LOCATION_COARSE, RouteSavePermission.LOCATION_FINE),
                "Poloha pomáha určiť tvoju aktuálnu polohu a naplánovať trasu.",
                true
            )
            PermissionUseCase.START_NAVIGATION -> PermissionRequestDecision(
                setOf(RouteSavePermission.LOCATION_COARSE, RouteSavePermission.LOCATION_FINE),
                "Navigácia potrebuje polohu, aby mohla sledovať trasu a poskytovať pokyny.",
                true
            )
            PermissionUseCase.ACTIVATE_VOICE -> PermissionRequestDecision(
                setOf(RouteSavePermission.MICROPHONE),
                "Mikrofón je potrebný, aby asistent počul tvoje hlasové príkazy.",
                true
            )
            PermissionUseCase.ENABLE_DRIVE_NOTIFICATION -> PermissionRequestDecision(
                setOf(RouteSavePermission.NOTIFICATIONS),
                "Oznámenie pomáha udržať aktívnu jazdu viditeľnú počas navigácie.",
                true
            )
            PermissionUseCase.CALL_CONTACT -> PermissionRequestDecision(
                setOf(RouteSavePermission.CONTACTS, RouteSavePermission.PHONE_CALL),
                "Kontakty pomôžu nájsť osobu a povolenie telefónu umožní uskutočniť hovor. Asistent si pred volaním vyžiada potvrdenie.",
                true
            )
            PermissionUseCase.SEND_MESSAGE -> PermissionRequestDecision(
                setOf(RouteSavePermission.CONTACTS, RouteSavePermission.SMS),
                "Tieto oprávnenia sa použijú iba pri nastavovaní posielania správ. Pred odoslaním si asistent vyžiada potvrdenie.",
                true
            )
            PermissionUseCase.SHARE_LOCATION,
            PermissionUseCase.COMMUNITY_HELP_REQUEST -> PermissionRequestDecision(
                setOf(RouteSavePermission.LOCATION_COARSE, RouteSavePermission.LOCATION_FINE),
                "Poloha môže pomôcť ľuďom v okolí nájsť miesto, kde potrebuješ pomoc. Zdieľanie sa nespustí bez tvojho jasného potvrdenia.",
                true
            )
            PermissionUseCase.BACKGROUND_NAVIGATION -> PermissionRequestDecision(
                setOf(RouteSavePermission.BACKGROUND_LOCATION),
                "Poloha na pozadí môže byť potrebná iba vtedy, keď chceš pokračovať v navigácii pri minimalizovanej aplikácii.",
                true
            )
        }

    fun mayPerformExternalAction(
        permissionGranted: Boolean,
        userConfirmedThisAction: Boolean
    ): Boolean = permissionGranted && userConfirmedThisAction
}
