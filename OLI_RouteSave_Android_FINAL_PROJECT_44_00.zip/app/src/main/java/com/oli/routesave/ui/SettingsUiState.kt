package com.oli.routesave.ui

data class SettingsUiState(
    val languageTag: String = "sk-SK",
    val metricUnits: Boolean = true,
    val truckMode: Boolean = false,
    val communityEnabled: Boolean = true,
    val voiceEnabled: Boolean = true
)
