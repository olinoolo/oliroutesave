package com.oli.routesave.data.model

data class VehicleProfile(
    val id: String,
    val name: String,
    val brand: String = "",
    val model: String = "",
    val fuelType: String = "PETROL",
    val averageConsumptionL100Km: Double = 0.0,
    val fuelPricePerLiter: Double = 0.0,
    val isDefault: Boolean = false
)
