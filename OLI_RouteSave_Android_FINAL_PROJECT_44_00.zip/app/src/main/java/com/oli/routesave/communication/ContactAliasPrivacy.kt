package com.oli.routesave.communication

object ContactAliasPrivacy {
    const val SETTINGS_SUMMARY =
        "Vlastné pomenovania kontaktov slúžia na hlasové vyhľadávanie. " +
        "Neukladajú telefónne čísla. Môžeš ich kedykoľvek upraviť alebo odstrániť."
}
