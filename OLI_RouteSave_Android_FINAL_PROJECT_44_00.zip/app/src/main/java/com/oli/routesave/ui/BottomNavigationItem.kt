package com.oli.routesave.ui

data class BottomNavigationItem(
    val screen: AppScreen,
    val label: String,
    val iconKey: String
)

object BottomNavigationDefaults {
    val items = listOf(
        BottomNavigationItem(AppScreen.HOME, "Domov", "home"),
        BottomNavigationItem(AppScreen.ROUTE, "Trasa", "route"),
        BottomNavigationItem(AppScreen.COMMUNITY, "Komunita", "people"),
        BottomNavigationItem(AppScreen.SETTINGS, "Nastavenia", "settings")
    )
}
