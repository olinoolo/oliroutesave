package com.oli.routesave.android.ui

data class DriveOverlaySpec(
    val assistantName: String,
    val destination: String,
    val eta: String,
    val remainingDistance: String,
    val driving: Boolean
)
