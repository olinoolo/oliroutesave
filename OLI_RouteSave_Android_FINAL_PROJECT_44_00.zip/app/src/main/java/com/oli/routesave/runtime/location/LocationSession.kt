package com.oli.routesave.runtime.location

class LocationSession(private val provider: LocationProvider) {
    private var last: LocationPoint? = null

    fun start(onUpdate: (LocationPoint) -> Unit) {
        provider.start {
            last = it
            onUpdate(it)
        }
    }

    fun stop() {
        provider.stop()
    }

    fun lastLocation(): LocationPoint? = last
}
