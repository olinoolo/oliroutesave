package com.oli.routesave.runtime.location

interface LocationProvider {
    fun start(onLocation: (LocationPoint) -> Unit)
    fun stop()
    fun isActive(): Boolean
}
