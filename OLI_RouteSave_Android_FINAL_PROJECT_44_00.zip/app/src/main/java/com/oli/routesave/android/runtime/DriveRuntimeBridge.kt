package com.oli.routesave.android.runtime

import com.oli.routesave.voice.runtime.UnifiedVoiceRuntime

/**
 * Application-level bridge: Android lifecycle -> unified voice runtime.
 * Concrete speech/TTS/wake-word providers are intentionally injected.
 */
class DriveRuntimeBridge(
    private val voiceRuntime: UnifiedVoiceRuntime,
    private val coordinator: DriveRuntimeCoordinator
) {
    fun startDrive(): DriveRuntimeSnapshot {
        return coordinator.handle(DriveRuntimeEvent.Start)
    }

    fun stopDrive(): DriveRuntimeSnapshot {
        voiceRuntime.reset()
        return coordinator.handle(DriveRuntimeEvent.Stop)
    }

    fun pauseDrive(): DriveRuntimeSnapshot =
        coordinator.handle(DriveRuntimeEvent.Pause)

    fun resumeDrive(): DriveRuntimeSnapshot =
        coordinator.handle(DriveRuntimeEvent.Resume)
}
