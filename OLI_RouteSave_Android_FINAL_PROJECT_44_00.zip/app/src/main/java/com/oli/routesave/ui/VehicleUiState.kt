package com.oli.routesave.ui

import com.oli.routesave.data.model.VehicleProfile

data class VehicleUiState(
    val vehicles: List<VehicleProfile> = emptyList(),
    val selectedVehicleId: String? = null
)
