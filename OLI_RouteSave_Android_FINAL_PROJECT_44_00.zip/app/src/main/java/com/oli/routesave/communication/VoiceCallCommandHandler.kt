package com.oli.routesave.communication

/**
 * Connects parsed voice commands to contact lookup / phone-number handling.
 *
 * This is an orchestration layer. The app's SpeechRecognizer/UI should pass
 * the recognized phrase and call options here. It deliberately stops before
 * starting a call; a user-facing confirmation step must happen first.
 */
sealed interface VoiceCallCommandOutcome {
    data class AskUser(val spokenPrompt: String) : VoiceCallCommandOutcome
    data class ContactSearchRequested(val spokenNameOrAlias: String, val channel: CallChannel, val mode: CallMode) : VoiceCallCommandOutcome
    data class NumberNeedsReview(val dialableNumber: String, val channel: CallChannel, val mode: CallMode) : VoiceCallCommandOutcome
    data class UnsupportedOrInvalid(val reason: String) : VoiceCallCommandOutcome
}

class VoiceCallCommandHandler(
    private val parser: CallVoiceCommandParser = CallVoiceCommandParser(),
    private val numberParser: PhoneNumberEntryParser = PhoneNumberEntryParser()
) {
    fun handle(recognizedPhrase: String): VoiceCallCommandOutcome {
        val parsed = parser.parse(recognizedPhrase)
            ?: return VoiceCallCommandOutcome.AskUser("Nerozumel som, komu chceš zavolať. Povedz meno kontaktu alebo telefónne číslo.")

        val numberResult = numberParser.parse(parsed.destinationText)
        return when (numberResult) {
            is PhoneNumberEntryResult.AcceptedForReview -> VoiceCallCommandOutcome.NumberNeedsReview(
                dialableNumber = numberResult.dialableNumber,
                channel = parsed.channel,
                mode = parsed.mode
            )
            is PhoneNumberEntryResult.NeedsClarification -> {
                val destination = parsed.destinationText.trim()
                if (destination.isBlank()) {
                    VoiceCallCommandOutcome.AskUser("Komu mám zavolať?")
                } else {
                    VoiceCallCommandOutcome.ContactSearchRequested(destination, parsed.channel, parsed.mode)
                }
            }
            is PhoneNumberEntryResult.Rejected -> {
                // Text may be a contact name rather than a number. Do not treat it as a number.
                val destination = parsed.destinationText.trim()
                if (destination.any(Char::isLetter)) {
                    VoiceCallCommandOutcome.ContactSearchRequested(destination, parsed.channel, parsed.mode)
                } else {
                    VoiceCallCommandOutcome.UnsupportedOrInvalid(numberResult.reason)
                }
            }
        }
    }
}
