package com.oli.routesave.runtime.navigation

import com.oli.routesave.ui.NavigationProvider
import com.oli.routesave.ui.NavigationRoute

class NavigationSession(private val provider: NavigationProvider) {
    private var state = NavigationSessionState.IDLE
    private var route: NavigationRoute? = null

    suspend fun calculate(origin: String, destination: String): Result<NavigationRoute> {
        state = NavigationSessionState.CALCULATING
        val result = provider.calculateRoute(origin, destination)
        state = if (result.isSuccess) {
            route = result.getOrNull()
            NavigationSessionState.READY
        } else {
            NavigationSessionState.ERROR
        }
        return result
    }

    fun start() {
        if (route != null) state = NavigationSessionState.ACTIVE
    }

    fun pause() {
        if (state == NavigationSessionState.ACTIVE) state = NavigationSessionState.PAUSED
    }

    fun resume() {
        if (state == NavigationSessionState.PAUSED) state = NavigationSessionState.ACTIVE
    }

    fun arrive() {
        state = NavigationSessionState.ARRIVED
    }

    fun stop() {
        state = NavigationSessionState.IDLE
        route = null
    }

    fun state(): NavigationSessionState = state
    fun route(): NavigationRoute? = route
}
