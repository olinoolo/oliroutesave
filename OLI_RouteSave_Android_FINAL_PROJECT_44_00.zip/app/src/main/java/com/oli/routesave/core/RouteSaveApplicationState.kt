package com.oli.routesave.core

import com.oli.routesave.ui.AppScreen
import com.oli.routesave.ui.DriveUiState

data class RouteSaveApplicationState(
    val screen: AppScreen = AppScreen.HOME,
    val drive: DriveUiState = DriveUiState(),
    val readyForDrive: Boolean = false,
    val lastError: String? = null
)
