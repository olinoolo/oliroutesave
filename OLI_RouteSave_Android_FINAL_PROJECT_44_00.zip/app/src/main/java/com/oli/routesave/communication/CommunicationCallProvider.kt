package com.oli.routesave.communication

/**
 * Provider adapter boundary. Concrete Android/WhatsApp/Messenger integrations
 * must verify supported intents/APIs at runtime and must never claim a call
 * started merely because an intent was constructed.
 */
interface CommunicationCallProvider {
    val channel: CallChannel

    suspend fun capability(mode: CallMode): CallCapability

    /** Prepare only. This must not place the call or start the video call. */
    suspend fun prepare(request: CallRequest): CallPreparationResult

    /** May be invoked only after the user clearly confirms the exact request. */
    suspend fun launchConfirmed(
        request: CallRequest,
        launchToken: String
    ): CallLaunchResult
}
