package com.oli.routesave.presentation

data class MainUiModel(
    val title: String = "OLI RouteSave",
    val slogan: String = "Save money. Travel smarter.",
    val assistantInvocation: String = "Niko",
    val vehicleName: String = "Moje vozidlo",
    val destination: String = "",
    val eta: String = "",
    val remainingKm: String = "",
    val driving: Boolean = false,
    val listening: Boolean = false
)
