package com.oli.routesave.voice.assistant

/**
 * Pure Kotlin settings model. Persistence and UI are injected by the host app.
 */
data class VoiceAssistantSettings(
    val selectedAssistantId: String = "nikolas",
    val languageTag: String = "sk-SK",
    val handsFreeEnabled: Boolean = false,
    val allowOptionalWakeWord: Boolean = true,
    val conciseResponses: Boolean = true,
    val romanticModeEnabled: Boolean = false
)

interface VoiceAssistantSettingsStore {
    fun load(): VoiceAssistantSettings
    fun save(settings: VoiceAssistantSettings)
}

class InMemoryVoiceAssistantSettingsStore(
    initial: VoiceAssistantSettings = VoiceAssistantSettings()
) : VoiceAssistantSettingsStore {
    private var settings: VoiceAssistantSettings = initial
    override fun load(): VoiceAssistantSettings = settings
    override fun save(settings: VoiceAssistantSettings) {
        this.settings = settings
    }
}

sealed interface AssistantSettingsResult {
    data class Saved(val settings: VoiceAssistantSettings) : AssistantSettingsResult
    data class Rejected(val reason: String) : AssistantSettingsResult
}

/**
 * Validates assistant selection and preferences before saving them.
 * Romantic mode is only a preference flag; it does not enable unsolicited
 * flirtation or bypass any safety/confirmation rules.
 */
class VoiceAssistantSettingsManager(
    private val store: VoiceAssistantSettingsStore
) {
    fun current(): VoiceAssistantSettings = store.load()

    fun selectAssistant(id: String): AssistantSettingsResult {
        val profile = AssistantProfileCatalog.byId(id)
            ?: return AssistantSettingsResult.Rejected("Neznámy hlasový asistent.")
        val updated = store.load().copy(
            selectedAssistantId = profile.id,
            languageTag = profile.languageTag
        )
        store.save(updated)
        return AssistantSettingsResult.Saved(updated)
    }

    fun update(
        handsFreeEnabled: Boolean? = null,
        allowOptionalWakeWord: Boolean? = null,
        conciseResponses: Boolean? = null,
        romanticModeEnabled: Boolean? = null,
        languageTag: String? = null
    ): AssistantSettingsResult {
        val old = store.load()
        val selected = AssistantProfileCatalog.byId(old.selectedAssistantId)
            ?: return AssistantSettingsResult.Rejected("Najprv vyber platného asistenta.")

        val requestedLanguage = languageTag?.trim()?.takeIf { it.isNotEmpty() } ?: old.languageTag
        if (requestedLanguage !in SUPPORTED_LANGUAGE_TAGS) {
            return AssistantSettingsResult.Rejected("Tento jazyk zatiaľ nie je v zozname podporovaných jazykov.")
        }

        val updated = old.copy(
            languageTag = requestedLanguage,
            handsFreeEnabled = handsFreeEnabled ?: old.handsFreeEnabled,
            allowOptionalWakeWord = allowOptionalWakeWord ?: old.allowOptionalWakeWord,
            conciseResponses = conciseResponses ?: old.conciseResponses,
            romanticModeEnabled = romanticModeEnabled ?: old.romanticModeEnabled
        )
        // Selecting an assistant and changing a language are independent settings.
        // The selected profile's default language is used only during selection.
        if (selected.id.isBlank()) return AssistantSettingsResult.Rejected("Neplatný profil asistenta.")
        store.save(updated)
        return AssistantSettingsResult.Saved(updated)
    }

    fun selectedAssistant(): AssistantProfile =
        AssistantProfileCatalog.byId(store.load().selectedAssistantId)
            ?: AssistantProfileCatalog.byId("nikolas")!!

    companion object {
        val SUPPORTED_LANGUAGE_TAGS = setOf(
            "sk-SK", "cs-CZ", "en-US", "de-DE", "pl-PL", "hu-HU", "ro-RO"
        )
    }
}
