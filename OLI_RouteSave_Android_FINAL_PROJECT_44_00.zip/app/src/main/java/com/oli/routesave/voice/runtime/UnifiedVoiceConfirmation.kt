package com.oli.routesave.voice.runtime

enum class UnifiedVoiceConfirmation {
    NONE,
    REQUIRED,
    CONFIRMED,
    DECLINED
}
