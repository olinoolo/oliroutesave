package com.oli.routesave.communication

/**
 * Resolves user-defined aliases first, then asks the Android contact gateway
 * to search by name. It never guesses a relationship such as "wife" or "brother".
 */
class VoiceCallResolutionService(
    private val aliasStore: ContactAliasStore,
    private val contactsGateway: AndroidContactsGateway
) {
    sealed interface Result {
        data class AliasResolved(val alias: ContactAlias) : Result
        data class ContactCandidates(val outcome: ContactLookupOutcome) : Result
        data class NeedsPermission(val prompt: String) : Result
    }

    suspend fun resolve(spokenReference: String): Result {
        val reference = spokenReference.trim()
        if (reference.isBlank()) {
            return Result.ContactCandidates(ContactLookupOutcome.NoMatch)
        }
        if (contactsGateway.permissionState() != ContactPermissionState.GRANTED) {
            return Result.NeedsPermission("Povoľ prístup ku kontaktom, aby som mohol vyhľadať osobu.")
        }
        val alias = aliasStore.find(reference)
        if (alias != null) return Result.AliasResolved(alias)
        return Result.ContactCandidates(contactsGateway.searchByNameOrNickname(reference))
    }
}
