package com.oli.routesave.travel

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class SharedPreferencesTravelBudgetRepository(
    context: Context,
    preferencesName: String = DEFAULT_PREFERENCES_NAME
) : TravelBudgetRepository {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)

    override fun get(): TravelBudget? {
        val raw = prefs.getString(KEY_BUDGET, null) ?: return null
        return try {
            val j = JSONObject(raw)
            val budget = TravelBudget(
                monthlyLimit = j.optDouble("monthlyLimit", Double.NaN),
                currencyCode = j.optString("currencyCode", "EUR"),
                updatedAtEpochMs = j.optLong("updatedAtEpochMs", -1L)
            )
            if (budget.validate().isEmpty()) budget else null
        } catch (_: Exception) {
            null
        }
    }

    override fun save(budget: TravelBudget) {
        val errors = budget.validate()
        require(errors.isEmpty()) { errors.joinToString(" ") }
        val json = JSONObject()
            .put("monthlyLimit", budget.monthlyLimit)
            .put("currencyCode", budget.currencyCode)
            .put("updatedAtEpochMs", budget.updatedAtEpochMs)
            .toString()
        prefs.edit().putString(KEY_BUDGET, json).apply()
    }

    override fun clear() {
        prefs.edit().remove(KEY_BUDGET).apply()
    }

    companion object {
        const val DEFAULT_PREFERENCES_NAME = "oli_routesave_travel_budget"
        private const val KEY_BUDGET = "monthly_budget"
    }
}
