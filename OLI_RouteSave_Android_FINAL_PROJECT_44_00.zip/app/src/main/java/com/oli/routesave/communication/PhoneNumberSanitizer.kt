package com.oli.routesave.communication

/**
 * Conservative cleanup before passing a dictated number to a real
 * region-aware phone-number library/provider. This is not full validation and
 * does not guess a country code.
 */
object PhoneNumberSanitizer {
    fun keepDialableCharacters(input: String): String {
        val trimmed = input.trim()
        val result = StringBuilder()
        trimmed.forEachIndexed { index, c ->
            when {
                c.isDigit() -> result.append(c)
                c == '+' && result.isEmpty() -> result.append(c)
                c == '*' || c == '#' -> result.append(c)
                c.isWhitespace() || c == '-' || c == '(' || c == ')' || c == '.' -> Unit
            }
        }
        return result.toString()
    }

    fun looksPlausible(number: String): Boolean {
        val clean = keepDialableCharacters(number)
        val digits = clean.count(Char::isDigit)
        return digits in 3..15 && clean.firstOrNull() != null
    }
}
