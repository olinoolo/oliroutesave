package com.oli.routesave.communication

/**
 * Produces a read-back summary for the selected recipient, channel and call
 * mode. This summary is spoken before confirmation; it does not launch a call.
 */
object CallReadbackFormatter {
    fun format(request: CallRequest): String {
        val target = when (val destination = request.destination) {
            is CallDestination.Contact -> destination.displayName
            is CallDestination.PhoneNumber -> destination.normalizedNumber
        }
        val modeText = if (request.mode == CallMode.VIDEO) "videohovor" else "hlasový hovor"
        val channelText = when (request.channel) {
            CallChannel.PHONE -> "bežným telefonátom"
            CallChannel.WHATSAPP -> "cez WhatsApp"
            CallChannel.MESSENGER -> "cez Messenger"
        }
        return "Rozumiem. Chceš spustiť $modeText s $target $channelText. Mám pokračovať?"
    }
}
