package com.oli.routesave.voice.runtime

class UnifiedVoiceStateMachine {

    private var state = UnifiedVoiceState.IDLE

    fun current(): UnifiedVoiceState = state

    fun apply(event: UnifiedVoiceEvent): UnifiedVoiceTransition {
        state = when (event.type) {
            UnifiedVoiceEventType.ASSISTANT_INVOCATION ->
                UnifiedVoiceState.LISTENING

            UnifiedVoiceEventType.USER_SPEECH ->
                UnifiedVoiceState.PROCESSING

            UnifiedVoiceEventType.TTS_STARTED ->
                UnifiedVoiceState.SPEAKING

            UnifiedVoiceEventType.TTS_FINISHED ->
                UnifiedVoiceState.LISTENING

            UnifiedVoiceEventType.BARGE_IN ->
                UnifiedVoiceState.LISTENING

            UnifiedVoiceEventType.CONFIRMATION_REQUIRED ->
                UnifiedVoiceState.WAITING_CONFIRMATION

            UnifiedVoiceEventType.CONFIRMATION_RECEIVED ->
                UnifiedVoiceState.PROCESSING

            UnifiedVoiceEventType.EMERGENCY,
            UnifiedVoiceEventType.ACTIVE_CALL,
            UnifiedVoiceEventType.NAVIGATION_CRITICAL ->
                UnifiedVoiceState.INTERRUPTED

            UnifiedVoiceEventType.SESSION_TIMEOUT,
            UnifiedVoiceEventType.ERROR ->
                UnifiedVoiceState.ENDED
        }

        return UnifiedVoiceTransition(state, event.type.name)
    }

    fun reset() {
        state = UnifiedVoiceState.IDLE
    }
}
