package com.oli.routesave.community

/**
 * A request is not published until the requester explicitly confirms the
 * preview. This component only changes local workflow state; networking and
 * location acquisition are deliberately handled by separate adapters.
 */
class CommunityHelpConsentFlow(
    private val nowMillis: () -> Long = { System.currentTimeMillis() }
) {
    private var draft: CommunityHelpRequest? = null

    @Synchronized
    fun prepare(request: CommunityHelpRequest): CommunityHelpConsentResult {
        when (val validation = CommunityHelpRequestValidator.validate(request)) {
            is CommunityHelpValidation.Invalid ->
                return CommunityHelpConsentResult.Rejected(validation.reasons)
            CommunityHelpValidation.Valid -> Unit
        }
        if (request.expiresAtEpochMillis <= nowMillis()) {
            return CommunityHelpConsentResult.Rejected(listOf("Žiadosť už vypršala."))
        }
        val pending = request.copy(status = HelpRequestStatus.AWAITING_CONFIRMATION)
        draft = pending
        return CommunityHelpConsentResult.NeedsConfirmation(
            pending,
            CommunityHelpPreviewFormatter.format(pending)
        )
    }

    @Synchronized
    fun respond(requestId: String, answer: String): CommunityHelpConsentResult {
        val current = draft ?: return CommunityHelpConsentResult.Rejected(
            listOf("Nie je pripravená žiadna žiadosť o pomoc.")
        )
        if (current.requestId != requestId) {
            return CommunityHelpConsentResult.Rejected(listOf("Žiadosť sa už zmenila."))
        }
        if (current.expiresAtEpochMillis <= nowMillis()) {
            draft = null
            return CommunityHelpConsentResult.Rejected(listOf("Žiadosť o pomoc vypršala."))
        }
        return when (normalize(answer)) {
            "ano", "ano potvrdzujem", "potvrdzujem" -> {
                draft = null
                CommunityHelpConsentResult.Confirmed(current.copy(status = HelpRequestStatus.PUBLISHED))
            }
            "nie", "zrus", "zrus to", "nie dakujem" -> {
                draft = null
                CommunityHelpConsentResult.Cancelled
            }
            else -> CommunityHelpConsentResult.NeedsConfirmation(
                current,
                "Prosím, povedz jasne áno alebo nie. ${CommunityHelpPreviewFormatter.format(current)}"
            )
        }
    }

    @Synchronized
    fun cancel() {
        draft = null
    }

    private fun normalize(value: String): String =
        java.text.Normalizer.normalize(value.trim().lowercase(), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("[.!?,;:]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
}

sealed interface CommunityHelpConsentResult {
    data class NeedsConfirmation(
        val request: CommunityHelpRequest,
        val spokenPrompt: String
    ) : CommunityHelpConsentResult

    data class Confirmed(val request: CommunityHelpRequest) : CommunityHelpConsentResult
    data object Cancelled : CommunityHelpConsentResult
    data class Rejected(val reasons: List<String>) : CommunityHelpConsentResult
}

object CommunityHelpPreviewFormatter {
    fun format(request: CommunityHelpRequest): String {
        val category = when (request.category) {
            HelpCategory.VEHICLE_BREAKDOWN -> "porucha vozidla"
            HelpCategory.FLAT_TIRE -> "defekt"
            HelpCategory.OUT_OF_FUEL -> "nedostatok paliva"
            HelpCategory.MEDICAL_ASSISTANCE -> "zdravotná pomoc"
            HelpCategory.SAFETY_CONCERN -> "bezpečnostná pomoc"
            HelpCategory.DIRECTIONS -> "pomoc s orientáciou"
            HelpCategory.OTHER -> "iná pomoc"
        }
        val location = if (request.latitude != null && request.longitude != null) {
            "a pripojiť tvoju polohu"
        } else {
            "bez pripojenia presnej polohy"
        }
        val urgency = if (request.urgency == HelpUrgency.URGENT) " ako naliehavú" else ""
        return "Mám zverejniť žiadosť o pomoc: $category$urgency v okruhu ${request.radiusKm} km $location? Povedz áno alebo nie."
    }
}
