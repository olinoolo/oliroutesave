package com.oli.routesave.navigation
import com.oli.routesave.ui.*
class MapboxNavigationAdapter(private val engine:MapboxNavigationEngine):NavigationProvider{
 override suspend fun calculateRoute(origin:String,destination:String)=engine.calculate(origin,destination)
}
interface MapboxNavigationEngine{suspend fun calculate(origin:String,destination:String):Result<NavigationRoute>}
