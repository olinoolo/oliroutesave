package com.oli.routesave.runtime.navigation

enum class NavigationSessionState {
    IDLE,
    CALCULATING,
    READY,
    ACTIVE,
    PAUSED,
    ARRIVED,
    ERROR
}
