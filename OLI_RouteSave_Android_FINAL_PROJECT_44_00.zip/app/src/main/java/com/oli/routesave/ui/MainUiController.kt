package com.oli.routesave.ui

class MainUiController(
    private val navigator: AppNavigator = AppNavigator()
) {
    fun dispatch(action: UiAction): AppScreen {
        when (action) {
            is UiAction.OpenScreen -> navigator.navigate(action.screen)
            UiAction.Back -> navigator.back()
            UiAction.StartDrive,
            UiAction.StopDrive -> Unit
        }
        return navigator.current()
    }

    fun screen(): AppScreen = navigator.current()
}
