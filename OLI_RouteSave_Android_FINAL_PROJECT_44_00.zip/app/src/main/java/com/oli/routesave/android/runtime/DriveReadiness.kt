package com.oli.routesave.android.runtime
data class DriveReadiness(val ready:Boolean,val missing:List<AndroidPermission> = emptyList(),val reason:String?=null)
class DriveReadinessChecker(private val permissions:PermissionController){
 fun check():DriveReadiness{
  val s=permissions.state()
  val missing=if(!s.fineLocation&&!s.coarseLocation) listOf(AndroidPermission.LOCATION_FINE) else emptyList()
  return if(missing.isEmpty()) DriveReadiness(true) else DriveReadiness(false,missing,"Pre navigáciu je potrebné povolenie polohy.")
 }
}
