package com.oli.routesave.android.runtime
enum class AudioFocusMode{NONE,VOICE_ASSISTANT,NAVIGATION_GUIDANCE,EMERGENCY}
class AudioFocusPolicy{
 fun priority(mode:AudioFocusMode)=when(mode){AudioFocusMode.NONE->0;AudioFocusMode.VOICE_ASSISTANT->50;AudioFocusMode.NAVIGATION_GUIDANCE->70;AudioFocusMode.EMERGENCY->100}
 fun canInterrupt(current:AudioFocusMode,requested:AudioFocusMode)=priority(requested)>priority(current)
}
