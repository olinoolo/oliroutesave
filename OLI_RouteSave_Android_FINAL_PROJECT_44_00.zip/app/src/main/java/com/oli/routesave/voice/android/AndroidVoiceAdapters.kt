package com.oli.routesave.voice.android

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Android adapters for speech input/output and preparing a call intent.
 *
 * Caller is responsible for requesting runtime permissions from an Activity
 * and only invoking prepareCallIntent after the app's explicit confirmation
 * flow has completed. This class does not automatically start a call.
 */
class AndroidSpeechInput(
    private val context: Context,
    private val onPartialText: (String) -> Unit,
    private val onFinalText: (String) -> Unit,
    private val onErrorMessage: (String) -> Unit,
    private val onFinalConfidence: ((String, Float) -> Unit)? = null
) {
    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun hasMicrophonePermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun start(localeTag: String = "sk-SK") {
        if (!isAvailable()) {
            onErrorMessage("Rozpoznávanie reči nie je v tomto zariadení dostupné.")
            return
        }
        if (!hasMicrophonePermission()) {
            onErrorMessage("Na rozpoznávanie reči je potrebné povoliť mikrofón.")
            return
        }
        stop()
        val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = speechRecognizer
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                onErrorMessage(when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Problém s mikrofónom."
                    SpeechRecognizer.ERROR_CLIENT -> "Rozpoznávanie bolo prerušené."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Chýba povolenie na mikrofón."
                    SpeechRecognizer.ERROR_NETWORK -> "Sieťová chyba pri rozpoznávaní."
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Vypršal časový limit siete."
                    SpeechRecognizer.ERROR_NO_MATCH -> "Nerozumela som. Skús to znova."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Rozpoznávanie reči je už zaneprázdnené."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nepočula som žiadnu reč."
                    else -> "Rozpoznávanie reči zlyhalo (kód $error)."
                })
            }
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    val score = results
                        ?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                        ?.firstOrNull()
                    // Missing/negative confidence is deliberately treated as uncertain.
                    val confidence = if (score != null && score >= 0f) score else 0.75f
                    val confidenceCallback = onFinalConfidence
                    if (confidenceCallback != null) confidenceCallback(text, confidence)
                    else onFinalText(text)
                }
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onPartialText(text)
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag(localeTag))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer.startListening(intent)
    }

    fun stop() {
        recognizer?.let {
            try { it.stopListening() } catch (_: Exception) {}
            try { it.cancel() } catch (_: Exception) {}
            it.destroy()
        }
        recognizer = null
    }
}

/** Text-to-speech wrapper. Call shutdown() from the owning lifecycle's cleanup. */
class AndroidSpeechOutput(
    context: Context,
    private val onReady: (Boolean) -> Unit
) {
    private var engine: TextToSpeech? = null
    private var ready = false

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            onReady(ready)
        }
    }

    fun speak(text: String, localeTag: String = "sk-SK") {
        val tts = engine ?: return
        if (!ready || text.isBlank()) return
        val locale = Locale.forLanguageTag(localeTag)
        val languageStatus = tts.setLanguage(locale)
        if (languageStatus == TextToSpeech.LANG_MISSING_DATA ||
            languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "oli-route-save-tts")
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "oli-route-save-tts")
    }

    fun stop() {
        engine?.stop()
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        ready = false
    }
}

/**
 * Returns a dialer intent only. It deliberately uses ACTION_DIAL instead of
 * ACTION_CALL, so the user sees the number and must press the call button.
 */
object AndroidCallPreparation {
    fun prepareCallIntent(context: Context, phoneNumber: String): Intent? {
        val normalized = phoneNumber.trim()
        if (normalized.isBlank()) return null
        return Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(normalized)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }.takeIf { it.resolveActivity(context.packageManager) != null }
    }
}
