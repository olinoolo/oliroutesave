package com.oli.routesave.communication

/**
 * Small intent parser scaffold; production integration should use localized
 * intent/slot extraction rather than relying only on keyword matching.
 */
data class ParsedCallCommand(
    val destinationText: String,
    val channel: CallChannel,
    val mode: CallMode
)

class CallVoiceCommandParser {
    fun parse(text: String): ParsedCallCommand? {
        val normalized = text.lowercase().trim()
        val isVideo = listOf("videohovor", "video hovor", "video call").any(normalized::contains)
        val channel = when {
            "whatsapp" in normalized || "what's app" in normalized -> CallChannel.WHATSAPP
            "messenger" in normalized -> CallChannel.MESSENGER
            else -> CallChannel.PHONE
        }
        val actionPresent = listOf("zavolaj", "volaj", "spusti", "uskutočni", "call").any(normalized::contains)
        if (!actionPresent) return null

        val destination = normalized
            .replace("cez whatsapp", "")
            .replace("cez messenger", "")
            .replace("whatsapp", "")
            .replace("messenger", "")
            .replace("videohovor", "")
            .replace("video hovor", "")
            .replace("video call", "")
            .replace("zavolaj", "")
            .replace("volaj", "")
            .replace("spusti", "")
            .replace("uskutočni", "")
            .replace("call", "")
            .replace("mi", "")
            .replace("prosím", "")
            .trim()
            .trim(',', '.', '!', '?')

        if (destination.isBlank()) return null
        return ParsedCallCommand(
            destinationText = destination,
            channel = channel,
            mode = if (isVideo) CallMode.VIDEO else CallMode.AUDIO
        )
    }
}
