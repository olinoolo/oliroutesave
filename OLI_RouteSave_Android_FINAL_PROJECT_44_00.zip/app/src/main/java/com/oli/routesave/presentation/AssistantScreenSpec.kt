package com.oli.routesave.presentation

data class AssistantScreenSpec(
    val officialName: String = "",
    val invocationName: String = "",
    val personalAddress: String = "",
    val voiceLabel: String = "Hlas asistenta",
    val conciseResponses: Boolean = true,
    val proactiveSuggestions: Boolean = true,
    val romanceEnabled: Boolean = false
)
