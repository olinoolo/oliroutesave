package com.oli.routesave.data

object TripCostCalculator {
    fun fuelCost(
        distanceKm: Double,
        consumptionL100Km: Double,
        fuelPricePerLiter: Double
    ): Double {
        if (distanceKm < 0 || consumptionL100Km < 0 || fuelPricePerLiter < 0) return 0.0
        val liters = distanceKm * consumptionL100Km / 100.0
        return liters * fuelPricePerLiter
    }

    fun totalCost(
        distanceKm: Double,
        consumptionL100Km: Double,
        fuelPricePerLiter: Double,
        tollCost: Double = 0.0,
        parkingCost: Double = 0.0
    ): Double {
        return fuelCost(distanceKm, consumptionL100Km, fuelPricePerLiter) +
            tollCost.coerceAtLeast(0.0) +
            parkingCost.coerceAtLeast(0.0)
    }
}
