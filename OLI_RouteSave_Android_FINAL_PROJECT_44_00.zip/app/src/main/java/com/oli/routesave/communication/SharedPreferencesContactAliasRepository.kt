package com.oli.routesave.communication

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Android-backed durable storage for contact aliases.
 *
 * Stores only the alias, contact ID and display name. Phone numbers and other
 * contact fields are deliberately not copied into this preference store.
 */
class SharedPreferencesContactAliasRepository(
    context: Context,
    preferencesName: String = DEFAULT_PREFERENCES_NAME
) : ContactAliasRepository {

    private val preferences: SharedPreferences =
        context.applicationContext.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)

    private val lock = Any()

    override suspend fun saveAlias(alias: ContactAlias) {
        val normalized = alias.alias.trim().replace(WHITESPACE, " ")
        require(normalized.isNotEmpty()) { "Alias must not be empty." }
        require(normalized.length <= MAX_ALIAS_LENGTH) { "Alias is too long." }
        require(alias.contactId.isNotBlank()) { "Contact ID is required." }
        require(alias.displayName.isNotBlank()) { "Contact display name is required." }

        val stored = JSONObject()
            .put(JSON_ALIAS, normalized)
            .put(JSON_CONTACT_ID, alias.contactId)
            .put(JSON_DISPLAY_NAME, alias.displayName)

        synchronized(lock) {
            preferences.edit()
                .putString(storageKey(normalized), stored.toString())
                .apply()
        }
    }

    override suspend fun findByAlias(alias: String): ContactAlias? {
        val normalized = normalizeAlias(alias)
        if (normalized.isEmpty()) return null

        val raw = synchronized(lock) {
            preferences.getString(storageKey(normalized), null)
        } ?: return null

        return decodeOrNull(raw)
    }

    override suspend fun removeAlias(alias: String): Boolean {
        val normalized = normalizeAlias(alias)
        if (normalized.isEmpty()) return false

        synchronized(lock) {
            val key = storageKey(normalized)
            if (!preferences.contains(key)) return false
            preferences.edit().remove(key).apply()
            return true
        }
    }

    override suspend fun allAliases(): List<ContactAlias> {
        val snapshot = synchronized(lock) { preferences.all.toMap() }
        return snapshot.entries
            .asSequence()
            .filter { it.key.startsWith(KEY_PREFIX) }
            .mapNotNull { entry -> (entry.value as? String)?.let(::decodeOrNull) }
            .sortedBy { it.alias.lowercase() }
            .toList()
    }

    private fun decodeOrNull(raw: String): ContactAlias? = try {
        val json = JSONObject(raw)
        val alias = json.optString(JSON_ALIAS).trim()
        val contactId = json.optString(JSON_CONTACT_ID).trim()
        val displayName = json.optString(JSON_DISPLAY_NAME).trim()

        if (alias.isEmpty() || alias.length > MAX_ALIAS_LENGTH ||
            contactId.isEmpty() || displayName.isEmpty()
        ) {
            null
        } else {
            ContactAlias(
                alias = alias,
                contactId = contactId,
                displayName = displayName
            )
        }
    } catch (_: Exception) {
        // Ignore malformed entries so one damaged preference cannot break the list.
        null
    }

    private fun normalizeAlias(alias: String): String =
        alias.trim().replace(WHITESPACE, " ").lowercase()

    private fun storageKey(alias: String): String = KEY_PREFIX + normalizeAlias(alias)

    companion object {
        const val DEFAULT_PREFERENCES_NAME = "oli_routesave_contact_aliases"
        private const val KEY_PREFIX = "contact_alias:"
        private const val JSON_ALIAS = "alias"
        private const val JSON_CONTACT_ID = "contactId"
        private const val JSON_DISPLAY_NAME = "displayName"
        private const val MAX_ALIAS_LENGTH = 40
        private val WHITESPACE = Regex("\\s+")
    }
}
