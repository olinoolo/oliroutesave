package com.oli.routesave.voice.assistant

import android.content.Context
import android.content.SharedPreferences

/**
 * Durable Android settings store for the selected voice assistant and preferences.
 *
 * Uses app-private SharedPreferences. It stores preferences only, not audio,
 * transcripts, contact details, or authentication credentials.
 */
class SharedPreferencesVoiceAssistantSettingsStore(
    context: Context,
    preferencesName: String = DEFAULT_PREFERENCES_NAME
) : VoiceAssistantSettingsStore {

    private val preferences: SharedPreferences =
        context.applicationContext.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)

    override fun load(): VoiceAssistantSettings {
        val defaults = VoiceAssistantSettings()
        val selectedId = preferences.getString(KEY_SELECTED_ASSISTANT, defaults.selectedAssistantId)
            ?: defaults.selectedAssistantId
        val languageTag = preferences.getString(KEY_LANGUAGE_TAG, defaults.languageTag)
            ?: defaults.languageTag

        return VoiceAssistantSettings(
            selectedAssistantId = selectedId,
            languageTag = languageTag,
            handsFreeEnabled = preferences.getBoolean(KEY_HANDS_FREE, defaults.handsFreeEnabled),
            allowOptionalWakeWord = preferences.getBoolean(KEY_OPTIONAL_WAKE_WORD, defaults.allowOptionalWakeWord),
            conciseResponses = preferences.getBoolean(KEY_CONCISE_RESPONSES, defaults.conciseResponses),
            romanticModeEnabled = preferences.getBoolean(KEY_ROMANTIC_MODE, defaults.romanticModeEnabled)
        )
    }

    override fun save(settings: VoiceAssistantSettings) {
        require(AssistantProfileCatalog.byId(settings.selectedAssistantId) != null) {
            "Unknown voice assistant ID."
        }
        require(settings.languageTag in VoiceAssistantSettingsManager.SUPPORTED_LANGUAGE_TAGS) {
            "Unsupported language tag."
        }

        preferences.edit()
            .putString(KEY_SELECTED_ASSISTANT, settings.selectedAssistantId)
            .putString(KEY_LANGUAGE_TAG, settings.languageTag)
            .putBoolean(KEY_HANDS_FREE, settings.handsFreeEnabled)
            .putBoolean(KEY_OPTIONAL_WAKE_WORD, settings.allowOptionalWakeWord)
            .putBoolean(KEY_CONCISE_RESPONSES, settings.conciseResponses)
            .putBoolean(KEY_ROMANTIC_MODE, settings.romanticModeEnabled)
            .apply()
    }

    companion object {
        const val DEFAULT_PREFERENCES_NAME = "oli_routesave_voice_settings"
        private const val KEY_SELECTED_ASSISTANT = "selected_assistant_id"
        private const val KEY_LANGUAGE_TAG = "language_tag"
        private const val KEY_HANDS_FREE = "hands_free_enabled"
        private const val KEY_OPTIONAL_WAKE_WORD = "optional_wake_word"
        private const val KEY_CONCISE_RESPONSES = "concise_responses"
        private const val KEY_ROMANTIC_MODE = "romantic_mode_enabled"
    }
}
