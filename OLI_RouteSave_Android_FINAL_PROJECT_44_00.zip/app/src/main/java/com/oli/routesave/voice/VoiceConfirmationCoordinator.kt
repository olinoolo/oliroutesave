package com.oli.routesave.voice

/**
 * Safe confirmation workflow for pending external actions.
 * This state machine never performs the external action itself.
 */
enum class ConfirmationUiState {
    IDLE, ASKING, WAITING_FOR_ANSWER, CONFIRMED, REJECTED, NEEDS_CLARIFICATION
}

data class ConfirmationPromptState(
    val state: ConfirmationUiState = ConfirmationUiState.IDLE,
    val pendingAction: PendingVoiceAction? = null,
    val prompt: String = "",
    val message: String = ""
)

class VoiceConfirmationCoordinator {
    var current: ConfirmationPromptState = ConfirmationPromptState()
        private set

    fun requestConfirmation(action: PendingVoiceAction): ConfirmationPromptState {
        val safeAction = action.copy(isConfirmed = false)
        current = ConfirmationPromptState(
            state = ConfirmationUiState.ASKING,
            pendingAction = safeAction,
            prompt = safeAction.confirmationPrompt,
            message = "Čakám na jasné potvrdenie."
        )
        return current
    }

    fun markPromptSpoken(): ConfirmationPromptState {
        if (current.pendingAction == null) return current
        current = current.copy(
            state = ConfirmationUiState.WAITING_FOR_ANSWER,
            message = "Povedz jasne áno alebo nie."
        )
        return current
    }

    fun receiveAnswer(text: String, confidence: Float): ConfirmationPromptState {
        val action = current.pendingAction
            ?: return current.copy(
                state = ConfirmationUiState.IDLE,
                message = "Nie je žiadna čakajúca akcia."
            )
        if (current.state !in setOf(
                ConfirmationUiState.ASKING,
                ConfirmationUiState.WAITING_FOR_ANSWER,
                ConfirmationUiState.NEEDS_CLARIFICATION
            )) {
            return current
        }
        if (confidence < 0.85f) {
            current = current.copy(
                state = ConfirmationUiState.NEEDS_CLARIFICATION,
                prompt = "Nepočula som jasnú odpoveď. Chceš pokračovať? Povedz áno alebo nie.",
                message = "Nízka istota rozpoznania; akcia zostáva nevykonaná."
            )
            return current
        }
        return when (text.trim().lowercase()) {
            "áno", "ano", "potvrdzujem", "áno potvrď", "ano potvrd", "yes", "confirm", "ja" -> {
                current = current.copy(
                    state = ConfirmationUiState.CONFIRMED,
                    pendingAction = action.copy(isConfirmed = true),
                    message = "Potvrdenie prijaté. Akcia sa ešte nevykonala; musí ju bezpečne spracovať samostatná vrstva."
                )
                current
            }
            "nie", "ne", "zruš", "zrus", "nepotvrdzujem", "no", "nein" -> {
                current = ConfirmationPromptState(
                    state = ConfirmationUiState.REJECTED,
                    pendingAction = null,
                    prompt = "",
                    message = "Akcia bola zrušená."
                )
                current
            }
            else -> {
                current = current.copy(
                    state = ConfirmationUiState.NEEDS_CLARIFICATION,
                    prompt = "Prosím, povedz jasne áno alebo nie.",
                    message = "Odpoveď nie je jednoznačná; akcia zostáva nevykonaná."
                )
                current
            }
        }
    }

    fun clear(): ConfirmationPromptState {
        current = ConfirmationPromptState(
            state = ConfirmationUiState.IDLE,
            pendingAction = null,
            prompt = "",
            message = "Žiadna čakajúca akcia."
        )
        return current
    }
}
