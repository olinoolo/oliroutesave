package com.oli.routesave.voice.android

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Single-turn Android speech recognition adapter.
 *
 * Caller must request RECORD_AUDIO at the moment the user activates voice.
 * This adapter intentionally does not start automatically in the background.
 */
class AndroidSpeechRecognizerAdapter(
    context: Context,
    private val listener: VoiceInputOutputListener
) : VoiceInputProvider {

    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    private var activeLanguageTag: String = "sk-SK"

    override fun startListening(languageTag: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            listener.onInputStateChanged(VoiceInputState.ERROR)
            listener.onInputError("Na tomto zariadení nie je dostupné rozpoznávanie reči.")
            return
        }

        activeLanguageTag = languageTag
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(appContext).also {
                it.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        listener.onInputStateChanged(VoiceInputState.LISTENING)
                    }

                    override fun onBeginningOfSpeech() {
                        listener.onInputStateChanged(VoiceInputState.LISTENING)
                    }

                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit

                    override fun onEndOfSpeech() {
                        listener.onInputStateChanged(VoiceInputState.PROCESSING)
                    }

                    override fun onError(error: Int) {
                        listener.onInputStateChanged(VoiceInputState.ERROR)
                        listener.onInputError(errorMessage(error))
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotBlank()) {
                            listener.onRecognition(VoiceRecognitionResult(text, languageTag = activeLanguageTag))
                            listener.onInputStateChanged(VoiceInputState.IDLE)
                        } else {
                            listener.onInputStateChanged(VoiceInputState.ERROR)
                            listener.onInputError("Nerozumel som príkazu. Skús to, prosím, ešte raz.")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        listener.onInputStateChanged(VoiceInputState.PROCESSING)
        recognizer?.startListening(intent)
    }

    override fun stopListening() {
        recognizer?.stopListening()
        listener.onInputStateChanged(VoiceInputState.IDLE)
    }

    override fun release() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        listener.onInputStateChanged(VoiceInputState.IDLE)
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Problém so zvukom. Skontroluj mikrofón."
        SpeechRecognizer.ERROR_CLIENT -> "Rozpoznávanie reči bolo prerušené."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Na hlasové ovládanie je potrebné povolenie mikrofónu."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Rozpoznávanie reči nemá dostupné sieťové spojenie."
        SpeechRecognizer.ERROR_NO_MATCH -> "Nerozumel som. Skús príkaz zopakovať."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Hlasové ovládanie je už zaneprázdnené."
        SpeechRecognizer.ERROR_SERVER -> "Služba rozpoznávania reči momentálne neodpovedá."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nič som nezachytil. Skús to znova."
        else -> "Rozpoznávanie reči zlyhalo. Skús to znova."
    }
}
