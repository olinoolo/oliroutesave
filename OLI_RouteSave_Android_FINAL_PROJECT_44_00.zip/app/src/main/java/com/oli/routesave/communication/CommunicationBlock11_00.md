# OLI RouteSave 11.0 — Communication foundation

## Included
- Unified communication request model for phone, WhatsApp, Messenger and SMS.
- Audio call, video call and text message modes with validation.
- Time-limited, token-bound explicit confirmation flow.
- Confirmation prompts that name the recipient, channel, action and dictated message text.
- Provider abstraction and safe dispatcher that refuses unconfirmed or mismatched requests.
- Tests for validation and confirmation behavior.

## What is not implemented yet
- This source block does not create Android intents or make a real call.
- WhatsApp and Messenger availability depends on the installed app, platform intents and supported features; no full private API integration is claimed.
- SMS sending, contacts permission UI and Android provider registration must be wired in the app.
- The selected assistant must speak the confirmation prompt through the existing voice session. This block provides the prompt and state flow but does not bind the Android TTS itself.

## Safety
- Every outbound call, message and location share should require explicit confirmation immediately before launch.
- A permission grant is not consent.
- Unclear confirmation never approves an action.
- Confirmation expires after 30 seconds by default.
- Source-only milestone; not compiled or device-tested.
