package com.oli.routesave.presentation

sealed interface MainUiAction {
    data object StartDrive: MainUiAction
    data object StopDrive: MainUiAction
    data object Voice: MainUiAction
    data object OpenRoute: MainUiAction
    data object OpenVehicle: MainUiAction
    data object OpenAssistant: MainUiAction
    data object OpenCommunity: MainUiAction
    data object OpenSettings: MainUiAction
}
