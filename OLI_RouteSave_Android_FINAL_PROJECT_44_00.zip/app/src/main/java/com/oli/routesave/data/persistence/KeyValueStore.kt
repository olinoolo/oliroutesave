package com.oli.routesave.data.persistence
interface KeyValueStore {
    fun getString(key:String, default:String=""):String
    fun putString(key:String,value:String)
    fun getBoolean(key:String,default:Boolean=false):Boolean
    fun putBoolean(key:String,value:Boolean)
    fun remove(key:String)
}
