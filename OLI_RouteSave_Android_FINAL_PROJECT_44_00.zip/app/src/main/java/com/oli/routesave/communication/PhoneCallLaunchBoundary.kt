package com.oli.routesave.communication

/**
 * Safe boundary for the eventual Android phone-call adapter.
 *
 * A real adapter should default to ACTION_DIAL (user completes the call in the
 * system dialer). Direct ACTION_CALL requires runtime CALL_PHONE permission and
 * must only be used after explicit confirmation and applicable policy checks.
 */
enum class PhoneLaunchMode {
    OPEN_DIALER,
    DIRECT_CALL
}

data class PhoneLaunchRequest(
    val normalizedNumber: String,
    val mode: PhoneLaunchMode,
    val confirmedByUser: Boolean
)

sealed interface PhoneLaunchOutcome {
    data object DialerOpened : PhoneLaunchOutcome
    data object CallRequested : PhoneLaunchOutcome
    data class PermissionRequired(val permission: String) : PhoneLaunchOutcome
    data class Rejected(val reason: String) : PhoneLaunchOutcome
}

interface PhoneCallLauncher {
    suspend fun launch(request: PhoneLaunchRequest): PhoneLaunchOutcome
}

class ConfirmationEnforcingPhoneCallLauncher(
    private val delegate: PhoneCallLauncher
) : PhoneCallLauncher {
    override suspend fun launch(request: PhoneLaunchRequest): PhoneLaunchOutcome {
        if (!request.confirmedByUser) {
            return PhoneLaunchOutcome.Rejected("Hovor nemožno spustiť bez jasného potvrdenia používateľa.")
        }
        if (!PhoneNumberSanitizer.looksPlausible(request.normalizedNumber)) {
            return PhoneLaunchOutcome.Rejected("Telefónne číslo sa nepodarilo dostatočne overiť.")
        }
        return delegate.launch(request)
    }
}
