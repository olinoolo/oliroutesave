package com.oli.routesave.messaging

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.os.Bundle

/**
 * Extracts only information Android exposes in a notification.
 * App-specific notification layouts vary; missing fields are expected.
 */
object NotificationMessageExtractor {
    fun extract(
        packageName: String,
        extras: Bundle?,
        receivedAtEpochMillis: Long,
        hasReplyAction: Boolean
    ): MessageNotification? {
        if (extras == null) return null
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
                ?.takeIf { it.isNotBlank() }

        val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        val newestMessage = messages
            ?.mapNotNull { it as? Bundle }
            ?.lastOrNull()
        val messageText = newestMessage?.getCharSequence("text")?.toString()?.trim()
            ?.takeIf { it.isNotBlank() }

        val finalText = messageText ?: text
        if (title.isNullOrBlank() && finalText.isNullOrBlank()) return null

        return MessageNotification(
            packageName = packageName,
            sender = title,
            messagePreview = finalText,
            conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString(),
            receivedAtEpochMillis = receivedAtEpochMillis,
            hasReplyAction = hasReplyAction
        )
    }

    fun hasReplyAction(notification: Notification): Boolean =
        notification.actions.orEmpty().any { action ->
            action.remoteInputs.orEmpty().any { input ->
                input.allowFreeFormInput || input.choices?.isNotEmpty() == true
            }
        }
}
