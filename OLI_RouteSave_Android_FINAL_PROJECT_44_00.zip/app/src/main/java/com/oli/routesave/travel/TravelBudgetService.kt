package com.oli.routesave.travel

import java.util.Calendar
import java.util.TimeZone

class TravelBudgetService(
    private val historyRepository: TripHistoryRepository,
    private val budgetRepository: TravelBudgetRepository,
    private val timeZone: TimeZone = TimeZone.getDefault()
) {
    fun saveMonthlyBudget(limit: Double, currencyCode: String = "EUR", now: Long = System.currentTimeMillis()) {
        budgetRepository.save(TravelBudget(limit, currencyCode, now))
    }

    fun overview(nowEpochMs: Long = System.currentTimeMillis()): TravelBudgetOverview {
        val budget = budgetRepository.get()
        val monthRecords = historyRepository.all().filter { isSameMonth(it.createdAtEpochMs, nowEpochMs) }
        val currency = budget?.currencyCode ?: monthRecords.firstOrNull()?.currencyCode ?: "EUR"
        val records = monthRecords.filter { it.currencyCode == currency }
        val spent = records.sumOf { it.totalCost }
        val limit = budget?.monthlyLimit
        val remaining = limit?.minus(spent)
        val percent = if (limit != null && limit > 0.0) spent / limit * 100.0 else null
        val status = when {
            limit == null -> BudgetStatus.NO_BUDGET
            spent > limit -> BudgetStatus.OVER_LIMIT
            limit > 0.0 && spent >= limit * NEAR_LIMIT_RATIO -> BudgetStatus.NEAR_LIMIT
            else -> BudgetStatus.ON_TRACK
        }
        return TravelBudgetOverview(
            budget = budget,
            spent = spent,
            remaining = remaining,
            percentUsed = percent,
            status = status,
            tripCount = records.size,
            currencyCode = currency
        )
    }

    private fun isSameMonth(timestamp: Long, reference: Long): Boolean {
        val a = Calendar.getInstance(timeZone).apply { timeInMillis = timestamp }
        val b = Calendar.getInstance(timeZone).apply { timeInMillis = reference }
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.MONTH) == b.get(Calendar.MONTH)
    }

    companion object {
        private const val NEAR_LIMIT_RATIO = 0.8
    }
}
