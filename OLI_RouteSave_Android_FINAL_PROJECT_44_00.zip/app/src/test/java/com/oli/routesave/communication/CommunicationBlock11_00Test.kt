package com.oli.routesave.communication

import org.junit.Assert.*
import org.junit.Test

class CommunicationRequestTest {
    @Test fun rejectsEmptyMessage() {
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.SMS,
            mode = CommunicationMode.TEXT_MESSAGE,
            messageText = " "
        )
        assertTrue(request.validate() is CommunicationValidation.Invalid)
    }

    @Test fun rejectsVideoCallOnPhoneChannel() {
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.PHONE,
            mode = CommunicationMode.VIDEO_CALL
        )
        assertTrue(request.validate() is CommunicationValidation.Invalid)
    }

    @Test fun acceptsWhatsappVideoCall() {
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.WHATSAPP,
            mode = CommunicationMode.VIDEO_CALL
        )
        assertEquals(CommunicationValidation.Valid, request.validate())
    }
}

class CommunicationConfirmationFlowTest {
    @Test fun onlyClearYesConfirmsAndConfirmationIsOneUse() {
        var now = 1_000L
        val flow = CommunicationConfirmationFlow(nowMillis = { now })
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.PHONE,
            mode = CommunicationMode.AUDIO_CALL
        )
        val awaiting = flow.request(request) as CommunicationConfirmationResult.Awaiting
        val unclear = flow.respond(awaiting.confirmation.token, "možno")
        assertTrue(unclear is CommunicationConfirmationResult.Awaiting)

        val confirmed = flow.respond(awaiting.confirmation.token, "áno")
        assertEquals(CommunicationConfirmationResult.Confirmed(request), confirmed)
        assertTrue(flow.respond(awaiting.confirmation.token, "áno") is CommunicationConfirmationResult.Rejected)
    }

    @Test fun expiredConfirmationCannotApprove() {
        var now = 100L
        val flow = CommunicationConfirmationFlow(timeoutMillis = 20L, nowMillis = { now })
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.PHONE,
            mode = CommunicationMode.AUDIO_CALL
        )
        val awaiting = flow.request(request) as CommunicationConfirmationResult.Awaiting
        now = 121L
        assertTrue(flow.respond(awaiting.confirmation.token, "áno") is CommunicationConfirmationResult.Rejected)
    }

    @Test fun noConfirmationCannotDispatch() {
        val provider = object : CommunicationProvider {
            override fun capability() = CommunicationCapability(
                CommunicationChannel.PHONE, audioCall = true, videoCall = false, textMessage = false
            )
            override fun launchConfirmed(request: CommunicationRequest) = CommunicationLaunchResult.Launched
        }
        val request = CommunicationRequest(
            recipientDisplayName = "Branislav",
            channel = CommunicationChannel.PHONE,
            mode = CommunicationMode.AUDIO_CALL
        )
        val dispatcher = ConfirmedCommunicationDispatcher(mapOf(CommunicationChannel.PHONE to provider))
        assertTrue(dispatcher.dispatch(CommunicationConfirmationResult.Cancelled, request) is CommunicationLaunchResult.Failed)
    }
}
