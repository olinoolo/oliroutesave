package com.oli.routesave.presentation

import com.oli.routesave.core.RouteSaveApplicationState
import com.oli.routesave.ui.DriveUiState
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class MainUiPresenterTest {
    @Test fun presentsDriveState() {
        val state = RouteSaveApplicationState(
            drive = DriveUiState(
                assistantInvocation = "Niko",
                vehicleName = "Audi A6",
                destination = "Praha",
                etaText = "14:20",
                remainingKm = 120.0,
                isDriving = true
            )
        )
        val model = MainUiPresenter().present(state)
        assertEquals("Niko", model.assistantInvocation)
        assertEquals("Audi A6", model.vehicleName)
        assertEquals("Praha", model.destination)
        assertEquals("120.0 km", model.remainingKm)
        assertTrue(model.driving)
    }
}
