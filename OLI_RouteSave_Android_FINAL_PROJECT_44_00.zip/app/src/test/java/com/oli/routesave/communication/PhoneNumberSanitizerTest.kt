package com.oli.routesave.communication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberSanitizerTest {
    @Test fun removesCommonFormattingOnly() {
        assertEquals("+421903123456", PhoneNumberSanitizer.keepDialableCharacters("+421 903-123-456"))
    }

    @Test fun doesNotInventCountryCode() {
        assertEquals("0903123456", PhoneNumberSanitizer.keepDialableCharacters("0903 123 456"))
    }

    @Test fun plausibleLengthIsBounded() {
        assertTrue(PhoneNumberSanitizer.looksPlausible("0903123456"))
        assertFalse(PhoneNumberSanitizer.looksPlausible("1"))
    }
}
