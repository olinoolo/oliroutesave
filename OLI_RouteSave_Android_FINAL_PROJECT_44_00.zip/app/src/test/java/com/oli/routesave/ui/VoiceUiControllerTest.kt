package com.oli.routesave.ui

import kotlin.test.Test
import kotlin.test.assertTrue

class VoiceUiControllerTest {
    @Test fun assistantButtonStartsListening() {
        val drive = DriveUiController()
        val voice = VoiceUiController(drive)
        voice.pressAssistantButton()
        assertTrue(drive.state().voiceListening)
    }
}
