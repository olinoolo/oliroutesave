package com.oli.routesave.ui

import kotlin.test.Test
import kotlin.test.assertEquals

class AppNavigatorTest {
    @Test fun navigatesAndReturns() {
        val n = AppNavigator()
        n.navigate(AppScreen.ROUTE)
        n.navigate(AppScreen.VEHICLE)
        assertEquals(AppScreen.VEHICLE, n.current())
        assertEquals(AppScreen.ROUTE, n.back())
        assertEquals(AppScreen.HOME, n.back())
    }
}
