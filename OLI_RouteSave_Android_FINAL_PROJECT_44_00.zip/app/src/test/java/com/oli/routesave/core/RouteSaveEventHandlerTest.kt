package com.oli.routesave.core

import com.oli.routesave.android.runtime.*
import com.oli.routesave.data.persistence.*
import com.oli.routesave.data.store.*
import com.oli.routesave.runtime.*
import com.oli.routesave.runtime.location.*
import com.oli.routesave.ui.*
import kotlin.test.Test
import kotlin.test.assertEquals

class RouteSaveEventHandlerTest {
    private class Permissions : PermissionChecker {
        override fun isGranted(permission: AndroidPermission) =
            permission == AndroidPermission.LOCATION_FINE
    }

    private class Location : LocationProvider {
        override fun start(onLocation:(LocationPoint)->Unit) {}
        override fun stop() {}
        override fun isActive() = true
    }

    private class Navigation : NavigationProvider {
        override suspend fun calculateRoute(origin:String,destination:String) =
            Result.success(NavigationRoute(1.0,1,destination))
    }

    private class Fg : ForegroundController {
        override fun start() {}
        override fun stop() {}
    }

    private class Audio : AudioFocusController {
        override fun request() {}
        override fun abandon() {}
    }

    private class Notification : DriveNotificationController {
        override fun show() {}
        override fun hide() {}
    }

    @Test fun appStartsAndDriveCanStart() {
        val graph = RouteSaveDependencyGraph(
            Permissions(), Location(), Navigation(), Fg(), Audio(), Notification()
        )
        val runtime = graph.createRuntime()
        val handler = RouteSaveEventHandler(runtime)

        handler.handle(RouteSaveEvent.AppStarted)
        val state = handler.handle(RouteSaveEvent.StartDrive)

        assertEquals(true, state.readyForDrive)
        assertEquals(true, state.drive.isDriving)
    }
}
