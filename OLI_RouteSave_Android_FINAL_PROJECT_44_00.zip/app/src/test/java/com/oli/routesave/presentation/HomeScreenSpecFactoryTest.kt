package com.oli.routesave.presentation

import kotlin.test.Test
import kotlin.test.assertEquals

class HomeScreenSpecFactoryTest {
    @Test fun startButtonChangesWithDriveState() {
        val stopped = HomeScreenSpecFactory.create(MainUiModel(driving=false))
        val active = HomeScreenSpecFactory.create(MainUiModel(driving=true))
        assertEquals("Spustiť jazdu", stopped.primaryButton)
        assertEquals("Ukončiť jazdu", active.primaryButton)
    }
}
