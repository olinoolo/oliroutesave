package com.oli.routesave.communication

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneCallLaunchBoundaryTest {
    @Test fun blocksLaunchWithoutConfirmation() = runBlocking {
        val fake = object : PhoneCallLauncher {
            override suspend fun launch(request: PhoneLaunchRequest) = PhoneLaunchOutcome.CallRequested
        }
        val launcher = ConfirmationEnforcingPhoneCallLauncher(fake)
        val result = launcher.launch(PhoneLaunchRequest("0903123456", PhoneLaunchMode.DIRECT_CALL, false))
        assertTrue(result is PhoneLaunchOutcome.Rejected)
    }

    @Test fun blocksImplausibleNumber() = runBlocking {
        val fake = object : PhoneCallLauncher {
            override suspend fun launch(request: PhoneLaunchRequest) = PhoneLaunchOutcome.CallRequested
        }
        val launcher = ConfirmationEnforcingPhoneCallLauncher(fake)
        val result = launcher.launch(PhoneLaunchRequest("1", PhoneLaunchMode.OPEN_DIALER, true))
        assertTrue(result is PhoneLaunchOutcome.Rejected)
    }
}
