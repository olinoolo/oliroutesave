package com.oli.routesave.voice.ui

import com.oli.routesave.voice.assistant.DefaultAssistantProfiles
import com.oli.routesave.voice.assistant.VoiceAssistantCoordinator
import com.oli.routesave.voice.intent.PendingExternalAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceAssistantUiBridgeTest {
    private class FakeSpeech : AssistantSpeechOutput {
        val spoken = mutableListOf<String>()
        override fun speak(text: String, languageTag: String) { spoken += text }
        override fun stop() = Unit
    }

    @Test
    fun breakdownWaitsForConfirmation() {
        val speech = FakeSpeech()
        var approved: PendingExternalAction? = null
        val bridge = VoiceAssistantUiBridge(
            VoiceAssistantCoordinator(nowMillis = { 1L }),
            speech,
            onApprovedExternalAction = { approved = it }
        )
        bridge.onRecognition("Niko, mám defekt", DefaultAssistantProfiles.nikolas)
        assertTrue(bridge.state.needsConfirmation)
        assertEquals(null, approved)
        bridge.confirm(false, DefaultAssistantProfiles.nikolas)
        assertFalse(bridge.state.needsConfirmation)
        assertEquals(null, approved)
    }

    @Test
    fun confirmedExternalActionIsOnlyHandedToExecutorCallback() {
        val speech = FakeSpeech()
        var approved: PendingExternalAction? = null
        val bridge = VoiceAssistantUiBridge(
            VoiceAssistantCoordinator(nowMillis = { 2L }),
            speech,
            onApprovedExternalAction = { approved = it }
        )
        bridge.onRecognition("Niko, zavolaj manželke", DefaultAssistantProfiles.nikolas)
        bridge.confirm(true, DefaultAssistantProfiles.nikolas)
        assertTrue(approved != null)
        assertEquals("CALL", approved?.actionType?.name)
    }
}
