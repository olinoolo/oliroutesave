package com.oli.routesave.messaging

import android.app.Notification
import android.os.Bundle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class NotificationMessageExtractorTest {
    @Test
    fun extractsAvailableNotificationTitleAndPreview() {
        val extras = Bundle().apply {
            putCharSequence(Notification.EXTRA_TITLE, "Peter")
            putCharSequence(Notification.EXTRA_TEXT, "Prídeš dnes?")
        }
        val result = NotificationMessageExtractor.extract(
            "com.example.chat", extras, 10L, false
        )
        assertNotNull(result)
        assertEquals("Peter", result?.sender)
        assertEquals("Prídeš dnes?", result?.messagePreview)
    }

    @Test
    fun emptyNotificationIsIgnored() {
        assertNull(NotificationMessageExtractor.extract("com.example.chat", Bundle(), 10L, false))
    }
}
