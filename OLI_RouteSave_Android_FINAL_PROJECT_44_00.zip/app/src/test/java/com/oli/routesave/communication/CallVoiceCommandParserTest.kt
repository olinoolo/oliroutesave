package com.oli.routesave.communication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class CallVoiceCommandParserTest {
    private val parser = CallVoiceCommandParser()

    @Test fun parsesWhatsAppVideoCall() {
        val result = parser.parse("Niko, spusti videohovor s manželkou cez WhatsApp")
        assertNotNull(result)
        assertEquals(CallChannel.WHATSAPP, result!!.channel)
        assertEquals(CallMode.VIDEO, result.mode)
        assert(result.destinationText.contains("manželkou"))
    }

    @Test fun parsesMessengerAudioCall() {
        val result = parser.parse("Niko, zavolaj bratovi cez Messenger")
        assertNotNull(result)
        assertEquals(CallChannel.MESSENGER, result!!.channel)
        assertEquals(CallMode.AUDIO, result.mode)
    }

    @Test fun parsesUnsavedNumberForPhoneCall() {
        val result = parser.parse("Niko, zavolaj na číslo 0903123456")
        assertNotNull(result)
        assertEquals(CallChannel.PHONE, result!!.channel)
        assert(result.destinationText.contains("0903123456"))
    }
}
