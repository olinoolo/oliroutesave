package com.oli.routesave.voice.assistant

import com.oli.routesave.voice.intent.ExternalActionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceAssistantCoordinatorTest {
    private val coordinator = VoiceAssistantCoordinator(nowMillis = { 100L })

    @Test
    fun routeWithoutDestinationAsksClarification() {
        val result = coordinator.handleSpeech("Niko, naplánuj trasu", DefaultAssistantProfiles.nikolas)
        assertTrue(result is AssistantOutcome.NeedsClarification)
    }

    @Test
    fun routeWithDestinationProducesRouteRequest() {
        val result = coordinator.handleSpeech("Niko, naplánuj trasu do Piešťan", DefaultAssistantProfiles.nikolas)
        assertTrue(result is AssistantOutcome.RouteRequested)
        assertEquals("pieštan", (result as AssistantOutcome.RouteRequested).destination)
    }

    @Test
    fun helpRequestMustBeConfirmedBeforeExternalAction() {
        val result = coordinator.handleSpeech("Niko, mám defekt", DefaultAssistantProfiles.nikolas)
        assertTrue(result is AssistantOutcome.AwaitingConfirmation)
        val denied = coordinator.confirmExternalAction(false, DefaultAssistantProfiles.nikolas)
        assertTrue(denied is AssistantOutcome.Speak)
    }

    @Test
    fun confirmedCallReturnsApprovedActionButDoesNotCallItself() {
        val result = coordinator.handleSpeech("Niko, zavolaj manželke", DefaultAssistantProfiles.nikolas)
        assertTrue(result is AssistantOutcome.AwaitingConfirmation)
        val confirmed = coordinator.confirmExternalAction(true, DefaultAssistantProfiles.nikolas)
        assertTrue(confirmed is AssistantOutcome.ExternalActionApproved)
        assertEquals(ExternalActionType.CALL, (confirmed as AssistantOutcome.ExternalActionApproved).action.actionType)
    }
}
