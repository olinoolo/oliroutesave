package com.oli.routesave.android.runtime
import kotlin.test.*
class ForegroundServicePolicyTest{
 @Test fun activeLocationNeedsService(){assertTrue(ForegroundServicePolicy().shouldRunForegroundService(true,false,true))}
 @Test fun stoppedDriveStops(){assertTrue(ForegroundServicePolicy().shouldStopForegroundService(false,false))}
}
