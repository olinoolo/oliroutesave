package com.oli.routesave.communication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberEntryParserTest {
    private val parser = PhoneNumberEntryParser()

    @Test fun acceptsFormattedNumberForReadback() {
        assertEquals(
            PhoneNumberEntryResult.AcceptedForReview("+421903123456"),
            parser.parse("+421 903-123-456")
        )
    }

    @Test fun asksToRepeatWhenNoNumberWasRecognized() {
        assertTrue(parser.parse("zavolaj manželke") is PhoneNumberEntryResult.NeedsClarification)
    }

    @Test fun rejectsClearlyShortNumber() {
        assertTrue(parser.parse("12") is PhoneNumberEntryResult.Rejected)
    }
}
