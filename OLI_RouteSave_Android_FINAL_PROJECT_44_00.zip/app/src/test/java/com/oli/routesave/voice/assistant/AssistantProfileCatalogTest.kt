package com.oli.routesave.voice.assistant

import org.junit.Assert.*
import org.junit.Test

class AssistantProfileCatalogTest {
    @Test fun catalogIncludesRequestedAssistantsAndInvocations() {
        assertEquals(7, AssistantProfileCatalog.all.size)
        assertEquals("Niko", AssistantProfileCatalog.byId("nikolas")?.invocationName)
        assertEquals("Brandži", AssistantProfileCatalog.byId("branislav")?.invocationName)
        assertEquals("Naty", AssistantProfileCatalog.byId("natalia")?.invocationName)
        assertEquals("Vany", AssistantProfileCatalog.byId("vanesa")?.invocationName)
        assertEquals("cs-CZ", AssistantProfileCatalog.byId("katerina")?.languageTag)
    }

    @Test fun invocationLookupIgnoresCaseAndDiacritics() {
        assertEquals("branislav", AssistantProfileCatalog.byInvocation("BRANDZI")?.id)
        assertEquals("natalia", AssistantProfileCatalog.byInvocation("NATY")?.id)
    }
}

class VoiceAssistantSettingsManagerTest {
    @Test fun selectingAssistantUpdatesSelectedIdAndDefaultLanguage() {
        val manager = VoiceAssistantSettingsManager(InMemoryVoiceAssistantSettingsStore())
        val result = manager.selectAssistant("katerina")
        assertTrue(result is AssistantSettingsResult.Saved)
        assertEquals("katerina", manager.current().selectedAssistantId)
        assertEquals("cs-CZ", manager.current().languageTag)
    }

    @Test fun unsupportedLanguageIsRejectedWithoutSaving() {
        val store = InMemoryVoiceAssistantSettingsStore()
        val manager = VoiceAssistantSettingsManager(store)
        val result = manager.update(languageTag = "xx-XX")
        assertTrue(result is AssistantSettingsResult.Rejected)
        assertEquals("sk-SK", manager.current().languageTag)
    }

    @Test fun supportedRomanianLanguageCanBeSelected() {
        val manager = VoiceAssistantSettingsManager(InMemoryVoiceAssistantSettingsStore())
        val result = manager.update(languageTag = "ro-RO")
        assertTrue(result is AssistantSettingsResult.Saved)
        assertEquals("ro-RO", manager.current().languageTag)
    }
}
