package com.oli.routesave.runtime.navigation

import com.oli.routesave.ui.NavigationProvider
import com.oli.routesave.ui.NavigationRoute
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlinx.coroutines.runBlocking

class NavigationSessionTest {
    private val provider = object : NavigationProvider {
        override suspend fun calculateRoute(origin: String, destination: String) =
            Result.success(
                NavigationRoute(
                    distanceKm = 120.0,
                    durationMinutes = 90,
                    destination = destination
                )
            )
    }

    @Test fun routeLifecycle() = runBlocking {
        val s = NavigationSession(provider)
        s.calculate("Myjava", "Bratislava")
        assertEquals(NavigationSessionState.READY, s.state())
        s.start()
        assertEquals(NavigationSessionState.ACTIVE, s.state())
        s.pause()
        assertEquals(NavigationSessionState.PAUSED, s.state())
        s.resume()
        assertEquals(NavigationSessionState.ACTIVE, s.state())
        s.arrive()
        assertEquals(NavigationSessionState.ARRIVED, s.state())
    }
}
