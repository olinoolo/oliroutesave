package com.oli.routesave.android.runtime

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DriveRuntimeCoordinatorTest {

    private class Fg : ForegroundController {
        var started = false
        override fun start() { started = true }
        override fun stop() { started = false }
    }

    private class Loc : LocationController {
        var active = false
        override fun start() { active = true }
        override fun pause() { active = false }
        override fun stop() { active = false }
    }

    private class Audio : AudioFocusController {
        var active = false
        override fun request() { active = true }
        override fun abandon() { active = false }
    }

    private class Notif : DriveNotificationController {
        var active = false
        override fun show() { active = true }
        override fun hide() { active = false }
    }

    @Test
    fun startActivatesDriveRuntime() {
        val fg = Fg()
        val loc = Loc()
        val audio = Audio()
        val notif = Notif()
        val c = DriveRuntimeCoordinator(fg, loc, audio, notif)

        val s = c.handle(DriveRuntimeEvent.Start)

        assertEquals(DriveRuntimeState.RUNNING, s.state)
        assertTrue(fg.started)
        assertTrue(loc.active)
        assertTrue(audio.active)
        assertTrue(notif.active)
    }

    @Test
    fun stopReleasesRuntimeResources() {
        val fg = Fg()
        val loc = Loc()
        val audio = Audio()
        val notif = Notif()
        val c = DriveRuntimeCoordinator(fg, loc, audio, notif)

        c.handle(DriveRuntimeEvent.Start)
        val s = c.handle(DriveRuntimeEvent.Stop)

        assertEquals(DriveRuntimeState.STOPPED, s.state)
        assertTrue(!fg.started)
        assertTrue(!loc.active)
        assertTrue(!audio.active)
        assertTrue(!notif.active)
    }

    @Test
    fun safetyBlocksStartDuringActiveCall() {
        val gate = DriveRuntimeSafetyGate()
        val permissions = DrivePermissionState(fineLocation = true)

        assertTrue(!gate.canStart(permissions, emergencyActive = false, activeCall = true))
    }
}
