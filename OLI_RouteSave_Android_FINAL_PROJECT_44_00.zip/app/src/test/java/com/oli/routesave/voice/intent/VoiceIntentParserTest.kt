package com.oli.routesave.voice.intent

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class VoiceIntentParserTest {
    private val parser = VoiceIntentParser()

    @Test
    fun parsesNikoCallAndRequiresConfirmation() {
        val result = parser.parse("Niko, zavolaj manželke")
        assertEquals(VoiceIntentType.CALL_CONTACT, result.type)
        assertEquals(ConfirmationRequirement.REQUIRED, result.confirmationRequirement)
        assertEquals("niko", result.assistantInvocation)
    }

    @Test
    fun breakdownDoesNotPublishHelpAutomatically() {
        val result = parser.parse("Niko, mám defekt")
        assertEquals(VoiceIntentType.REPORT_BREAKDOWN, result.type)
        assertEquals(ConfirmationRequirement.REQUIRED, result.confirmationRequirement)
    }

    @Test
    fun unknownSpeechStaysUnknown() {
        val result = parser.parse("Niko, povedz mi niečo zaujímavé")
        assertEquals(VoiceIntentType.UNKNOWN, result.type)
    }
}
