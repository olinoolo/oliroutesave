package com.oli.routesave.android.runtime
import kotlin.test.*
class DriveReadinessCheckerTest{
 private class F(private val s:Set<AndroidPermission>):PermissionChecker{override fun isGranted(p:AndroidPermission)=p in s}
 @Test fun locationReady(){assertTrue(DriveReadinessChecker(PermissionController(F(setOf(AndroidPermission.LOCATION_FINE)))).check().ready)}
 @Test fun noLocationBlocks(){assertFalse(DriveReadinessChecker(PermissionController(F(emptySet()))).check().ready)}
}
