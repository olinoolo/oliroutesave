package com.oli.routesave.community

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CommunityHelpConsentFlowTest {
    private fun request(now: Long = 1_000L) = CommunityHelpRequest(
        requestId = "req-1",
        requesterId = "user-1",
        requesterType = HelperUserType.DRIVER,
        category = HelpCategory.FLAT_TIRE,
        description = "Defekt na krajnici",
        latitude = 48.0,
        longitude = 17.0,
        radiusKm = 10.0,
        urgency = HelpUrgency.NORMAL,
        createdAtEpochMillis = now,
        expiresAtEpochMillis = now + 60_000L
    )

    @Test fun requestIsNotPublishedUntilClearYes() {
        var now = 1_000L
        val flow = CommunityHelpConsentFlow { now }
        val prepared = flow.prepare(request(now)) as CommunityHelpConsentResult.NeedsConfirmation
        val unclear = flow.respond(prepared.request.requestId, "možno")
        assertTrue(unclear is CommunityHelpConsentResult.NeedsConfirmation)
        val confirmed = flow.respond(prepared.request.requestId, "áno") as CommunityHelpConsentResult.Confirmed
        assertEquals(HelpRequestStatus.PUBLISHED, confirmed.request.status)
    }

    @Test fun noCancelsRequest() {
        val flow = CommunityHelpConsentFlow { 1_000L }
        val prepared = flow.prepare(request()) as CommunityHelpConsentResult.NeedsConfirmation
        assertEquals(
            CommunityHelpConsentResult.Cancelled,
            flow.respond(prepared.request.requestId, "nie")
        )
    }

    @Test fun invalidRadiusRejected() {
        val bad = request().copy(radiusKm = 0.1)
        assertTrue(CommunityHelpRequestValidator.validate(bad) is CommunityHelpValidation.Invalid)
    }

    @Test fun publisherRejectsUnconfirmedRequest() = runBlocking {
        val repository = object : CommunityHelpRepository {
            override suspend fun publishConfirmed(request: CommunityHelpRequest) =
                CommunityPublishResult.Published(request.requestId)
            override suspend fun cancel(requestId: String) = true
        }
        val publisher = ConfirmedCommunityHelpPublisher(repository) { 1_000L }
        assertTrue(publisher.publish(request()) is CommunityPublishResult.Rejected)
    }
}
