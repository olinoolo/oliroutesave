package com.oli.routesave.driver

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class DriverBreakPlannerTest {
    @Test fun warnsThirtyMinutesBeforeConfiguredDeadline() {
        val planner = DriverBreakPlanner(DriverBreakPreferences(reminderLeadMinutes = 30))
        val session = DriverWorkSession(
            sessionStartedAtMillis = 0L,
            nextBreakDueAtMillis = 3_600_000L
        )
        val result = planner.nextReminder(session, 1_800_000L) as BreakPlannerResult.Reminder
        assertEquals(BreakReminderKind.APPROACHING_BREAK, result.reminder.kind)
    }

    @Test fun doesNotRemindWhenNotDrivingOrAlreadyOnBreak() {
        val planner = DriverBreakPlanner()
        val session = DriverWorkSession(
            sessionStartedAtMillis = 0L,
            nextBreakDueAtMillis = 3_600_000L,
            isDriving = false
        )
        assertEquals(BreakPlannerResult.NoReminder, planner.nextReminder(session, 3_600_000L))
    }

    @Test fun plansFortyFiveMinuteBreakByDefault() {
        val planner = DriverBreakPlanner()
        assertEquals(2_700_000L, planner.plannedBreakEnd(0L))
    }
}

class EntertainmentSafetyPolicyTest {
    @Test fun defersDuringCriticalNavigation() {
        assertEquals(
            EntertainmentAction.PAUSE_OR_DEFER,
            EntertainmentSafetyPolicy.chooseAction(
                EntertainmentType.MUSIC,
                DrivingSafetyContext(true, true, false, false)
            )
        )
    }

    @Test fun avoidsWordGameWhileDriving() {
        assertEquals(
            EntertainmentAction.PAUSE_OR_DEFER,
            EntertainmentSafetyPolicy.chooseAction(
                EntertainmentType.WORD_GAME,
                DrivingSafetyContext(true, false, false, false)
            )
        )
    }
}

class RestStopSearchServiceTest {
    @Test fun sortsValidStopsByDistance() = runBlocking {
        val provider = object : RestStopProvider {
            override suspend fun searchNearby(latitude: Double, longitude: Double, radiusKm: Double) =
                listOf(
                    RestStop("2", "Stop B", 48.0, 17.0, 12.0),
                    RestStop("1", "Stop A", 48.1, 17.1, 4.0)
                )
        }
        val result = RestStopSearchService(provider).search(48.0, 17.0, 20.0) as RestStopSearchResult.Success
        assertEquals("Stop A", result.stops.first().name)
    }
}
