package com.oli.routesave.ui

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ScreenContentCatalogTest {
    @Test fun homeHasDriveAction() {
        val spec = ScreenContentCatalog.forScreen(AppScreen.HOME)
        assertEquals("Spustiť jazdu", spec.primaryAction)
    }

    @Test fun communityUsesHelpNetworkLabel() {
        val spec = ScreenContentCatalog.forScreen(AppScreen.COMMUNITY)
        assertTrue(spec.title.contains("pomáhajú"))
    }
}
