package com.oli.routesave.runtime.location

import kotlin.test.Test
import kotlin.test.assertEquals

class LocationSessionTest {
    private class FakeProvider : LocationProvider {
        private var active = false
        private var callback: ((LocationPoint) -> Unit)? = null
        override fun start(onLocation: (LocationPoint) -> Unit) {
            active = true
            callback = onLocation
            onLocation(LocationPoint(48.0, 17.0, 5f, 1L))
        }
        override fun stop() { active = false }
        override fun isActive() = active
    }

    @Test fun receivesLatestLocation() {
        val s = LocationSession(FakeProvider())
        s.start {}
        assertEquals(48.0, s.lastLocation()!!.latitude)
        assertEquals(17.0, s.lastLocation()!!.longitude)
    }
}
