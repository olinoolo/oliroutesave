package com.oli.routesave.communication

import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceCallCommandHandlerTest {
    private val handler = VoiceCallCommandHandler()

    @Test fun contactPhraseRequestsContactSearch() {
        val result = handler.handle("Niko, zavolaj Petrovi cez Messenger")
        assertTrue(result is VoiceCallCommandOutcome.ContactSearchRequested)
    }

    @Test fun dictatedNumberIsSentForReviewNotCalledImmediately() {
        val result = handler.handle("Niko, zavolaj na číslo +421 903 123 456")
        assertTrue(result is VoiceCallCommandOutcome.NumberNeedsReview)
    }

    @Test fun unknownCommandAsksClarification() {
        val result = handler.handle("Niko, urob niečo")
        assertTrue(result is VoiceCallCommandOutcome.AskUser)
    }
}
