package com.oli.routesave.android.ui

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class UiActionGuardTest {
    @Test fun locationIsRequiredForDrive() {
        val g = UiActionGuard()
        assertTrue(g.canStartDrive(true))
        assertFalse(g.canStartDrive(false))
    }

    @Test fun microphoneIsRequiredForVoice() {
        val g = UiActionGuard()
        assertTrue(g.canUseVoice(true))
        assertFalse(g.canUseVoice(false))
    }
}
