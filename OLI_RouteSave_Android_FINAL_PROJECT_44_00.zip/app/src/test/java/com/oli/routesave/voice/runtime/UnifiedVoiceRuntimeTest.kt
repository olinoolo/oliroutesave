package com.oli.routesave.voice.runtime

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFails
import kotlin.test.assertTrue

class UnifiedVoiceRuntimeTest {

    private val context = UnifiedVoiceContext(
        assistantName = "Nikolas",
        invocationName = "Niko",
        personalAddress = null,
        driving = true,
        navigationCritical = false,
        emergencyActive = false,
        activeCall = false,
        pendingConfirmation = false
    )

    @Test
    fun invocationStartsListening() {
        val runtime = UnifiedVoiceRuntime()

        runtime.invoke(context)

        assertEquals(
            UnifiedVoiceState.LISTENING,
            runtime.state()
        )
    }

    @Test
    fun externalActionRequiresConfirmation() {
        val runtime = UnifiedVoiceRuntime()

        val action = UnifiedVoiceAction(
            "zavolal manželke",
            UnifiedVoiceConfirmation.REQUIRED,
            external = true
        )

        runtime.requestConfirmation(context, action)

        val failure = runtime.execute(context, action)

        assertTrue(failure.isFailure)
    }

    @Test
    fun confirmedExternalActionCanExecute() {
        val runtime = UnifiedVoiceRuntime()

        val action = UnifiedVoiceAction(
            "zavolal manželke",
            UnifiedVoiceConfirmation.CONFIRMED,
            external = true
        )

        val result = runtime.execute(context, action)

        assertTrue(result.isSuccess)
    }

    @Test
    fun emergencyInterruptsVoice() {
        val runtime = UnifiedVoiceRuntime()

        runtime.invoke(context)

        runtime.interrupt(
            UnifiedVoiceEventType.EMERGENCY
        )

        assertEquals(
            UnifiedVoiceState.INTERRUPTED,
            runtime.state()
        )
    }

    @Test
    fun bargeInReturnsToListening() {
        val runtime = UnifiedVoiceRuntime()

        runtime.invoke(context)
        runtime.processSpeech("Povedz mi niečo")
        runtime.finishSpeech()

        runtime.interrupt(
            UnifiedVoiceEventType.BARGE_IN
        )

        assertEquals(
            UnifiedVoiceState.LISTENING,
            runtime.state()
        )
    }
}
