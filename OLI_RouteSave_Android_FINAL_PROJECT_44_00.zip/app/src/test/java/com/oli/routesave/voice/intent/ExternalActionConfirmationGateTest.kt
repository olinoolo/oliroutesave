package com.oli.routesave.voice.intent

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ExternalActionConfirmationGateTest {
    @Test
    fun pendingActionNeedsExplicitYes() {
        val gate = ExternalActionConfirmationGate()
        gate.requestConfirmation(PendingExternalAction(
            ExternalActionType.SHARE_LOCATION,
            "Zdieľať tvoju polohu s ľuďmi v okolí.",
            1L
        ))
        assertFalse(!gate.hasPendingAction())
        assertNull(gate.confirm(false))
        assertFalse(gate.hasPendingAction())
    }

    @Test
    fun yesReturnsOnlyTheActionThatWasConfirmed() {
        val gate = ExternalActionConfirmationGate()
        val pending = PendingExternalAction(ExternalActionType.CALL, "Zavolať kontaktu.", 2L)
        gate.requestConfirmation(pending)
        assertNotNull(gate.confirm(true))
    }
}
