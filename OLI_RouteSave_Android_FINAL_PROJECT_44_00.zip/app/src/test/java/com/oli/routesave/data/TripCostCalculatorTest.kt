package com.oli.routesave.data

import kotlin.test.Test
import kotlin.test.assertEquals

class TripCostCalculatorTest {

    @Test
    fun calculatesFuelCostFromVehicleConsumption() {
        val result = TripCostCalculator.fuelCost(
            distanceKm = 500.0,
            consumptionL100Km = 5.0,
            fuelPricePerLiter = 1.60
        )
        assertEquals(40.0, result, absoluteTolerance = 0.0001)
    }

    @Test
    fun calculatesTotalTripCost() {
        val result = TripCostCalculator.totalCost(
            distanceKm = 500.0,
            consumptionL100Km = 5.0,
            fuelPricePerLiter = 1.60,
            tollCost = 12.0,
            parkingCost = 8.0
        )
        assertEquals(60.0, result, absoluteTolerance = 0.0001)
    }
}
