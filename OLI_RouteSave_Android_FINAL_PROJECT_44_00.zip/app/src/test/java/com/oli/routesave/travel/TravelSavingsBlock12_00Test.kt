package com.oli.routesave.travel

import org.junit.Assert.*
import org.junit.Test

class TripCostCalculatorTest {
    private val calculator = TripCostCalculator()

    @Test fun calculatesFuelAndAdditionalCostsFromVehicleProfile() {
        val vehicle = VehicleProfile("car-1", "My car", 6.0, 1.70)
        val result = calculator.estimate(
            vehicle,
            TripCostInput(distanceKm = 600.0, fuelPricePerLitre = 1.70, tollCost = 12.0, parkingCost = 5.0)
        ) as TripCostResult.Success

        assertEquals(36.0, result.estimate.fuelLitres, 0.0001)
        assertEquals(61.2, result.estimate.fuelCost, 0.0001)
        assertEquals(78.2, result.estimate.totalCost, 0.0001)
    }

    @Test fun tripOverrideTakesPrecedence() {
        val vehicle = VehicleProfile("car-1", "My car", 6.0)
        val result = calculator.estimate(
            vehicle,
            TripCostInput(100.0, 2.0, consumptionOverrideLitresPer100Km = 8.0)
        ) as TripCostResult.Success

        assertEquals(8.0, result.estimate.consumptionLitresPer100Km, 0.0001)
        assertEquals(16.0, result.estimate.fuelCost, 0.0001)
    }

    @Test fun rejectsNegativeDistance() {
        val result = calculator.estimate(
            VehicleProfile("car-1", "My car", 6.0),
            TripCostInput(-1.0, 1.7)
        )
        assertTrue(result is TripCostResult.Invalid)
    }
}

class TravelComparisonTest {
    @Test fun findsCheapestAndFastestKnownOptions() {
        val comparison = TravelComparison(
            origin = "Myjava",
            destination = "Bratislava",
            options = listOf(
                TravelOption(TravelMode.CAR, 110, 28.0),
                TravelOption(TravelMode.TRAIN, 150, 12.0),
                TravelOption(TravelMode.BUS, 140, 10.0),
                TravelOption(TravelMode.PLANE)
            )
        )
        assertEquals(TravelMode.BUS, comparison.cheapestKnownOption()?.mode)
        assertEquals(TravelMode.CAR, comparison.fastestKnownOption()?.mode)
    }
}
