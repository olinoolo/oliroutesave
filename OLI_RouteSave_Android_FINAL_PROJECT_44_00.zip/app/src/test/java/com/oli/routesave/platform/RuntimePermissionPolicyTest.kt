package com.oli.routesave.platform

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimePermissionPolicyTest {
    @Test
    fun externalActionRequiresPermissionAndExplicitConfirmation() {
        assertFalse(RuntimePermissionPolicy.mayPerformExternalAction(false, true))
        assertFalse(RuntimePermissionPolicy.mayPerformExternalAction(true, false))
        assertTrue(RuntimePermissionPolicy.mayPerformExternalAction(true, true))
    }

    @Test
    fun voicePermissionIsRequestedOnlyForVoiceUseCase() {
        val decision = RuntimePermissionPolicy.decisionFor(PermissionUseCase.ACTIVATE_VOICE)
        assertTrue(decision.permissions.contains(RouteSavePermission.MICROPHONE))
        assertTrue(decision.shouldAskNow)
    }
}
