package com.oli.routesave.android.runtime
import kotlin.test.*
class AudioFocusPolicyTest{@Test fun emergencyWins(){assertTrue(AudioFocusPolicy().canInterrupt(AudioFocusMode.NAVIGATION_GUIDANCE,AudioFocusMode.EMERGENCY))}}
