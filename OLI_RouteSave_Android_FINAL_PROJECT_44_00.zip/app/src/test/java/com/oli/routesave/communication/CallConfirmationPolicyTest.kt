package com.oli.routesave.communication

import org.junit.Assert.assertEquals
import org.junit.Test

class CallConfirmationPolicyTest {
    private val policy = CallConfirmationPolicy()

    @Test fun yesApprovesOnlyMatchingUnexpiredNonce() {
        assertEquals(
            ConfirmationDecision.Approved,
            policy.decide(VoiceConfirmationAnswer.YES, "abc", "abc", 500L, 400L)
        )
    }

    @Test fun noRejects() {
        assertEquals(
            ConfirmationDecision.Rejected,
            policy.decide(VoiceConfirmationAnswer.NO, "abc", "abc", 500L, 400L)
        )
    }

    @Test fun unclearAsksAgainRatherThanApproving() {
        assert(policy.decide(VoiceConfirmationAnswer.UNCLEAR, "abc", "abc", 500L, 400L)
            is ConfirmationDecision.AskAgain)
    }

    @Test fun staleNonceCannotApprove() {
        assertEquals(
            ConfirmationDecision.Stale,
            policy.decide(VoiceConfirmationAnswer.YES, "new", "old", 500L, 400L)
        )
    }

    @Test fun expiredConfirmationCannotApprove() {
        assertEquals(
            ConfirmationDecision.Expired,
            policy.decide(VoiceConfirmationAnswer.YES, "abc", "abc", 500L, 500L)
        )
    }
}
