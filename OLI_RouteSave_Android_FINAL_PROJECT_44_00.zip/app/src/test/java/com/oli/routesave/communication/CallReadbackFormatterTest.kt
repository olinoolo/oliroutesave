package com.oli.routesave.communication

import org.junit.Assert.assertTrue
import org.junit.Test

class CallReadbackFormatterTest {
    @Test fun readbackNamesNumberChannelAndVideoMode() {
        val prompt = CallReadbackFormatter.format(
            CallRequest(
                CallDestination.PhoneNumber("+421903123456"),
                CallChannel.WHATSAPP,
                CallMode.VIDEO
            )
        )
        assertTrue(prompt.contains("+421903123456"))
        assertTrue(prompt.contains("videohovor"))
        assertTrue(prompt.contains("WhatsApp"))
    }
}
