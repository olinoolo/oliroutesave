package com.oli.routesave.communication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactSelectionPolicyTest {
    @Test fun asksWhenMoreThanOneContactMatches() {
        val a = ContactCandidate("1", "Peter", listOf(ContactPhoneNumber("mobile", "0903111111")))
        val b = ContactCandidate("2", "Peter", listOf(ContactPhoneNumber("work", "0903222222")))
        val result = ContactSelectionPolicy.select(ContactLookupOutcome.Found(listOf(a, b)))
        assertTrue(result is ContactSelectionOutcome.AskWhichContact)
    }

    @Test fun asksWhichNumberWhenContactHasMultipleNumbers() {
        val person = ContactCandidate(
            "1", "Branislav",
            listOf(ContactPhoneNumber("mobile", "0903111111"), ContactPhoneNumber("work", "0903222222"))
        )
        val result = ContactSelectionPolicy.select(ContactLookupOutcome.Found(listOf(person)))
        assertTrue(result is ContactSelectionOutcome.AskWhichNumber)
    }

    @Test fun permissionRequiredDoesNotPretendToSearch() {
        assertEquals(
            ContactSelectionOutcome.CannotProceed("Na vyhľadanie kontaktov je potrebné povoliť prístup ku kontaktom."),
            ContactSelectionPolicy.select(ContactLookupOutcome.PermissionRequired)
        )
    }
}
