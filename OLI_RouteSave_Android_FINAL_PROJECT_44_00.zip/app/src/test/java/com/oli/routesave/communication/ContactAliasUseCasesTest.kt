package com.oli.routesave.communication

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactAliasUseCasesTest {
    @Test fun savesAndListsAlias() = runBlocking {
        val repo = InMemoryContactAliasRepository()
        val useCases = ContactAliasUseCases(repo)
        val contact = ContactCandidate("42", "Jana Nováková", listOf(ContactPhoneNumber("mobile", "0903123456")))
        assertTrue(useCases.saveAlias(" Manželka ", contact) is ContactAliasUseCases.SaveResult.Saved)
        assertEquals("Manželka", useCases.listAliases().single().alias)
        assertEquals("42", useCases.listAliases().single().contactId)
    }
    @Test fun rejectsBlankAlias() = runBlocking {
        val useCases = ContactAliasUseCases(InMemoryContactAliasRepository())
        val contact = ContactCandidate("42", "Jana", emptyList())
        assertTrue(useCases.saveAlias(" ", contact) is ContactAliasUseCases.SaveResult.Rejected)
    }
    @Test fun deleteAliasRemovesIt() = runBlocking {
        val useCases = ContactAliasUseCases(InMemoryContactAliasRepository())
        useCases.saveAlias("manželka", ContactCandidate("42", "Jana", emptyList()))
        useCases.deleteAlias("MANŽELKA")
        assertTrue(useCases.listAliases().isEmpty())
    }
}
