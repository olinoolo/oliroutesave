package com.oli.routesave.ui

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DriveUiControllerTest {
    @Test fun drivingLifecycleWorks() {
        val c = DriveUiController()
        c.setAssistant("Niko", "Niko")
        c.setVehicle("Audi A6")
        c.setDestination("Praha")
        c.setRoute("3 h 20 min", 280.0)
        c.startDriving()
        c.setVoiceListening(true)

        val s = c.state()
        assertTrue(s.isDriving)
        assertTrue(s.voiceListening)
        assertEquals("Praha", s.destination)
        assertEquals(280.0, s.remainingKm)
    }

    @Test fun stoppingDriveStopsVoice() {
        val c = DriveUiController()
        c.startDriving()
        c.setVoiceListening(true)
        c.stopDriving()
        assertTrue(!c.state().isDriving)
        assertTrue(!c.state().voiceListening)
    }
}
