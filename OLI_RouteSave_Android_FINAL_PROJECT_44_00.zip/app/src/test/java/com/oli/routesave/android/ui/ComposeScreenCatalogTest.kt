package com.oli.routesave.android.ui

import kotlin.test.Test
import kotlin.test.assertTrue

class ComposeScreenCatalogTest {
    @Test fun homeShowsMapAndVoice() {
        assertTrue(ComposeScreenCatalog.home.showMap)
        assertTrue(ComposeScreenCatalog.home.showVoiceButton)
    }

    @Test fun driveShowsMap() {
        assertTrue(ComposeScreenCatalog.drive.showMap)
    }
}
