package com.oli.routesave.data.store

import com.oli.routesave.data.model.VehicleProfile
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class InMemoryVehicleStoreTest {

    @Test
    fun defaultVehicleIsUnique() {
        val store = InMemoryVehicleStore()
        store.save(VehicleProfile("1", "Auto 1", isDefault = true))
        store.save(VehicleProfile("2", "Auto 2", isDefault = true))

        assertTrue(!store.get("1")!!.isDefault)
        assertTrue(store.get("2")!!.isDefault)
        assertEquals("2", store.getDefault()!!.id)
    }
}
