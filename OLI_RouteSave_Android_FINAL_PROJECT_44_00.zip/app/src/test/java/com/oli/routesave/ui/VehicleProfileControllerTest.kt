package com.oli.routesave.ui
import com.oli.routesave.data.persistence.VehicleRepository
import com.oli.routesave.data.store.InMemoryVehicleStore
import kotlin.test.*
class VehicleProfileControllerTest{
 @Test fun savesConsumption(){val c=VehicleProfileController(VehicleRepository(InMemoryVehicleStore()));val v=c.save("1","Audi A6","Audi","A6","DIESEL",5.2,1.55,true);assertEquals(5.2,v.averageConsumptionL100Km)}
 @Test fun rejectsNegative(){val c=VehicleProfileController(VehicleRepository(InMemoryVehicleStore()));assertFailsWith<IllegalArgumentException>{c.save("1","Auto","","","DIESEL",-1,1.5,true)}}
}
