package com.oli.routesave.data.persistence
import com.oli.routesave.data.model.AppSettings
import kotlin.test.*
class SettingsRepositoryTest{
 @Test fun roundTrip(){val r=SettingsRepository(InMemoryKeyValueStore());val s=AppSettings(languageTag="ro-RO",truckModeEnabled=true);r.saveAppSettings(s);assertEquals(s,r.loadAppSettings())}
}
