package com.oli.routesave.communication

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ContactAliasStoreTest {
    @Test fun aliasesAreMatchedCaseInsensitively() = runBlocking {
        val store = InMemoryContactAliasStore()
        store.save(ContactAlias("Manželka", "contact-1", "Jana"))
        val result = store.find("  MANŽELKA ")
        assertNotNull(result)
        assertEquals("contact-1", result!!.contactId)
    }
}
