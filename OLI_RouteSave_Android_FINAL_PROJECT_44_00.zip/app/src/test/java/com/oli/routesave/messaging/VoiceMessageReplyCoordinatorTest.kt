package com.oli.routesave.messaging

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceMessageReplyCoordinatorTest {
    private class FakeProvider(var available: Boolean = true) : NotificationReplyProvider {
        var sent: PreparedMessageReply? = null
        override fun canReply(notificationKey: String) = available
        override fun sendConfirmedReply(reply: PreparedMessageReply): MessageReplyResult {
            sent = reply
            return MessageReplyResult.Sent
        }
    }

    @Test
    fun doesNotSendUntilConfirmed() {
        val provider = FakeProvider()
        val coordinator = VoiceMessageReplyCoordinator(provider)
        val prompt = coordinator.prepareReply("key", "com.example.chat", "Peter", "Prídem o pol hodiny")
        assertNotNull(prompt)
        assertEquals(null, provider.sent)
        coordinator.confirm(false)
        assertEquals(null, provider.sent)
        assertEquals(ReplyState.CANCELLED, coordinator.state)
    }

    @Test
    fun sendsOnlyAfterYes() {
        val provider = FakeProvider()
        val coordinator = VoiceMessageReplyCoordinator(provider)
        coordinator.prepareReply("key", "com.example.chat", "Peter", "Prídem o pol hodiny")
        val result = coordinator.confirm(true)
        assertEquals(MessageReplyResult.Sent, result)
        assertEquals("Prídem o pol hodiny", provider.sent?.text)
        assertEquals(ReplyState.SENT, coordinator.state)
    }

    @Test
    fun unavailableReplyActionDoesNotPretendToSend() {
        val provider = FakeProvider(available = false)
        val coordinator = VoiceMessageReplyCoordinator(provider)
        assertNull(coordinator.prepareReply("key", "com.example.chat", "Peter", "Ahoj"))
        assertEquals(ReplyState.UNAVAILABLE, coordinator.state)
    }
}
