# OLI RouteSave 18.0

Cumulative source package based on version 17.0.

## Main improvement
Settings and vehicle profiles can now be persisted locally with Android `SharedPreferences` adapters instead of relying solely on in-memory stores.

## New files
- `app/src/main/java/com/oli/routesave/voice/assistant/SharedPreferencesVoiceAssistantSettingsStore.kt`
- `app/src/main/java/com/oli/routesave/data/store/SharedPreferencesVehicleStore.kt`
- `docs/PERSISTENT_SETTINGS_AND_VEHICLES_18_00.md`

## Status
Source code only. No APK was built and the Android project was not compiled in this environment. The adapters still need integration into the app's startup and UI, followed by build and device tests.
