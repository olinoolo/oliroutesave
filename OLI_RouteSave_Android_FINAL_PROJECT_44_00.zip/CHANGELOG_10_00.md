# OLI RouteSave — 10.0

Large block: voice assistant foundation.
- Added canonical catalog of all seven requested assistant profiles and short invocation names.
- Added validated assistant/language settings model.
- Added a recognition-to-coordinator-to-speech session orchestration layer.
- Added clear yes/no voice confirmation handling for pending external actions.
- Added unit-test source and integration notes.
- Source-only; APK not compiled or device-tested.
