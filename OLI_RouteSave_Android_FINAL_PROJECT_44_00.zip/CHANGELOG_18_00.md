# OLI RouteSave — 18.0

- Added durable Android storage for voice assistant settings.
- Added durable Android storage for vehicle profiles, including consumption and fuel price.
- Added validation and default-vehicle handling to the persistence adapter.
- Added integration and privacy notes.
- No APK built; no Android compile/device test claimed.
