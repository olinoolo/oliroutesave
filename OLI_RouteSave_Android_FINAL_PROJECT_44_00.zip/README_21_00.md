# OLI RouteSave 21.0

Cumulative project package based on 20.0.

Main update: the Vehicle and Assistant destinations now contain Compose forms connected to local SharedPreferences repositories. The rest of the app still contains placeholders for map/live providers and several destinations.

No APK was generated and no Android build or device test was run in this environment.
