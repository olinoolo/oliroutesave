# OLI RouteSave 25.0

Cumulative Android source project based on version 24.0.

Adds a travel statistics screen with current-month, last-30-days, and all-time filters, showing saved trip count, distance, fuel use and cost breakdown. Access it from the More section.

This is source code, not an APK. Android compilation and device tests remain outstanding.
