# Voice UI integration — 8.70

The intended flow:
1. User activates the assistant button.
2. UI state changes to LISTENING.
3. A recognition result is passed to `VoiceAssistantUiBridge`.
4. The bridge maps the utterance to an assistant outcome.
5. UI displays the outcome and sends speech to an injected `AssistantSpeechOutput`.
6. If confirmation is required, UI displays/announces the exact action and waits.
7. A clear yes/no resolves only the pending action; a no cancels it.
8. The returned approved action is still not executed here; a phone/community service must execute it after permission and capability checks.

Never interpret a permission grant as consent to call or send a message.
