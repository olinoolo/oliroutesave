# OLI RouteSave 7.90 – Android Runtime Readiness
Added permission model, drive readiness checks, audio-focus priority, foreground-service policy, Android location lifecycle adapter, and Mapbox map/navigation adapters.
Emergency audio has higher priority than navigation guidance and voice assistant audio. Normal driving startup requires location permission.
Provider-specific Android, Mapbox, SpeechRecognizer, TTS and wake-word integrations remain behind interfaces. This is source architecture, not a compiled APK.
