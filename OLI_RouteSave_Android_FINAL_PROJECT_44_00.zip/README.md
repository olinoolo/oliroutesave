

## Version 42.0 — build environment diagnostics

Added `tools/check_build_environment.py` to report Java, Gradle, SDK, wrapper and required-file availability. It does not compile the app.


## Version 43.0 — cloud APK build

Added `.github/workflows/android-apk.yml` to attempt a debug APK build on GitHub Actions. The workflow has not been run; build success is not yet known.


## Version 44.0 — build diagnostics

GitHub Actions now uploads the build log/reports even on failure and uploads the APK only after a successful build.
