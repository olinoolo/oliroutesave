# OLI RouteSave 28.0
- Added train/bus search request and connection models.
- Added provider interface, validation, and explicit unavailable state.
- Added search UI under More → Vlaky a autobusy.
- Updated Android version metadata to 28.0 / versionCode 28.
- No APK built; no Android build/device test claimed.
