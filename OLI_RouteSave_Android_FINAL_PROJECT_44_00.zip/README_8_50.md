# OLI RouteSave — milestone 8.50: Voice provider integration foundation

## Added
- A voice input/output contract with clear listening states and callbacks.
- Android `SpeechRecognizer` adapter skeleton for single-turn recognition.
- Android `TextToSpeech` adapter with initialization, language selection, speaking, and shutdown lifecycle.
- Slovak-friendly voice command intent parser for common safe intents.
- A confirmation gate model for external actions: call, message, share location, community help request.
- Integration checklist and unit tests for parsing and confirmation decisions.

## Limitations
This is source code only, not a compiled APK. The adapters are not yet wired to the Compose UI or the central app runtime. Speech recognition requires Android's speech service and microphone permission; device/provider behavior varies. This module is not an always-listening wake-word engine and does not guarantee offline speech recognition.
