# Changelog 40.0

- Zvýšená verzia na 40.0.
- Odstránené duplicitné importy v hlavnej Compose obrazovke.
- Pridaný statický validačný skript `tools/validate_project.py`.
- Zdokumentované limity overenia: bez kompilácie APK.
