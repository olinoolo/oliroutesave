# Android integration checklist — 8.40

## 1. Compose Activity
Use `RouteSaveActivity` as the launcher Activity and call `setContent { RouteSaveComposeApp() }`.

## 2. Core runtime permissions
- Fine/coarse location: request when the user starts route planning or navigation.
- Microphone: request when the user explicitly activates voice interaction.
- Notifications: request if required by the target Android version and the foreground-drive notification is enabled.

## 3. Do not request everything at launch
Contacts, call-related permissions, SMS, background location, Bluetooth, and other sensitive permissions should be added only when the corresponding feature is implemented and the user initiates it. Explain the purpose before showing Android's permission prompt.

## 4. External actions
Calling, sending messages, publishing a help request, and sharing location must remain behind the selected voice assistant's explicit confirmation gate. A permission grant is not consent to perform a particular action.

## 5. Before producing APK
- Confirm Gradle wrapper and Android Gradle Plugin versions.
- Confirm Compose BOM / Material 3 / icons dependencies.
- Configure `namespace` and `applicationId` as `com.oli.routesave`.
- Set `minSdk` and `targetSdk` deliberately.
- Add app icon and official OLI RouteSave logo assets.
- Compile, run unit tests, install on a physical Android phone, and test denied/revoked permissions.
