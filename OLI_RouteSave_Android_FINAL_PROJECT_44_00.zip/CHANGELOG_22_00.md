# OLI RouteSave — 22.0

- Connected home vehicle card to saved vehicle repository.
- Added quick trip-cost calculator UI.
- Added distance, toll, parking and optional per-trip consumption inputs.
- Used existing calculator model to calculate fuel litres and total estimated cost.
- Added estimate/provider limitation notes.
- No Android build/device test claimed; no APK produced.
