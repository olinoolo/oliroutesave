# Changelog 37.0

- Pridaný stavový automat na bezpečné potvrdenie externých akcií.
- Pridaná obrazovka Potvrdenie hlasom s testovacími scenármi.
- Nejasné odpovede sa nepovažujú za súhlas; akcie sa nevykonávajú.
- Verzia zvýšená na 37.0.
