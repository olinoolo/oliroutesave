# OLI RouteSave 9.30 — konkrétne Android adaptéry

## Implementované v zdrojovom kóde
- `AndroidContactsGatewayImpl`: vyhľadávanie telefónnych kontaktov cez `ContactsContract`, iba ak má aplikácia povolenie `READ_CONTACTS`.
- `AndroidPhoneCallLauncher`: otvára systémový dialer cez `ACTION_DIAL` ako bezpečnejšiu predvolenú možnosť.
- Priamy `ACTION_CALL` je oddelený režim a vyžaduje už udelené runtime povolenie `CALL_PHONE` a výslovné potvrdenie.
- Chyby oprávnení a chýbajúca telefonická aplikácia sa vracajú ako výsledky, nie ako falošný úspech.

## Pred použitím
1. Android UI musí používateľovi zrozumiteľne vysvetliť, prečo potrebuje prístup ku kontaktom.
2. `READ_CONTACTS` treba požiadať cez runtime permission flow.
3. Pre bezpečnejšie používanie je odporúčaný `OPEN_DIALER`; používateľ ešte vidí číslo v systémovom dialeri.
4. Priamy hovor nesmie byť volaný z hlasového toku, kým nie je overené jasné potvrdenie ku konkrétnemu príjemcovi a číslu.
5. Treba zostaviť projekt s Android SDK a otestovať na reálnom zariadení.

## Obmedzenia
- Android adaptéry sú pridané do zdrojového projektu, ale v tomto prostredí neboli skompilované ani otestované na telefóne.
- Vyhľadávanie je podľa mena v indexe telefónnych kontaktov; aliasy ako „manželka“ či „brat“ ešte vyžadujú používateľom nastavené aliasy alebo samostatnú mapu vzťahov.
- Tieto adaptéry nespúšťajú WhatsApp ani Messenger. Tie potrebujú samostatné, overené integračné adaptéry.
