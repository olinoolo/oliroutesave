# OLI RouteSave 16.0 — static source compatibility audit

## Scope
This milestone performs a static review of the source tree and build scaffold from 15.0, adds a repeatable checklist, and records likely compatibility risks. No Android SDK/Gradle compiler was run here, so findings are not equivalent to a successful build.

## Project configuration reviewed
- Root Gradle settings and plugin versions
- App module SDK and Java/Kotlin targets
- Android manifest and declared permissions
- Source imports and use of Android-only APIs in unit-testable classes
- Presence of Gradle wrapper files

## Key build-preparation findings
1. The project did not include a Gradle wrapper in the prior archive. A compatible Gradle installation or wrapper generation is needed before reproducible builds.
2. Android-only implementations use `android.*` APIs and `org.json`; keep those adapters out of plain JVM unit tests unless Android test runtime/Robolectric is configured.
3. Kotlin source uses language/library features such as `data object`, `buildList` and `Enum.entries`; the Kotlin plugin must be new enough to support them. The scaffold uses Kotlin 2.0.21.
4. `AndroidManifest.xml` declares permissions, but runtime permission requests still must be implemented in app code. Manifest declarations alone do not grant access.
5. Source modules include interfaces and model layers for live data providers; those do not create live routing, ticket search, rest-stop data, messaging, or community backend by themselves.
6. Build configuration and static inspection do not prove that all source files compile. The first Android Studio Gradle sync/build is still required.

## Recommended first build loop
1. Extract the ZIP into a clean folder.
2. Open the folder containing `settings.gradle.kts` in Android Studio.
3. Use JDK 17 and install Android SDK Platform 35 when prompted.
4. Let Gradle sync, then run `:app:assembleDebug`.
5. Fix compiler errors one at a time; do not assume a release-ready APK until the build succeeds.
6. Run `:app:testDebugUnitTest`.
7. Install the debug APK on a test device and test startup, permissions, and safety confirmations.

## Testability separation rule
- Pure models/calculations/state machines should be unit-tested on the JVM.
- Android adapters (ContactsContract, SharedPreferences, TextToSpeech, SpeechRecognizer, notification listener, intents) should be verified through Android instrumentation tests or a configured Robolectric environment.
- Live API provider tests should use fake providers in unit tests and real sandbox credentials only in integration tests.

## Release status
Static audit and documentation only. No APK was produced. No compile or device test has been claimed.
