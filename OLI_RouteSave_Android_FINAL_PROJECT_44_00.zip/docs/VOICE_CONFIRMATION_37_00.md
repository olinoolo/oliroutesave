# OLI RouteSave 37.0 — Bezpečný tok potvrdenia

## Pridané
- `VoiceConfirmationCoordinator`: stavový automat pre otázku, čakanie na odpoveď, jasné potvrdenie, odmietnutie a nejednoznačnú odpoveď.
- Nová obrazovka **Potvrdenie hlasom** v menu **Viac**.
- Testovacie scenáre pre telefonát, zdieľanie polohy a nákup lístka.
- Ukážkový vstup „áno/nie“ a simulácia nízkej istoty rozpoznania.
- Verzia zvýšená na 37.0.

## Bezpečnostné správanie
- Akcia sa nikdy nevykoná týmto stavovým automatom.
- Jasné „nie“ čakajúcu akciu zruší.
- Nejednoznačná odpoveď alebo nízka istota necháva akciu nevykonanú a žiada spresnenie.
- Potvrdenie iba označí akciu ako potvrdenú; samostatná integračná vrstva musí vykonať ďalší krok.

## Obmedzenia
Táto obrazovka je testovacia ukážka a jej odpoveď sa zadáva textovo. Nie je ešte napojená na živé rozpoznávanie reči z mikrofónu. Telefonovanie, SMS, zdieľanie polohy, rezervácie a nákupy sa nevykonávajú.

## Stav zostavenia
Zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
