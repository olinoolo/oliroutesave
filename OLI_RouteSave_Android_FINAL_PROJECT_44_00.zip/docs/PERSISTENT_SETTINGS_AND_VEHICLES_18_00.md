# OLI RouteSave 18.0 — persistent voice settings and vehicle profiles

## What is new
- `SharedPreferencesVoiceAssistantSettingsStore` persists selected assistant, language, hands-free preference, optional wake-word preference, concise responses, and romantic-mode preference.
- `SharedPreferencesVehicleStore` persists vehicle profile fields, including average fuel consumption and fuel price.
- Vehicle storage validates IDs, names, consumption, and fuel price before saving.
- Setting a vehicle as default clears the default flag from the other stored profiles.
- Corrupt or invalid vehicle records are skipped when reading, rather than crashing the entire list.

## Integration
These are Android-backed adapters for existing interfaces. The host app must construct them with an Android `Context`, then pass them to the existing managers/repositories. They do not automatically wire themselves into a screen or application startup.

Example:
```kotlin
val voiceStore = SharedPreferencesVoiceAssistantSettingsStore(applicationContext)
val voiceSettings = VoiceAssistantSettingsManager(voiceStore)

val vehicleStore = SharedPreferencesVehicleStore(applicationContext)
val vehicleRepository = VehicleRepository(vehicleStore)
```

## Privacy and limitations
- Data is stored in app-private SharedPreferences, not encrypted by this adapter.
- Voice recordings and transcripts are not stored by the settings adapter.
- Vehicle profiles are local to this installation and are not synced between devices.
- For stronger data modelling, migrations, and larger datasets, use Room.
- No Android compilation or device test was performed during packaging.
