# OLI RouteSave 35.0 — Most medzi Android hlasom a koordinátorom

## Pridané
- `AndroidVoiceSession`, ktorý spája Android `SpeechRecognizer` a `TextToSpeech` z verzie 33.0 s `VoiceInteractionCoordinator` z verzie 34.0.
- Stav rozpoznávania a odpovede sa posiela cez callback `onStateChanged`.
- Pred spustením rozpoznávania kontroluje dostupnosť mikrofónneho povolenia.
- Rozpoznaný finálny text sa pošle koordinátoru; odpoveď sa prehrá cez TTS.
- Metódy na začatie/zastavenie počúvania, zastavenie hovorenia a uvoľnenie zdrojov.
- Verzia zvýšená na 35.0.

## Dôležité hranice
Tento most je pripravený ako samostatná trieda, ale ešte nie je pripojený k hlavnej Compose obrazovke a aplikácia zatiaľ nemá hotové tlačidlo mikrofónu s runtime žiadosťou o povolenie. Používateľské rozhranie musí pred `startListening()` vyžiadať `RECORD_AUDIO` cez Android runtime permission API a po zatvorení obrazovky zavolať `close()`.

- Nie je implementované nepretržité počúvanie ani wake-word.
- Počúvanie sa spúšťa len výslovným volaním metódy.
- Trieda nevykonáva hovory, SMS, zdieľanie polohy, rezervácie ani nákupy.
- Akcia s externým účinkom ostáva iba čakajúcou akciou; samostatná bezpečná integračná vrstva by ju musela vykonať po potvrdení.

## Stav zostavenia
Ide o zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
