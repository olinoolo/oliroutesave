# OLI RouteSave 31.0 — Hlasový spolujazdec

## Čo pribudlo
- Nový zdrojový modul `voice/VoiceAssistantModels.kt`.
- Modely hlasových príkazov, zámerov, rizík a čakajúcej externej akcie.
- Oslovenia vybraných asistentov:
  - Marek → „Marek“
  - Branislav → „Brandži“
  - Nikolas → „Niko“
  - Tanya → „Tanya“
  - Vanesa → „Vany“
  - Natália → „Naty“
  - Kateřina → „Kateřina“
- Základná politika vyžadujúca výslovné potvrdenie pri telefonáte, správe, zdieľaní polohy, otvorení rezervácie a nákupe lístka.
- Nová obrazovka **Hlasový spolujazdec** s výberom asistenta a ukážkovým textovým príkazom.
- Verzia zvýšená na 31.0.

## Čo ešte nefunguje ako skutočná hlasová funkcia
Táto verzia zatiaľ nepripája mikrofón, nepretržité počúvanie, Android SpeechRecognizer, prevod textu na reč (TTS), telefonovanie, SMS ani GPS. Obrazovka je prototyp textového spracovania a konfigurácie pravidiel, nie hotový hlasový asistent. Externé akcie sa nevykonávajú.

## Potvrdenie akcií
Povolenie mikrofónu ani rozpoznaný príkaz nie sú súhlasom s externou akciou. Pred telefonátom, odoslaním správy, zdieľaním polohy, otvorením rezervácie či nákupom musí zvolený asistent požiadať o jasné potvrdenie. Nejasná odpoveď sa nesmie považovať za súhlas.

## Stav zostavenia
Ide o zdrojový Android projekt. APK nebolo vytvorené; Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
