# OLI RouteSave 30.0 — Plánovanie cesty a bezpečné potvrdenie akcií

## Veľký blok 30.0
Táto verzia nadväzuje na obrazovku „Inteligentné pokračovanie cesty“ z verzie 29.0.

### Pridané v zdrojovom projekte
- Pomocná trieda `JourneyPlanRanker`, ktorá zoradí plány dodané nakonfigurovaným poskytovateľom podľa:
  - najnižšej ceny,
  - najkratšieho trvania,
  - najmenšieho počtu prestupov,
  - najskoršieho príchodu.
- Neplatné plány sa pri zoradení vynechajú; chýbajúce údaje sa nepovažujú za výhodnejšie než známe údaje.
- `ExternalActionGuard` a typy akcií pre budúce potvrdenie otvorenia rezervácie, odoslania správy, zdieľania polohy, telefonátu a nákupu lístka.
- Verzia zvýšená na 30.0.

## Dôležité hranice
- Reálne cestovné poriadky, lety, ceny, dostupnosť a rezervácie nie sú pripojené.
- Zoraďovanie funguje len nad plánmi, ktoré v budúcnosti vráti skutočný poskytovateľ; táto verzia nevytvára falošné spoje.
- `ExternalActionGuard` je základná pomocná logika, nie úplná hlasová integrácia. Samotné telefonovanie, SMS, GPS, hlasové rozpoznávanie a nákup lístkov ešte nie sú týmto blokom implementované.
- GPS sa bez výslovného povolenia nepoužíva a v aktuálnej obrazovke sa miesto zadáva ručne.
- Každá budúca externá akcia má vyžadovať jasné potvrdenie od používateľa cez aktuálne zvoleného hlasového asistenta.

## Stav zostavenia
Ide o zdrojový Android projekt. APK nebolo vytvorené; zostavenie Gradle ani testovanie na zariadení nebolo vykonané v tomto prostredí.
