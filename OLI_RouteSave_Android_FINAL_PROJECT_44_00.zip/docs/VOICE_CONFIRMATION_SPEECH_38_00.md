# OLI RouteSave 38.0 — Hlasová odpoveď na potvrdenie

## Pridané
- `AndroidVoiceConfirmationSession` prepája `AndroidSpeechInput`, `AndroidSpeechOutput` a `VoiceConfirmationCoordinator`.
- Obrazovka **Potvrdenie hlasom** teraz obsahuje tlačidlo **Odpovedať hlasom**.
- Pri prvom použití sa zobrazí runtime žiadosť o povolenie mikrofónu.
- Rozpoznaná odpoveď sa vyhodnotí ako potvrdenie, odmietnutie alebo potreba spresnenia.
- Pri nejasnej odpovedi asistent hlasovo požiada o jasné „áno“ alebo „nie“.
- Textový vstup zostáva ako záložná testovacia možnosť.
- Verzia zvýšená na 38.0.

## Bezpečnostné hranice
- Táto integrácia spracúva len odpoveď na potvrdenie; nevykonáva telefonát, SMS, zdieľanie polohy, rezerváciu ani nákup.
- Po potvrdení sa akcia iba označí ako potvrdená. Vykonávacia vrstva ešte nie je pripojená.
- Rozpoznanie reči môže mať chyby; používateľ musí skontrolovať zobrazený stav. Pri chybe zostáva akcia nevykonaná.
- Mikrofón sa spustí len po stlačení tlačidla a udelení povolenia; žiadne nepretržité počúvanie.

## Stav zostavenia
Zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
