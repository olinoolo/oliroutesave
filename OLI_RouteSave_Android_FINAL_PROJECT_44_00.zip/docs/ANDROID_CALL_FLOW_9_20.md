# OLI RouteSave 9.20 — hlasový tok pre kontakt a číslo

## Pridané
- Parser nadiktovaného čísla, ktorý číslo iba pripraví na prečítanie a kontrolu.
- Hlasový súhrn hovoru: príjemca/číslo, kanál a hlasový alebo video režim.
- Jednoduchá vrstva, ktorá vracia otázky pre hlasové rozhranie alebo požiadavku na vyhľadanie kontaktu.
- Testy pre formátovanie čísla, neúplné rozpoznanie a hlasové prečítanie hovoru.

## Zamýšľaný tok
1. Používateľ povie príkaz.
2. Aplikácia rozlíši kontakt od nadiktovaného čísla.
3. Pri čísle ho očistí a pripraví na hlasové zopakovanie; neodhaduje predvoľbu krajiny.
4. Pri kontakte požiada Android kontaktný adaptér o kandidátov; viac zhôd sa musí vyjasniť.
5. Asistent zopakuje príjemcu, kanál a režim hovoru.
6. Len po jasnom a stále platnom potvrdení sa môže vyvolať konkrétny poskytovateľ.
7. Ak integrácia nie je dostupná, asistent oznámi obmedzenie.

## Stav implementácie
Toto je zdrojový základ pre tok a texty, nie skutočné napojenie na `ContactsContract`, Android `Intent` alebo WhatsApp/Messenger API. Nejde o skompilovanú APK ani o overenú funkciu na telefóne.
