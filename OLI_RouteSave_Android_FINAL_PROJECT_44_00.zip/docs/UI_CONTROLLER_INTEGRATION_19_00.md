# OLI RouteSave 19.0 — UI-facing controllers

## Added
- `VehicleProfileFormState`: safe text-first form model for vehicle entry, accepting comma or dot decimal separators.
- `VehicleProfileScreenController`: loads, saves, and deletes vehicle profiles through the existing repository and returns explicit success/validation results.
- `VoiceAssistantSettingsController`: exposes assistant choices and settings operations to a UI layer.

## How to integrate
Construct the controllers from the app's composition/root layer:
```kotlin
val vehicleStore = SharedPreferencesVehicleStore(applicationContext)
val vehicleRepository = VehicleRepository(vehicleStore)
val vehicleController = VehicleProfileScreenController(vehicleRepository)

val settingsStore = SharedPreferencesVoiceAssistantSettingsStore(applicationContext)
val settingsManager = VoiceAssistantSettingsManager(settingsStore)
val settingsController = VoiceAssistantSettingsController(settingsManager)
```

A screen can call `vehicleController.save(formState)` and display errors from `VehicleSaveResult.Invalid`. A Compose UI still needs to be written and connected to app navigation; these controller classes do not create screens on their own.

## Notes
- Decimal comma input is normalized before parsing.
- Consumption is validated between 0 and 100 l/100 km.
- Fuel price is validated between 0 and 20 per litre.
- Supported fuel types are PETROL, DIESEL, LPG, CNG, ELECTRIC, and HYBRID.
- No Android build or device test was run during packaging.
