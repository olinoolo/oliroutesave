# OLI RouteSave 8.90 — hlasové hovory a videohovory

## Pridaná zdrojová architektúra
- Model hovoru: bežný telefón, WhatsApp alebo Messenger; hlasový hovor alebo videohovor.
- Cieľ hovoru môže byť uložený kontakt alebo nadiktované telefónne číslo mimo kontaktov.
- Rozhranie na vyhľadanie kontaktu a normalizáciu čísla.
- Rozhranie poskytovateľa na kontrolu schopností, prípravu hovoru a spustenie až po potvrdení.
- Koordinátor, ktorý vytvorí presnú hlasovú otázku a nepovolí spustenie pred jasným potvrdením.
- Základný parser príkazov a testy pre WhatsApp videohovor, Messenger hovor a ned uložené číslo.

## Čo ešte nie je hotové
Toto je zdrojový základ, nie hotová integrácia ani APK. Konkrétne Android adaptéry pre telefón, WhatsApp a Messenger ešte treba napojiť a overiť na zariadení. Dostupnosť spustenia hlasového hovoru/videohovoru sa líši podľa verzie aplikácie, Androidu, nainštalovanej aplikácie a podporovaných verejných rozhraní. Kód preto nesmie predstierať úspech, ak poskytovateľ reálne nepotvrdí spustenie.

## Bezpečnostné pravidlá
1. Asistent zopakuje cieľ, kanál a typ hovoru.
2. Hovor sa spustí len po jasnom potvrdení používateľa.
3. Nejednoznačný kontakt alebo číslo treba najprv vyjasniť.
4. Ak kanál alebo videohovor nie je dostupný, asistent to povie.
5. Počas jazdy sa nesmie vyžadovať manipulácia s telefónom; ak je potrebný dotyk alebo nebezpečný krok, odloží sa do bezpečného zastavenia.
