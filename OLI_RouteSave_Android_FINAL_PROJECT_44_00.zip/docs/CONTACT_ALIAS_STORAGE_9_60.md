# Contact alias storage — milestone 9.60

## What changed
- Added `SharedPreferencesContactAliasRepository`, an Android storage adapter for the existing `ContactAliasRepository` contract.
- Aliases survive ordinary app restarts because they are saved in app-private `SharedPreferences`.
- Alias lookup normalizes case and repeated whitespace.
- Malformed stored entries are skipped instead of crashing the alias list.
- The repository stores only the alias, contact ID and display name. It does not copy phone numbers into alias storage.

## Integration notes
Create the repository with an Android `Context`, preferably from the application context:

```kotlin
val aliasRepository = SharedPreferencesContactAliasRepository(applicationContext)
```

Use the existing `ContactAliasUseCases` / `VoiceCallResolutionService` wiring to provide this repository wherever the in-memory implementation was previously supplied.

## Privacy and safety
- This is app-private storage, not encrypted storage.
- The repository does not request contact permissions; those are needed separately by the contacts gateway.
- Persisting an alias does not authorize a call. Existing voice-call confirmation rules must still require clear user confirmation before launching an external call.
- This is source code only. It has not been compiled or tested on a device in this environment.
