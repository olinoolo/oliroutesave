# OLI RouteSave 27.0 — travel mode comparison

## Added
- Comparison service for car, train, bus, and plane.
- Car estimate includes fuel based on distance, consumption and fuel price, plus toll and parking.
- Train, bus, and plane ticket costs can be entered manually, with optional additional costs.
- Comparison UI accessible from More → Porovnať spôsob dopravy.
- The UI explicitly labels results as estimates and does not claim live provider prices.

## Limits
- No live ticket search, route duration or provider integration.
- Train/bus/plane prices must be entered by the user.
- Car estimate excludes depreciation, insurance, maintenance, and any unspecified costs.
- No APK built; Android compilation/device testing not performed.
