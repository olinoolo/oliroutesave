# OLI RouteSave 36.0 — Obrazovka ovládania hlasom

## Pridané
- Nová obrazovka **Ovládanie hlasom** dostupná z menu **Viac**.
- UI používa `AndroidVoiceSession` a `VoiceInteractionCoordinator`.
- Tlačidlo na začatie počúvania a runtime žiadosť o povolenie mikrofónu.
- Tlačidlo na zastavenie počúvania a zastavenie hovoreného výstupu.
- Zobrazenie stavu, rozpoznaného textu a odpovede asistenta.
- Zobrazenie informácie, keď koordinátor čaká na potvrdenie externej akcie.
- Verzia zvýšená na 36.0.

## Obmedzenia
- Nie je implementované nepretržité počúvanie ani wake-word.
- Klasifikácia príkazov je zatiaľ jednoduchá a môže sa pomýliť; nejde o plnohodnotné NLU.
- Externé akcie (hovor, SMS, GPS, rezervácia, nákup) sa nevykonávajú.
- Pred potvrdením externých akcií treba doplniť samostatné UI/hlasový tok, ktorý zaznamená odpoveď používateľa a až potom dovolí ďalšiu integračnú vrstvu.
- Skutočná dostupnosť slovenčiny a hlasu závisí od zariadenia a nainštalovaných služieb.

## Stav zostavenia
Zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
