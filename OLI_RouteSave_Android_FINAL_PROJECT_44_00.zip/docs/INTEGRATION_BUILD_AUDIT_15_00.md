# OLI RouteSave 15.0 — integration and build-preparation audit

## Added in this block
- Android Gradle project scaffold: `settings.gradle.kts`, root `build.gradle.kts`, `app/build.gradle.kts`, and `gradle.properties`.
- Real `app/src/main/AndroidManifest.xml` generated from the existing manifest template.
- Declared `READ_CONTACTS` because contact lookup code exists in the source. Runtime permission request UI is still required.
- Added Compose, Material 3, extended icons, Android activity, coroutines and unit-test dependencies.
- Added this integration/build-readiness report.

## Important limitations found
- A Gradle wrapper (`gradlew`, `gradlew.bat`, wrapper JAR/properties) is not included. Open the project in Android Studio with a compatible Gradle installation or generate a wrapper there.
- No Android SDK/Gradle build was executed in this environment, so this scaffold is not proof that the project compiles.
- The app contains many architectural modules and provider interfaces. Several features are not connected to live backends or Android UI flows.
- Runtime permission prompts for microphone, location, contacts and notifications still need to be implemented in the UI.
- Location search, route calculation, live fuel/toll/parking prices, live train/bus/flight search, community backend, real media providers and WhatsApp/Messenger launch providers are not configured by this scaffold.
- Vehicle and settings repositories in the current dependency graph are in-memory placeholders and do not persist across restarts.
- Always-on wake-word listening is not implemented.
- Some source files may reveal compiler/API issues during the first real Android Studio build; resolve those before creating a release APK.

## Open in Android Studio
1. Extract the ZIP into a new folder.
2. Open that folder in Android Studio (not the `app` subfolder).
3. Install Android SDK Platform 35 and a compatible Android SDK Build Tools version when prompted.
4. Use JDK 17 for Gradle.
5. Allow Gradle sync to finish.
6. Run `app` on an emulator or a physical Android device.
7. Fix any compile errors reported by the first build before treating the app as testable.
8. For unit tests, run the `test` task after Gradle sync succeeds.

## Suggested first verification checklist
- App opens to the Compose screen without crashing.
- Assistant selection and language settings remain valid.
- Call/message/location actions cannot run without explicit confirmation.
- Contacts and microphone permissions are requested at the moment the feature is used.
- Fuel estimate uses vehicle consumption or a per-trip override.
- Community help stays local until confirmation and is not published without a backend.
- Missing live-data providers are shown as unavailable rather than displaying invented prices.

## Release status
This is a source-only project scaffold. It has not been compiled, unit-tested, signed, or tested on a physical Android device in this environment. Do not distribute as a production APK yet.
