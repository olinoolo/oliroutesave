# OLI RouteSave 42.0 — diagnostika pred zostavením APK

## Nové v 42.0
- Pridaný `tools/check_build_environment.py`, ktorý vypíše dostupnosť Javy, Gradle, Android SDK, wrappera a povinných súborov projektu.
- Verzia aplikácie zvýšená na 42.0.

## Použitie
V koreňovom priečinku projektu:
```bash
python3 tools/check_build_environment.py
```
Na Windows:
```powershell
py tools/check_build_environment.py
```

Tento skript **nič neinštaluje, nič nekompiluje a nemení nastavenia telefónu**. Iba vypíše, čo je na počítači dostupné.

## Realistický postup k APK
1. Rozbaľ ZIP do samostatného priečinka.
2. Otvor koreňový priečinok projektu v Android Studio.
3. Ak Android Studio ponúkne inštaláciu SDK alebo synchronizáciu Gradle, dokonči ju.
4. Spusti kontrolu prostredia.
5. Spusti `tools/build_debug_apk.ps1` vo Windows alebo `bash tools/build_debug_apk.sh` na Linux/macOS.
6. Ak build zlyhá, skopíruj sem celý prvý blok chyby z Build Output; podľa neho sa bude opravovať konkrétny problém.

## Stav overenia
V prostredí vytvárania tohto ZIP-u nebol dostupný Gradle ani Android SDK, preto APK nebolo vytvorené. Projekt nebol skompilovaný a nie je možné tvrdiť, že build prechádza.
