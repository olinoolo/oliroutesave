# OLI RouteSave 44.0 — výsledok zostavenia a diagnostika

## Čo pribudlo
- GitHub Actions workflow po neúspešnom zostavení uloží dostupný `build-log.txt` a reporty ako samostatný artefakt `OLI-RouteSave-build-diagnostics`.
- APK sa nahrá ako artefakt iba vtedy, keď build úspešne skončí.
- Verzia aplikácie je 44.0.

## Postup z Android telefónu
1. Otvor GitHub repozitár v prehliadači.
2. Skontroluj, či sú projektové súbory v koreňovom priečinku repozitára (`settings.gradle.kts`, `build.gradle.kts`, `app/`), a nie iba zabalené v ZIP súbore.
3. Uisti sa, že súbor `.github/workflows/android-apk.yml` je uložený v repozitári.
4. Otvor kartu **Actions** a vyber **Build OLI RouteSave APK**.
5. Spusti **Run workflow**.
6. Po skončení:
   - ak je beh úspešný, stiahni artefakt `OLI-RouteSave-debug-APK`;
   - ak zlyhá, stiahni `OLI-RouteSave-build-diagnostics` a pošli sem obsah `build-log.txt` alebo snímku prvej červenej chyby.

## Dôležité
Tento ZIP nebol zostavený v tomto prostredí. Pridanie diagnostického artefaktu iba uľahčuje zistenie príčiny, ak cloudový build zlyhá; nezaručuje, že build prejde.
