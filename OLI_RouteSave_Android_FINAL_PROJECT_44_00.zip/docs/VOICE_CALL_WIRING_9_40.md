# OLI RouteSave 9.40 — spojenie hlasových príkazov s kontaktmi

## Pridané
- `VoiceCallCommandHandler`: spracuje výsledok rozpoznania hlasu a rozhodne, či treba vyhľadať kontakt, skontrolovať nadiktované číslo alebo požiadať o spresnenie.
- `ContactAliasStore`: základ na vlastné pomenovania kontaktov, napríklad „manželka“ alebo „brat“.
- `VoiceCallResolutionService`: najprv hľadá používateľom definovaný alias a potom vyhľadá meno v Android kontaktoch.
- Testy príkazov a aliasov.

## Bezpečnostný tok
1. Rozpoznaj hlasový príkaz.
2. Rozlíš kontakt/alias od telefónneho čísla.
3. Vyhľadaj kandidátov; ak je viac zhôd, spýtaj sa.
4. Zopakuj príjemcu, kanál a režim hovoru.
5. Čakaj na výslovné potvrdenie.
6. Až potom odovzdaj požiadavku adaptéru hovoru.

## Obmedzenia
Toto ešte nie je kompletné zapojenie do UI ani zostavená APK. Android Contacts adapter existuje v zdrojovom kóde od 9.30, ale potrebuje runtime permission UI a testovanie. Alias store je zatiaľ iba v pamäti a po zatvorení aplikácie sa jeho obsah stratí; pre produkciu ho treba napojiť na trvalé úložisko. WhatsApp/Messenger call launchery ešte nie sú implementované.
