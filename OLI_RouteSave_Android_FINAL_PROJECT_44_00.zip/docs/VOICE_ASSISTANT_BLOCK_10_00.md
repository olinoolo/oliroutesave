# OLI RouteSave 10.0 — Voice assistant foundation

## Included
- One canonical catalog of the seven requested built-in assistants: Marek, Branislav/Brandži, Nikolas/Niko, Tanya, Vanesa/Vany, Natália/Naty and Kateřina.
- A settings model for selected assistant, language, hands-free preference, optional wake-word preference, concise responses and opt-in romantic mode.
- Settings validation for the requested language set: Slovak, Czech, English, German, Polish, Hungarian and Romanian.
- A session coordinator that connects voice recognition, the existing assistant command coordinator and speech output.
- Spoken external-action confirmation: only clear yes/no responses are accepted; unclear responses leave the action pending and do not approve it.
- Unit-test source for catalog lookup and settings validation.

## Important implementation boundaries
- `InMemoryVoiceAssistantSettingsStore` is a temporary store for logic/testing. Persistent preferences UI/storage still needs to be wired into the Android app.
- The session coordinator is not an always-on wake-word detector. Android microphone permissions, foreground/lifecycle handling and explicit start/stop UI must be connected by the host app.
- External actions are surfaced as outcomes for the host app. This coordinator does not directly launch calls, send messages or share location.
- A granted Android permission does not count as confirmation for an external action.
- The project is a source ZIP. It has not been compiled or tested on a physical device in this environment.
