# OLI RouteSave 21.0 — real screens connected to local storage

## Implemented in source
- Replaced the placeholder Vehicle and Assistant detail destinations with actual Jetpack Compose forms.
- Vehicle screen loads stored profiles, edits fields, validates consumption and fuel price, saves locally, and lists saved vehicles.
- Assistant screen loads current preferences, lets the user select among the seven built-in assistants, select one of seven supported languages, and persist hands-free, optional wake-word, concise response, and romantic-mode preferences.
- The app uses the SharedPreferences adapters introduced in 18.0.

## Safety
- The hands-free switch is a preference only; it does not start the microphone.
- Enabling optional wake-word does not implement an always-on detector.
- External actions still require a separate explicit confirmation flow.
- This screen does not perform phone calls, send messages, or share location.

## Build status
This is a source-code change only. Android compilation and physical-device testing have not been performed. Please run Gradle sync and `:app:assembleDebug` in Android Studio; address any compile errors from actual build output.
