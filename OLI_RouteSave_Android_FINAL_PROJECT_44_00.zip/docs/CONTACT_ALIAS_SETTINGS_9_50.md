# OLI RouteSave 9.50 — správa vlastných pomenovaní kontaktov

## Pridané
- Repository rozhranie pre aliasy kontaktov a testovacia in-memory implementácia.
- Use cases na pridanie, zobrazenie a odstránenie pomenovania.
- Kontrola prázdneho a príliš dlhého pomenovania.
- Text vysvetľujúci ochranu súkromia.

## Zamýšľané používanie
Používateľ vyberie kontakt a priradí mu pomenovanie, napríklad „manželka“, „brat“ alebo „servis“. Aplikácia nebude vzťahy odhadovať sama.

## Stav
In-memory implementácia je iba na testy/ukážky. Trvalé úložisko (napríklad Room alebo DataStore) a používateľské rozhranie ešte treba napojiť. APK nie je zostavená.
