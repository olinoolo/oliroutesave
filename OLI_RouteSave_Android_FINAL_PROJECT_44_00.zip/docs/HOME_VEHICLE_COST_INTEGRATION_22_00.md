# OLI RouteSave 22.0 — saved vehicle on home screen and trip cost estimate

## Added
- The home screen reads the saved default vehicle instead of showing hard-coded Audi details.
- If no default vehicle exists, the user sees a prompt to add one.
- Added a quick trip cost estimate with distance, optional trip-specific consumption override, toll and parking.
- The calculator is embedded directly under the vehicle card and uses the existing `TripCostCalculator`.
- The estimate uses saved vehicle consumption and fuel price; a per-trip consumption override can replace the profile consumption.
- Inputs accept decimal commas and dots; invalid or out-of-range values are rejected by the calculator.

## Important
- The displayed value is an estimate, not a live fuel/toll/parking quote.
- This does not add live routing, fuel prices, toll provider data or map APIs.
- No Android compilation or device test was performed in this environment.
