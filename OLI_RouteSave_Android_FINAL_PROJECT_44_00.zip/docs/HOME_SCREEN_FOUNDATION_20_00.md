# OLI RouteSave 20.0 — základ hlavnej obrazovky

## Pridané
- `RouteSaveHomeUiState`: dátový model pre hlavnú obrazovku.
- `RouteSaveHomeController`: spravuje trasu, aktívnu sekciu, hlasový stav, predvolené vozidlo a text odhadu.
- `RouteSaveScreenCatalog`: jednotný katalóg piatich hlavných sekcií: Domov, Vozidlo, Hlasový asistent, Porovnanie dopravy a Komunitná pomoc.

## Dôležité hranice
Toto je základ pre používateľské rozhranie, nie hotová grafická Compose obrazovka. Controller je zatiaľ framework-independent a musí sa zapojiť do Activity/Compose vrstvy. Text hlasového stavu neznamená, že mikrofón počúva; reálne spustenie hlasovej služby, runtime oprávnenia a UI stav sa musia doplniť samostatne.

## Pripojenie
```kotlin
val vehicleStore = SharedPreferencesVehicleStore(applicationContext)
val vehicleRepository = VehicleRepository(vehicleStore)
val settingsStore = SharedPreferencesVoiceAssistantSettingsStore(applicationContext)
val settingsManager = VoiceAssistantSettingsManager(settingsStore)
val settingsController = VoiceAssistantSettingsController(settingsManager)
val homeController = RouteSaveHomeController(vehicleRepository, settingsController)
val initialState = homeController.refresh()
```

## Čo ešte chýba
- Skutočné Compose obrazovky a navigácia.
- Logo a grafické prvky v Android resources.
- Integrácia do launcher Activity.
- Gradle wrapper, kompilácia a testovanie na telefóne.
- Živé mapy, trasy a externé ceny.
