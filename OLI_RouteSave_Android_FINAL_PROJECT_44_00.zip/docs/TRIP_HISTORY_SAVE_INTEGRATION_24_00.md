# OLI RouteSave 24.0 — save estimates into trip history

## Added
- The quick cost calculator now accepts optional trip origin and destination.
- After a successful estimate, the user can tap “Uložiť cestu do histórie”.
- The action saves the exact distance, vehicle, consumption override, fuel price, fuel estimate, toll, parking, total, and timestamp to the local trip-history repository.
- The save action is hidden until a valid calculation succeeds and becomes available again after recalculation.
- App Gradle version metadata updated to 24.0 / versionCode 24.

## Privacy and limits
- Trip records remain in app-private SharedPreferences on the device.
- No GPS location is collected by this feature; origin and destination are manually entered labels.
- No cloud synchronization, route provider, or live pricing is included.
- Saved records are estimates, not receipts or confirmed real-world costs.

## Validation status
- Source integration and archive packaging only.
- Android compilation and device tests have not been run; no APK is included.
