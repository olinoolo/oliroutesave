# OLI RouteSave 9.00 — potvrdenie hovoru a čísla

## Pridané
- Model stavov hovoru pre rozhranie a hlasového asistenta.
- Potvrdenie naviazané na konkrétny čakajúci hovor pomocou nonce a časového limitu.
- Nejasná odpoveď sa nikdy nepovažuje za súhlas; asistent sa opýta znova.
- Zrušenie, staré potvrdenie alebo vypršaný časový limit nemôžu spustiť hovor.
- Konzervatívne čistenie nadiktovaného čísla bez automatického domýšľania predvoľby.
- Register poskytovateľov na kontrolu dostupnosti hlasového hovoru/videohovoru podľa kanála.
- Testy pre potvrdenia, časový limit, staré potvrdenie a čistenie čísla.

## Dôležité
Ide o zdrojovú architektúru, nie o skompilovanú alebo otestovanú APK. Čistenie čísla nie je náhradou za regionálne overovanie telefónnych čísel. Konkrétne adaptéry pre Android Phone, WhatsApp a Messenger musia overiť reálne dostupné verejné integračné možnosti na zariadení.

## Bezpečnosť
- Súhlas sa viaže na presného príjemcu, kanál a režim hovoru.
- „Áno“ po vypršaní potvrdenia alebo k inému čakajúcemu hovoru sa ignoruje.
- Nejasné rozpoznanie reči nie je súhlas.
- Ak integrácia nevie bezpečne spustiť hovor bez ďalšej manipulácie s telefónom, asistent musí používateľa upozorniť a odporučiť bezpečné zastavenie.
