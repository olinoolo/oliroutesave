# OLI RouteSave 23.0 — persistent trip history

## Added
- Trip history model with validation.
- Repository interface, in-memory implementation for tests, and Android SharedPreferences implementation.
- `TripHistoryService` records estimates and computes a summary for the first currency represented in the history.
- Compose history screen showing totals and individual records, with delete action.
- Added a History entry in the More section.

## Current integration limitation
The history repository and screen are connected, but the quick cost calculator has not yet been given a “Save trip” action in this milestone. Until that action is connected, history will usually be empty. That is the next integration step.

## Currency note
Summary intentionally totals records in one currency only to avoid adding unlike currencies. It uses the currency of the newest stored record as the summary currency.

## Status
Local data only. No cloud sync, live routes, or external ticket/fuel APIs. No Android build or device test was run.
