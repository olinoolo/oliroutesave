# OLI RouteSave 25.0 — travel statistics

## Added
- Statistics service over saved local trip history.
- Filters: current calendar month, last 30 days, all time.
- Totals: trip count, distance, fuel litres, fuel cost, toll, parking, other costs, and overall cost.
- New Compose statistics screen reachable from More.
- Currency handling: the summary uses the newest currency in the selected period and ignores records in other currencies rather than adding unlike currencies.

## Limits
- Statistics are only as complete as the user's saved history.
- These are estimated trip costs, not verified receipts.
- No cloud backup, currency conversion, live route services, or fuel provider integrations.
- No APK built; Android compilation/device testing not performed.
