# OLI RouteSave 28.0 — train and bus search foundation

## Added
- Transit search request/connection/result models.
- Validation of route fields, passenger count, price, currency, time order and HTTPS booking URLs.
- Provider interface and service boundary ready for a real licensed/official data source.
- Search screen reachable from More → Vlaky a autobusy.
- Unconfigured provider returns an explicit unavailable status rather than inventing schedules or prices.

## Not yet implemented
- No live timetable, ticket price, seat availability, booking, or provider API.
- The screen is an integration-ready shell and does not claim live search.
- No APK built; Android compilation/device testing not performed.
