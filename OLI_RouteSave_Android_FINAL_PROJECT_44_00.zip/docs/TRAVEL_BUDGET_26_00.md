# OLI RouteSave 26.0 — monthly travel budget

## Added
- A validated monthly travel budget model and repository interface.
- App-private SharedPreferences persistence for the budget.
- A budget overview that sums saved trip records from the current calendar month.
- Budget status: on track, at least 80% used, or over limit.
- Currency filter: only saved trips in the budget currency are counted; no automatic currency conversion.
- Compose screen accessible from More → Mesačný rozpočet.

## Limits
- Totals include only saved cost estimates, not all real spending.
- This is an in-app status screen, not a system notification.
- No currency conversion, bank connection, cloud sync, or live travel data.
- No APK built; Android compilation/device testing not performed.
