# OLI RouteSave 9.10 — kontakty a hranica telefonovania

## Pridané do zdrojového projektu
- Rozhranie pre budúce vyhľadávanie kontaktov Androidu.
- Model stavov povolenia prístupu ku kontaktom.
- Politika výberu kontaktu: pri viacerých zhodách sa asistent musí opýtať, koho používateľ myslí.
- Politika výberu čísla: ak má kontakt viac čísel, asistent si vyžiada upresnenie.
- Hranica spúšťania telefonátu, ktorá blokuje volanie bez výslovného potvrdenia a odmieta zjavne neplatné čísla.
- Predvolený bezpečnejší smer integrácie: otvoriť systémový dialer; priame volanie je samostatný režim a vyžaduje runtime povolenie aj potvrdenie.

## Čo ešte treba doplniť
Tento balík ešte neobsahuje konkrétnu implementáciu cez Android `ContentResolver`/`ContactsContract`, dialer `Intent` ani reálne testy na telefóne. Sú to rozhrania a pravidlá, nie predstierané funkčné napojenie. WhatsApp a Messenger ostávajú závislé od ich dostupných podporovaných integračných možností.

## Príklad zamýšľaného správania
Používateľ: „Niko, zavolaj Petrovi.“
Asistent: ak sa nájde viac Petrovcov, opýta sa, ktorého myslí. Ak má vybraný Peter viac telefónnych čísel, opýta sa, na ktoré. Potom zopakuje cieľ a spôsob volania a čaká na jasné potvrdenie.
