# OLI RouteSave 9.00

Rozšírený zdrojový základ komunikácie o stavový model hovoru, potvrdenie viazané na konkrétnu akciu s časovým limitom, register dostupných poskytovateľov a konzervatívne čistenie nadiktovaných čísel. Pridané testy a dokumentácia. Bez reálnych Android providerov to ešte nie je funkčná telefonická integrácia ani APK.
