# OLI RouteSave – 7.20 Unified Voice & Assistant Runtime

Major voice integration milestone.

Connects:
- selected assistant profile
- invocation name
- voice session lifecycle
- speech input
- TTS output
- barge-in
- natural dialogue
- drive context
- action confirmation
- safety interruption
- community communication
- navigation voice guidance

The runtime is provider-agnostic. Android SpeechRecognizer, TTS engines, wake-word engines and audio focus are runtime/provider integrations.

Safety:
- emergency can interrupt speech
- active calls can interrupt normal dialogue
- navigation-critical state suppresses nonessential speech
- external actions require explicit confirmation
- the selected assistant is the voice identity used for communication
