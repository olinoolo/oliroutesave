# OLI RouteSave — 21.0

- Connected the Vehicle Compose destination to persistent vehicle storage.
- Added editable vehicle fields and local save/list flow.
- Connected Assistant settings UI to persistent assistant settings.
- Added assistant selection, supported language selection, and preference switches.
- Added safety copy clarifying that preference toggles do not themselves start microphone or external actions.
- No APK built; no Android compile/device test claimed.
