# OLI RouteSave 33.0

# OLI RouteSave 33.0 — Android hlasové adaptéry

## Pridané
- Android adaptér `AndroidSpeechInput` pre `SpeechRecognizer` s podporou jazykového tagu, čiastočných výsledkov a chybových hlásení.
- Kontrola dostupnosti rozpoznávania reči a runtime povolenia mikrofónu.
- Android adaptér `AndroidSpeechOutput` pre `TextToSpeech`, nastavenie jazyka, zastavenie a uvoľnenie zdrojov.
- `AndroidCallPreparation` pripraví iba `ACTION_DIAL` zámer; sám nezačne hovor.
- Povolenie `RECORD_AUDIO` je deklarované v manifeste, ale Android stále vyžaduje runtime súhlas používateľa.
- Verzia zvýšená na 33.0.

## Dôležité
Toto sú platformové adaptéry pripravené pre integráciu do obrazovky a životného cyklu aplikácie. Nie sú zatiaľ automaticky zapojené do používateľského rozhrania; preto v tejto verzii ešte nemožno tvrdiť, že hlasové ovládanie funguje od začiatku do konca.
- Mikrofón sa nesmie aktivovať potichu; oprávnenie musí používateľ udeliť.
- Volanie sa pripravuje cez dialer, nie priamym volaním. Pred otvorením dialera musí aplikácia dokončiť svoj explicitný hlasový potvrdzovací tok.
- SMS, zdieľanie polohy, kontaktový provider a trvalé hands-free počúvanie nie sú implementované.
- Jazyk reči závisí od podpory zariadenia a nainštalovaných jazykových balíkov.

## Stav zostavenia
Zdrojový Android projekt. APK nebolo vytvorené a Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
