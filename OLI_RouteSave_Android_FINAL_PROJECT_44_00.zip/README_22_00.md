# OLI RouteSave 22.0

Cumulative source package based on 21.0.

Main update: the home screen now reads the saved default vehicle and includes a quick trip-cost estimate using fuel consumption, fuel price, toll and parking. It supports a per-trip consumption override.

The estimate is offline and based on user-entered values. This is source code only; no APK has been built or tested.
