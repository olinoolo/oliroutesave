# OLI RouteSave 27.0
- Added travel mode comparison model and service.
- Added UI for car vs train vs bus vs plane cost comparison.
- Added manual ticket price and extra-cost inputs.
- Updated Android version metadata to 27.0 / versionCode 27.
- No APK built; no Android build/device test claimed.
