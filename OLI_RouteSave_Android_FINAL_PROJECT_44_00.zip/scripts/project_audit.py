#!/usr/bin/env python3
"""Static OLI RouteSave project audit. Uses only Python standard library.

Run from project root:
    python3 scripts/project_audit.py
This does not compile Kotlin or build an APK.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
MAIN = APP / "src" / "main"
JAVA = MAIN / "java"
MANIFEST = MAIN / "AndroidManifest.xml"

checks = []
def check(name, passed, detail=""):
    checks.append((name, bool(passed), detail))

check("Root Gradle settings exist", (ROOT / "settings.gradle.kts").is_file())
check("Root Gradle build file exists", (ROOT / "build.gradle.kts").is_file())
check("App Gradle build file exists", (APP / "build.gradle.kts").is_file())
check("Android manifest exists", MANIFEST.is_file())
check("Gradle wrapper script exists", (ROOT / "gradlew").is_file())
check("Gradle wrapper JAR exists", (ROOT / "gradle" / "wrapper" / "gradle-wrapper.jar").is_file())

kt_files = list(JAVA.rglob("*.kt")) if JAVA.exists() else []
check("Kotlin source files found", bool(kt_files), f"{len(kt_files)} files")

package_mismatches = []
missing_package = []
for path in kt_files:
    try:
        content = path.read_text(encoding="utf-8")
    except Exception as exc:
        missing_package.append(f"{path.relative_to(ROOT)} (read error: {exc})")
        continue
    match = re.search(r"^\s*package\s+([\w.]+)", content, re.M)
    if not match:
        missing_package.append(str(path.relative_to(ROOT)))
        continue
    expected = ".".join(path.parent.relative_to(JAVA).parts)
    actual = match.group(1)
    if expected and actual != expected:
        package_mismatches.append(f"{path.relative_to(ROOT)}: declared {actual}, path suggests {expected}")

check("Kotlin files declare package", not missing_package, "; ".join(missing_package[:5]))
check("Kotlin package/path consistency", not package_mismatches, "; ".join(package_mismatches[:5]))

manifest_text = MANIFEST.read_text(encoding="utf-8") if MANIFEST.is_file() else ""
check("Manifest has application element", "<application" in manifest_text)
check("Manifest has launcher activity", "android.intent.action.MAIN" in manifest_text and "android.intent.category.LAUNCHER" in manifest_text)

gradle_text = ""
for path in [ROOT / "build.gradle.kts", APP / "build.gradle.kts", ROOT / "settings.gradle.kts"]:
    if path.is_file():
        gradle_text += "\n" + path.read_text(encoding="utf-8")
check("Android plugin declared in Gradle files", "com.android.application" in gradle_text)
check("Kotlin Android plugin declared in Gradle files", "org.jetbrains.kotlin.android" in gradle_text)

# Basic secret scan; reports only file and pattern category, never the matching value.
secret_hits = []
secret_patterns = [
    ("possible API key", re.compile(r"(?i)\b(api[_-]?key|access[_-]?token|client[_-]?secret)\s*[:=]\s*['\"][^'\"]{12,}['\"]")),
    ("possible private key header", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
]
for path in ROOT.rglob("*"):
    if not path.is_file() or any(part in {".git", ".gradle", "build"} for part in path.parts):
        continue
    if path.suffix.lower() not in {".kt", ".kts", ".java", ".xml", ".json", ".properties", ".md", ".txt"}:
        continue
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        continue
    for label, pattern in secret_patterns:
        if pattern.search(content):
            secret_hits.append(f"{path.relative_to(ROOT)} ({label})")
check("No obvious hard-coded secrets detected", not secret_hits, "; ".join(secret_hits[:5]))

# Android runtime permission declarations are not runtime permission handling.
runtime_permission_uses = []
for path in kt_files:
    content = path.read_text(encoding="utf-8", errors="ignore")
    if "requestPermissions(" in content or "ActivityResultContracts.RequestPermission" in content or "ActivityResultContracts.RequestMultiplePermissions" in content:
        runtime_permission_uses.append(str(path.relative_to(ROOT)))
check("Runtime permission request code detected", bool(runtime_permission_uses),
      "; ".join(runtime_permission_uses[:5]) if runtime_permission_uses else "No request flow detected by this simple scan")

# Flag external provider implementation gaps by looking for obvious interface/provider boundaries.
provider_refs = []
for path in kt_files:
    content = path.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"\binterface\s+\w*(Provider|Repository)\b", content):
        provider_refs.append(str(path.relative_to(ROOT)))
check("Provider/repository abstraction files present", bool(provider_refs), f"{len(provider_refs)} source files with interface declarations")

print("OLI RouteSave — Static Project Audit")
print("=" * 42)
for name, passed, detail in checks:
    status = "PASS" if passed else "NEEDS WORK"
    print(f"[{status}] {name}" + (f" — {detail}" if detail else ""))
print("-" * 42)
passed_count = sum(1 for _, passed, _ in checks if passed)
print(f"Summary: {passed_count}/{len(checks)} checks passed.")
print("Note: this is static inspection only. It does not compile Kotlin or build/test an APK.")
# Exit 1 when core scaffold checks fail, but wrapper/runtime permission checks are advisory.
core_names = {
    "Root Gradle settings exist", "Root Gradle build file exists",
    "App Gradle build file exists", "Android manifest exists",
    "Kotlin source files found", "Manifest has application element",
    "Manifest has launcher activity", "Android plugin declared in Gradle files",
    "Kotlin Android plugin declared in Gradle files",
}
failed_core = [name for name, passed, _ in checks if name in core_names and not passed]
sys.exit(1 if failed_core else 0)
