# Changelog 36.0

- Pridaná obrazovka Ovládanie hlasom.
- Prepojené UI s AndroidVoiceSession a koordinátorom.
- Pridané runtime povolenie mikrofónu a ovládanie počúvania/hlasu.
- Externé akcie sa nevykonávajú; wake-word nie je implementovaný.
- Verzia zvýšená na 36.0.
