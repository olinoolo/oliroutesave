# Integration note for milestone 8.30

1. Ensure the app module uses Jetpack Compose and Material 3.
2. Add Material Icons Extended if the project does not already provide the icons used here.
3. Set the Activity content to `RouteSaveComposeApp()` inside `RouteSaveTheme` (the app composable already applies the theme).
4. Replace map placeholders with the selected real map SDK.
5. Connect button actions to the existing runtime/controllers. Current buttons are UI demo callbacks.
6. Do not enable live location, calling, SMS, or public help requests until permissions, provider integrations, and explicit assistant confirmation gates are connected and tested.
7. This package is source-only and has not been compiled into an APK.
