# OLI RouteSave – 7.40 Persistent Data Foundation

This block introduces the application's core data layer.

## Added
- vehicle profiles
- average fuel consumption in l/100 km
- per-trip consumption override
- fuel price handling
- trip history model
- toll and parking costs
- assistant settings
- app settings
- vehicle/trip/settings store interfaces
- in-memory implementations for the architecture
- trip cost calculator
- tests

## Vehicle consumption
The default vehicle consumption is taken from the vehicle profile.
A specific trip can override the consumption value without changing the vehicle profile.

## Next production step
Replace the in-memory stores with Android persistence such as Room/DataStore while keeping the interfaces stable.
