# Messaging assistant integration — 8.80

## Intended hands-free flow
1. User enables notification access for OLI RouteSave in Android settings.
2. A supported messaging app posts a notification containing a readable message preview.
3. The listener emits a normalized event; content should be kept in memory only unless the user explicitly enables history.
4. The selected assistant announces the sender and asks before reading private content when configured to do so.
5. User dictates a reply; OLI prepares the text and reads it back.
6. The assistant asks for explicit confirmation.
7. Only after confirmation, an app-specific provider may send via an available notification reply action (RemoteInput). If no supported action exists, the assistant explains that the reply cannot be sent from that notification.

## Privacy and safety
- Notification access is broad and can expose sensitive content from multiple apps. Explain this clearly before directing users to enable it.
- Do not log message bodies or persist them by default.
- Do not treat notification access as consent to read messages aloud at any time; offer a private-mode setting and allow interruption/cancellation.
- No message is sent without confirmation of the final text and recipient.
- The service cannot promise access to messages that are hidden, bundled, muted, or not present in notifications.
