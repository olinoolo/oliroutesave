# Changelog 39.0

- Použitie skutočného skóre istoty Android SpeechRecognizer, keď je dostupné.
- Nízka istota pri chýbajúcom skóre; nejasná odpoveď sa nepovažuje za súhlas.
- Odstránené dvojité vytvorenie čakajúcej potvrdzovanej akcie v ukážkovom UI.
- Pridaný technický audit a zaznamenané obmedzenia zostavenia.
