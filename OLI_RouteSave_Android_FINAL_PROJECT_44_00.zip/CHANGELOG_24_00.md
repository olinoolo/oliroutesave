# OLI RouteSave 24.0
- Connected the quick cost calculator to local trip history.
- Added optional origin and destination fields.
- Added “Uložiť cestu do histórie” after a valid calculation.
- Bumped Android version metadata to 24.0 (versionCode 24).
- No APK built; no Android compilation/device test claimed.
