# OLI RouteSave 28.0

Cumulative Android source project based on version 27.0.

Adds the train/bus search screen and a validated provider interface. The current provider explicitly reports that live data is not configured; no fake departures or prices are shown.

This is source code, not an APK. Android compilation and device tests remain outstanding.
