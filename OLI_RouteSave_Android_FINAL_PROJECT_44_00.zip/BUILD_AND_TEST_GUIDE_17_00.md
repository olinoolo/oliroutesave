# OLI RouteSave 17.0 — build and test guide

## What changed
This milestone adds a repeatable static project-audit script and a practical first-build guide. It is still a source project, not a prebuilt APK.

## Run the audit
From the project root:
```bash
python3 scripts/project_audit.py
```
The script uses only Python's standard library. It checks key Gradle files, the manifest, Kotlin package/path consistency, obvious hard-coded secret patterns, runtime permission request code, and provider/repository abstractions. Its findings are indicators, not a Kotlin compiler.

## First real Android build
1. Open the folder containing `settings.gradle.kts` in Android Studio.
2. Set Gradle JDK to JDK 17.
3. Install Android SDK Platform 35 if Android Studio requests it.
4. Sync Gradle.
5. Run the Gradle task `:app:assembleDebug`.
6. Save the full build output if the task fails; the first compiler error is usually the best starting point.
7. Run `:app:testDebugUnitTest` after compilation succeeds.
8. Install and launch the debug APK on a physical Android device.
9. Test each external action with negative cases: no confirmation, unclear answer, expired confirmation, and explicit rejection.

## Safety checks before a test release
- No phone call, SMS, messaging, location sharing, or community request should execute without a fresh, clear confirmation.
- Permission denial should leave the rest of the app usable where possible.
- If a live data source is not connected, label its result as unavailable or estimated; never imply a live lookup occurred.
- Never present the app as a certified tachograph or as emergency-service replacement.
- Do not store raw phone numbers unnecessarily in contact aliases.

## Current limits
The audit script does not compile Kotlin, does not install Android SDK components, and does not generate an APK. A Gradle wrapper may still need to be generated through a compatible Gradle installation. Actual compilation and device testing remain outstanding.
