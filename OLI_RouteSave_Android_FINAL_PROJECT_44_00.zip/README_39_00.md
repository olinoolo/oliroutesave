# OLI RouteSave 39.0

# OLI RouteSave — technická kontrola verzie 39.0

## Opravy v tejto verzii
1. **Skóre rozpoznania reči:** `AndroidSpeechInput` teraz číta `SpeechRecognizer.CONFIDENCE_SCORES`, ak ich Android poskytne.
2. **Bezpečný záložný stav:** ak skóre chýba alebo je záporné, používa sa nízka istota 0.75; potvrdenie preto neprejde automaticky prahom 0.85.
3. **Jedno vytvorenie čakajúcej akcie:** ukážkové tlačidlá už zbytočne nevolajú stavový automat dvakrát.
4. Verzia Android aplikácie zvýšená na 39.0.

## Zistenia auditu
- V archíve nie je Gradle Wrapper (`gradlew`/`gradlew.bat`).
- V tomto prostredí nie je dostupný príkaz `gradle` ani nakonfigurovaná premenná Android SDK (`ANDROID_HOME`/`ANDROID_SDK_ROOT`).
- Preto tu nebolo možné vykonať Gradle build ani vytvoriť APK.
- Zdrojový projekt obsahuje viacero funkcií, ktoré sú zatiaľ iba modelmi alebo ukážkovým UI; živé cestovné údaje, nákup lístkov a vykonávanie externých akcií nie sú týmto krokom potvrdené.
- Úpravy boli skontrolované na úrovni očakávaných súborov a textových zmien, nie kompilátorom Kotlin/Android.

## Bezpečnostné pravidlo
Ani jasné hlasové „áno“ v tejto vrstve nevykoná telefonát, SMS, zdieľanie polohy ani nákup. Potvrdenie iba aktualizuje stav; samotná vykonávacia vrstva sa musí implementovať a otestovať samostatne.
