# Changelog 42.0

- Pridaný diagnostický skript pre prostredie zostavenia.
- Zjednotený ďalší postup na zistenie a opravu build chýb.
- Verzia zvýšená na 42.0.
