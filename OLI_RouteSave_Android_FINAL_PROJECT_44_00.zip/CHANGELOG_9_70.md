# OLI RouteSave — 9.70

- Added contact-alias-first recipient resolution for voice calling.
- Added explicit states for missing, ambiguous and permission-blocked contact lookups.
- Added Slovak spoken read-back prompts for audio calls, video calls and dictated phone numbers.
- Recipient resolution never launches a call or counts as user consent.
- Source-only package; not compiled or device-tested.
