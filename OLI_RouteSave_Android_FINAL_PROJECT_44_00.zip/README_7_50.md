# OLI RouteSave 7.50 – Android Persistence & Settings
Added a stable persistence abstraction, settings repository, vehicle repository, assistant/app settings storage, vehicle-profile controller and tests.
Stored settings include language, metric units, truck mode, community/voice switches, selected assistant, invocation name, personal address, concise/proactive behavior and romance settings.
Vehicle data includes consumption in l/100 km and fuel price. The architecture keeps storage behind interfaces so Android DataStore/Room can be connected later without rewriting higher layers.
This remains source architecture, not a compiled APK.
