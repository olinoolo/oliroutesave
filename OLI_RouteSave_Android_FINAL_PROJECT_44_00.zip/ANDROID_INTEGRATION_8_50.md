# Voice integration notes — 8.50

## Runtime flow
1. User explicitly taps the microphone or later invokes a configured assistant wake phrase.
2. Android asks for microphone permission when needed.
3. Speech recognizer returns recognized text.
4. `VoiceIntentParser` maps a small set of phrases to typed intents.
5. Safe intents can be routed to the relevant controller.
6. External actions are only prepared as pending confirmation; do not execute until the user clearly confirms.
7. The assistant responds using Android TTS, with the selected assistant's invocation/personal address configured separately.

## Initial sample intents
- “Niko, naplánuj trasu do Piešťan” → route planning intent
- “Niko, koľko ma bude stáť palivo?” → fuel estimate intent
- “Niko, mám defekt” → breakdown/help intent, asks before publishing a help request
- “Niko, zavolaj manželke” → call intent, requires a confirmation step before the call

## Production requirements
- Wire Activity Result API microphone permission to UI activation.
- Call recognizer on the main thread and handle `ERROR_*` results.
- Release `SpeechRecognizer` and `TextToSpeech` with lifecycle.
- Handle audio focus and navigation/emergency interruptions.
- Add selected assistant profile, language selection, and invocation names.
- Test speech recognition/TTS across supported languages and real devices.
- For continuous hands-free wake word, integrate and license a dedicated wake-word provider; this adapter is single-turn speech recognition only.
