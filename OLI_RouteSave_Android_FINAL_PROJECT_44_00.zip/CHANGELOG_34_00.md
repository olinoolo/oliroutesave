# Changelog 34.0

- Pridaný koordinátor hlasovej interakcie.
- Pridané spracovanie výsledkov rozpoznávania, oslovenia asistenta a toku potvrdenia.
- Externé akcie sa nevykonávajú automaticky.
- Android SpeechRecognizer/TextToSpeech ešte nie sú zapojené do UI.
- Verzia zvýšená na 34.0.
