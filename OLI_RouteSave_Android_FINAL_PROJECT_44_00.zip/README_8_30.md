# OLI RouteSave — milestone 8.30
Continued from the 8.20 project package.

## What this milestone adds
- A concrete Jetpack Compose screen skeleton for Home, Route, Drive, Vehicle, Assistant, Community, and Settings.
- Dark navy / blue / orange visual direction matching the approved OLI RouteSave mockup.
- Bottom navigation and a large hands-free assistant button.
- Home summary cards for vehicle fuel use, trip costs, and community help.
- Drive screen with route guidance placeholder, ETA/distance, speed card, and end-drive control.
- Accessibility-minded large touch targets and concise labels.

## Important
This is Android source code, not a compiled APK. It has not been built or device-tested in this environment.
The map is a placeholder container; a real map/navigation SDK, location permissions, speech recognition, TTS, and backend integrations must be configured and tested before production use.
