# OLI RouteSave 15.0

This is the cumulative Android source project plus an initial Gradle build scaffold.

- App name: **OLI RouteSave**
- Android package: `com.oli.routesave`
- UI framework: Jetpack Compose / Material 3
- Suggested build JDK: 17
- Compile SDK: 35
- Minimum SDK: 26

Read `docs/INTEGRATION_BUILD_AUDIT_15_00.md` before attempting a build. The project has not been compiled in this environment, and live service integrations remain incomplete.
