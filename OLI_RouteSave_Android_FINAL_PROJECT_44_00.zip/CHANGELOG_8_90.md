# OLI RouteSave 8.90

Pridaný zdrojový základ pre potvrdením chránené hlasové hovory a videohovory cez telefón, WhatsApp a Messenger, vrátane prípravy volania na čísla, ktoré nie sú uložené v kontaktoch. Konkrétne Android adaptéry a testovanie na zariadení zostávajú ďalším krokom.
