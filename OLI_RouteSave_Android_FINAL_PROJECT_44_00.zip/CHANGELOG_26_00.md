# OLI RouteSave 26.0
- Added monthly budget model, validation, and local persistence.
- Added budget status and current-month spend overview.
- Added budget screen accessible from More.
- Updated Android version metadata to 26.0 / versionCode 26.
- No APK built; no Android build/device test claimed.
