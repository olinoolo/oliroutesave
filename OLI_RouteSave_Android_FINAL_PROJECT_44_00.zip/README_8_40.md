# OLI RouteSave — milestone 8.40: Android integration foundation

## Added
- Example `MainActivity` that hosts the Compose UI.
- Android manifest template with app label/theme and only the core permissions needed for the next integration stage.
- Permission request coordinator for location and microphone, using Android's runtime permission flow.
- Permission policy notes: request permissions in context, explain why, and don't request calls/SMS/contacts/background location until the corresponding feature is being wired and the user starts it.
- Build integration checklist.

## Honest status
This remains a source project package, not a compiled or device-tested APK. The archive inherited the existing source architecture and adds integration templates. The project still needs a complete Gradle Android app setup, dependency/version alignment, SDK configuration, compilation, and real-device testing before an installable APK can be claimed.
