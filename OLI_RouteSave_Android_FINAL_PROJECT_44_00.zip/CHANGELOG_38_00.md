# Changelog 38.0

- Pridaný živý mikrofónový tok pre odpoveď na hlasovú otázku o potvrdení.
- Pridaná runtime žiadosť o povolenie mikrofónu na obrazovke potvrdenia.
- Nejasná odpoveď vyvolá ďalšiu hlasovú otázku.
- Externé akcie sa nevykonávajú.
- Verzia zvýšená na 38.0.
