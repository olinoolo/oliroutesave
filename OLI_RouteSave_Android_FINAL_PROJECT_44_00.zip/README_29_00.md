# OLI RouteSave 29.0

# OLI RouteSave 29.0 — Inteligentné pokračovanie cesty

## Čo pribudlo
- Nová obrazovka **Inteligentné pokračovanie cesty** v menu **Viac**.
- Ručné zadanie miesta, kde cesta pokračuje, a konečného cieľa.
- Výber počtu cestujúcich.
- Voľby dopravy: vlak, autobus, metro, električka, lietadlo, taxi a chôdza; samostatne možno povoliť aj úsek autom.
- Preferencia budúceho plánovania: najskorší príchod, najnižšia cena, najkratšie trvanie alebo najmenej prestupov.
- Modely a validácia pre viacúsekovú cestu, cenu, časy, prestupy, stav čerstvosti dát a HTTPS odkazy na rezerváciu.
- Rozhranie `JourneySearchProvider` a bezpečný predvolený poskytovateľ, ktorý otvorene hlási, že živé dáta nie sú nakonfigurované.

## Čo ešte nie je pripojené
Táto verzia **neobsahuje živé cestovné poriadky, letové údaje, aktuálne ceny, dostupnosť miest ani nákup lístkov**. Zobrazené možnosti sú zatiaľ používateľské nastavenia pre budúce vyhľadávanie; aplikácia nevymýšľa falošné odchody ani ceny. Automatické GPS vyhľadanie najbližšej stanice nie je v tejto verzii zapnuté. Rezervácie a externé akcie sa nevykonávajú.

## Bezpečnosť a súkromie
- Používateľ zadáva miesto ručne; automatická poloha sa bez výslovnej akcie nepoužíva.
- Pred budúcimi externými akciami (napr. otvorenie rezervácie alebo nákup) má hlasový asistent najprv požiadať o jasné potvrdenie.
- Rozhranie poskytovateľa je pripravené na budúce napojenie reálnych služieb.

## Technický stav
Verzia aplikácie: `29.0` (`versionCode 29`). Ide o zdrojový Android projekt. V tomto prostredí nebol vytvorený APK a nebolo vykonané zostavenie Gradle ani testovanie na zariadení.
