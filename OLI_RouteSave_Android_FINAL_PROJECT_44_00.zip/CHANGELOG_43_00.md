# Changelog 43.0

- Pridaný GitHub Actions workflow na cloudové zostavenie debug APK.
- Pridaný návod na získanie APK z Android telefónu.
- Verzia zvýšená na 43.0.
