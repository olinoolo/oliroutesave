# OLI RouteSave 40.0

# OLI RouteSave — kontrolný krok 40.0

## Zmeny
- Verzia Android aplikácie zvýšená na 40.0 (`versionCode 40`).
- Odstránené opakované identické importy z hlavného Compose súboru.
- Pridaný skript `tools/validate_project.py` na lokálnu statickú kontrolu povinných súborov, manifestu, verzie a duplicitných importov.

## Ako spustiť statickú kontrolu
V koreňovom priečinku projektu spusti:
```bash
python3 tools/validate_project.py
```
Na Windows možno použiť:
```powershell
py tools/validate_project.py
```

## Čo táto kontrola znamená
Skript kontroluje základnú štruktúru projektu a niektoré zjavné problémy. **Nekompiluje Kotlin a nedokazuje, že aplikácia sa zostaví alebo spustí.**

## Stav zostavenia
V prostredí, kde bol pripravený tento archív, nie je dostupný Gradle ani Android SDK. Preto nebol vykonaný Gradle build, nebolo vytvorené APK a neprebehlo testovanie na zariadení.
