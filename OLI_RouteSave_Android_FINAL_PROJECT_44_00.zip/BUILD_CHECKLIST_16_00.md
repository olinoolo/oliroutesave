# OLI RouteSave 16.0 — build checklist

- [ ] Open project root (folder containing `settings.gradle.kts`) in Android Studio.
- [ ] Select JDK 17 for Gradle.
- [ ] Install Android SDK Platform 35.
- [ ] Complete Gradle sync.
- [ ] Run `:app:assembleDebug`.
- [ ] Resolve all compile errors.
- [ ] Run `:app:testDebugUnitTest`.
- [ ] Install debug APK on Android.
- [ ] Verify startup and permissions.
- [ ] Verify external actions cannot run without explicit confirmation.
- [ ] Verify unavailable live providers are clearly labelled.
- [ ] Do not call the app production-ready until all required checks pass.
