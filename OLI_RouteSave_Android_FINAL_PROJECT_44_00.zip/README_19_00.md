# OLI RouteSave 19.0

Cumulative source package based on version 18.0.

This milestone adds UI-facing controller classes and a validated vehicle form model so a future Compose screen can use persistent vehicle and voice settings repositories consistently.

Source-only archive. It is not an APK. UI screens, app navigation, Gradle wrapper, Android compilation, and device testing remain outstanding.
