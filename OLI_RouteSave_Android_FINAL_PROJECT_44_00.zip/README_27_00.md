# OLI RouteSave 27.0

Cumulative Android source project based on version 26.0.

Added a travel-mode comparison screen. It estimates car fuel/toll/parking costs and lets the user manually enter ticket and extra costs for train, bus and plane. All outputs are labelled as estimates, not live quotes.

This is source code, not an APK. Android compilation and device tests remain outstanding.
