# OLI RouteSave 41.0

# OLI RouteSave 41.0 — príprava na zostavenie APK

## Čo je pridané
- `tools/build_debug_apk.sh` — skript na zostavenie debug APK na Linux/macOS, ak je dostupný Gradle a Android SDK.
- `tools/build_debug_apk.ps1` — ekvivalent pre Windows PowerShell.
- Verzia Android aplikácie je 41.0.

## Zostavenie vo Windows
1. Rozbaľ celý ZIP do priečinka.
2. Otvor priečinok projektu v Android Studio.
3. Nainštaluj odporúčaný Android SDK podľa výzvy Android Studio.
4. Spusti Gradle Sync a vyrieš prípadné chyby, ktoré IDE zobrazí.
5. V termináli projektu spusti `.	oolsuild_debug_apk.ps1` alebo priamo `gradle :app:assembleDebug`.
6. Pri úspechu hľadaj APK v `app/build/outputs/apk/debug/app-debug.apk`.

## Zostavenie na Linux/macOS
V koreňovom priečinku spusti `bash tools/build_debug_apk.sh`.

## Dôležité
- Archív neobsahuje `gradlew` ani binárne súbory Gradle Wrapper. Skripty preto vyžadujú lokálnu inštaláciu Gradle.
- Skripty neobchádzajú chýbajúce SDK, závislosti ani chyby Kotlinu; oznámia ich pri skutočnom builde.
- V tomto prostredí sa Gradle build nevykonal, APK nebolo vytvorené a aplikácia nebola otestovaná na telefóne.
- Toto je krok na zjednodušenie build procesu, nie potvrdenie, že build už prechádza.
