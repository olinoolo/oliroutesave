# OLI RouteSave — milestone 8.80: Messaging assistant foundation

## Added
- Notification-access foundation for reading message previews exposed by Android notifications.
- Notification listener service template and normalized message-notification model.
- Messaging provider interfaces for reading notifications and sending a reply through an app's supported notification reply action.
- Confirmation-first voice reply coordinator.
- Unit tests for confirmation-required replies and privacy-safe extraction.

## Important limitations
This is source code, not a compiled APK. Messenger, WhatsApp, SMS and other apps expose different notification structures and reply actions. Some notifications may hide message text or have no reply action. This module does not guarantee full access to all conversations, does not bypass app security, and does not send messages directly by itself. User must manually grant Android notification access in system settings. Actual RemoteInput reply wiring, app-specific testing, voice/TTS wiring and lifecycle integration remain to be completed.
