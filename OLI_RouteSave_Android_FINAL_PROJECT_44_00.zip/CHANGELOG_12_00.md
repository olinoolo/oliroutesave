# OLI RouteSave — 12.0

Large block: travel and savings foundation.
- Added vehicle profile fuel consumption and per-trip override.
- Added fuel/toll/parking/other-cost estimate with validation.
- Added car/train/bus/plane comparison models and provider interface.
- Missing live providers are labelled as unconnected rather than inventing fares.
- Added unit-test source and integration documentation.
- Source-only; APK not compiled or device-tested.
