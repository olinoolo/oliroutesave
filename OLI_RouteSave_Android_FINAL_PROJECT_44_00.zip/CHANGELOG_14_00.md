# OLI RouteSave — 14.0

Large block: professional-driver support and entertainment foundation.
- Added configurable break reminder planning with default 30-minute lead and 45-minute break duration.
- Added rest-stop provider/search abstraction with validation and sorting.
- Added entertainment models and driving safety policy.
- Added unit-test source and integration documentation.
- No live GPS, rest-stop database or audio provider is connected.
- Source-only; APK not compiled or device-tested.
