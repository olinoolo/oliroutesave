# Changelog 31.0

- Pridané modely hlasových príkazov a vlastných oslovení asistentov.
- Pridaná obrazovka Hlasový spolujazdec s ukážkovou textovou kontrolou príkazu.
- Pridané pravidlá pre potvrdenie externých akcií.
- Skutočné rozpoznávanie reči, TTS a vykonávanie externých akcií nie sú pripojené.
- Verzia zvýšená na 31.0.
