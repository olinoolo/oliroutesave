# OLI RouteSave 25.0
- Added trip statistics service and period filters.
- Added statistics screen and access from More.
- Added cost breakdown and distance/fuel totals.
- Updated Android version metadata to 25.0 / versionCode 25.
- No APK built and no Android build/device test claimed.
