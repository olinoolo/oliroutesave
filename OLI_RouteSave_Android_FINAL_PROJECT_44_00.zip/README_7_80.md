# OLI RouteSave 7.80 – Drive / GPS / Navigation Runtime

This block connects the UI foundation to runtime provider boundaries.

## Added
- LocationPoint
- LocationProvider
- LocationSession
- NavigationSession
- Navigation session lifecycle
- DriveSessionOrchestrator
- VoiceNavigationBridge
- ProviderHealth

## Runtime flow
1. User starts driving.
2. Android drive runtime becomes active.
3. Location session can start.
4. Navigation calculates and owns the active route.
5. Voice controls can operate while driving.
6. Pause/resume/stop propagate through the same orchestrator.
7. Emergency interruption can terminate voice/driving UI safely.

## Provider boundaries
Actual GPS, Mapbox/other navigation SDK, speech recognition, TTS and wake-word implementations remain replaceable providers.

## Important
This is a source integration layer, not a compiled APK.
