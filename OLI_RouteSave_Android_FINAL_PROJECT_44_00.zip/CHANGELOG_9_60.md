# OLI RouteSave — 9.60

- Added Android `SharedPreferences` persistence for contact aliases.
- Alias entries survive app restarts.
- Storage is limited to alias, contact ID and contact display name; no phone numbers are copied.
- Malformed persisted entries are safely skipped.
- This milestone is source-only and is not a compiled APK.
