# Changelog 35.0

- Pridaný AndroidVoiceSession spájajúci Android rozpoznávanie reči, TTS a koordinátor.
- Pridaná kontrola povolenia mikrofónu a správa životného cyklu.
- UI a runtime žiadosť o povolenie ešte nie sú pripojené.
- Externé akcie sa nevykonávajú.
- Verzia zvýšená na 35.0.
