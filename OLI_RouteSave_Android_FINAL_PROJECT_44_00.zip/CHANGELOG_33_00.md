# Changelog 33.0

- Pridaný Android SpeechRecognizer adaptér s kontrolou oprávnenia a chybovými hláseniami.
- Pridaný Android TextToSpeech adaptér.
- Pridaná príprava telefonátu cez ACTION_DIAL bez automatického volania.
- Deklarované povolenie RECORD_AUDIO.
- Adaptéry ešte nie sú napojené do UI; APK nebolo zostavené ani testované.
- Verzia zvýšená na 33.0.
