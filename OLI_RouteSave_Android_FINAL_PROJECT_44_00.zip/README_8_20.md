# OLI RouteSave 8.20 – Android Activity / Compose-Ready UI

## Added
- Android UI host contract
- Activity bridge to central application runtime
- Compose-ready screen catalog
- map container specification
- voice button specification
- driving overlay specification
- UI action guards
- tests

## Intended Android UI
The main screen is prepared for:
- OLI RouteSave branding
- map
- user location
- route
- follow-user camera
- assistant voice button
- drive state
- destination
- ETA
- remaining distance

## Architecture
The bridge keeps Android UI separate from the application/domain runtime. A real Jetpack Compose Activity can consume these models without moving business logic into Composables.

## Important
This is Compose-ready source architecture, not a compiled APK.
