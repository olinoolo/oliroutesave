# Changelog 32.0

- Pridaný engine odpovedí na hlasové príkazy.
- Pridané modely rozlíšenia kontaktov bez automatického volania.
- Pridaný tok jasného potvrdenia alebo odmietnutia.
- Android SpeechRecognizer, TextToSpeech, kontakty a hovory zatiaľ nie sú napojené.
- Verzia zvýšená na 32.0.
