# OLI RouteSave 9.30

Pridané konkrétne Android adaptéry pre ContactsContract a systémové telefonické vytáčanie. ACTION_DIAL je bezpečnejšia predvolená cesta; ACTION_CALL vyžaduje explicitné potvrdenie a runtime CALL_PHONE permission. Zostavenie APK a testy na zariadení ešte neboli vykonané.
