# Changelog 41.0

- Pridaný build skript pre Linux/macOS.
- Pridaný build skript pre Windows PowerShell.
- Zdokumentovaný postup zostavenia debug APK.
- Verzia zvýšená na 41.0.
