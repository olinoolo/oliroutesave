# OLI RouteSave 23.0

Cumulative source project based on 22.0.

Added local trip history storage, a service for recording cost estimates, and a history screen with totals and deletion. The history screen is prepared, but the “save this estimate” action from the calculator is not connected yet.

This is source code, not an APK. Android compilation and device tests remain outstanding.
