# OLI RouteSave 9.40

Pridané prepojenie hlasových príkazov s vyhľadávaním kontaktov a používateľskými aliasmi, ako aj testy. Príkaz sa iba spracuje a pripraví na ďalší potvrdzovací krok; táto verzia sama osebe neuskutočňuje hovor a nie je skompilovanou APK.
