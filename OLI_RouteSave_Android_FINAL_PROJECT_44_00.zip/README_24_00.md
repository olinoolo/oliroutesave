# OLI RouteSave 24.0

Cumulative Android source project based on version 23.0.

Main improvement: successful quick cost estimates can now be saved into local trip history. Optional origin/destination labels, the exact cost inputs, calculated totals and timestamp are stored on the device. The history screen from 23.0 can then display the saved records.

This is source code, not an APK. Android build and device testing remain outstanding.
