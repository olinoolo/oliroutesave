# OLI RouteSave 8.00 – Unified Application Integration

This is the first major composition layer that connects the previous modules into one application runtime.

## Integrated
- application state
- dependency graph / composition root
- screen navigation
- persistent settings repository
- vehicle repository
- permission/readiness checks
- foreground drive runtime
- GPS lifecycle
- navigation session
- drive UI state
- start/pause/resume/stop drive actions
- central event handling

## Architecture
Android-specific services are injected through interfaces. This keeps the core runtime testable and allows Mapbox, Android location, AudioManager and notification implementations to be swapped without changing the application logic.

## Safety
Drive startup checks location readiness. Emergency can terminate the active drive flow. Existing assistant-first confirmation rules remain above the integration layer.

## Important
8.00 is a source integration milestone. It is not a compiled APK. Real Android provider implementations and SDK dependencies still need to be connected in the Android build environment.
