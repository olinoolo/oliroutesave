# OLI RouteSave 9.20

Pridaný hlasový tok na spracovanie nadiktovaného čísla, hlasové zopakovanie presného cieľa/kanála/režimu a vrstva otázok pre kontaktné vyhľadávanie. Obsahuje testy a dokumentáciu. Konkrétne Android adaptéry a APK build nie sú súčasťou tejto verzie.
