# Voice-to-app bridge — integration plan

1. `VoiceAssistantCoordinator` receives a recognition result.
2. `VoiceIntentParser` classifies the text.
3. The selected `AssistantProfile` controls name/address/language.
4. Route and fuel requests call injected safe callbacks.
5. External actions are stored as pending and announced for confirmation.
6. Only after explicit yes does the coordinator return an approved action for a platform service to execute.
7. Unknown speech asks for clarification; it must never guess and perform an external action.

The actual Android adapter still needs to be wired to lifecycle-aware Compose state and the app's dependency graph.
