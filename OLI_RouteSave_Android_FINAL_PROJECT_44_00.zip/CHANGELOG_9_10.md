# OLI RouteSave 9.10

Pridané rozhrania pre Android kontakty, bezpečné riešenie viacerých zhôd a viacerých telefónnych čísel, stav povolenia ku kontaktom a potvrdením chránená hranica telefonovania. Ide o zdrojovú prípravu; konkrétny Android ContentResolver/dialer adapter a testovanie na zariadení ešte nie sú implementované.
