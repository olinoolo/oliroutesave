# OLI RouteSave — 20.0

- Added home-screen UI state.
- Added home controller with route fields, assistant status, default vehicle summary and section navigation state.
- Added a screen catalogue for Home, Vehicle, Assistant Settings, Travel Comparison and Community Help.
- Added integration notes and explicit limitations.
- No Compose screen was rendered, no Android build was run, and no APK was produced.
