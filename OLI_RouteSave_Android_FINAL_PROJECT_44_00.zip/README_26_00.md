# OLI RouteSave 26.0

Cumulative Android source project based on version 25.0.

Added a persistent monthly travel budget, spending overview and status warning when at least 80% of the limit is used or the limit is exceeded. Open it from More → Mesačný rozpočet.

This is source code, not an APK. Android compilation and device tests remain outstanding.
