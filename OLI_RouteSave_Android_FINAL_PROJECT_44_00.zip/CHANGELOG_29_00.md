# Changelog 29.0

- Pridaná obrazovka Inteligentné pokračovanie cesty.
- Pridané modely viacúsekovej trasy a rozhranie poskytovateľa.
- Pridané voľby dopravy a preferencie plánovania.
- Živé cestovné dáta zostávajú nepripojené; aplikácia neuvádza vymyslené spoje ani ceny.
- Verzia zvýšená na 29.0.
