# Changelog 44.0

- Workflow ukladá diagnostiku aj pri neúspešnom builde.
- APK artefakt sa nahráva len po úspešnom zostavení.
- Verzia zvýšená na 44.0.
