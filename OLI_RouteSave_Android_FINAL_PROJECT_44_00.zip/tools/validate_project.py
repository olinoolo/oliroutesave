#!/usr/bin/env python3
"""Static sanity checks for the OLI RouteSave Android project. Does not compile the app."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
errors = []
warnings = []

required = [
    root / "settings.gradle.kts",
    root / "build.gradle.kts",
    root / "app" / "build.gradle.kts",
    root / "app" / "src" / "main" / "AndroidManifest.xml",
    root / "app" / "src" / "main" / "java" / "com" / "oli" / "routesave" / "RouteSaveActivity.kt",
]
for path in required:
    if not path.is_file():
        errors.append(f"Chýba povinný súbor: {path.relative_to(root)}")

app_gradle = root / "app" / "build.gradle.kts"
if app_gradle.is_file():
    text = app_gradle.read_text(encoding="utf-8")
    code = re.search(r"versionCode\s*=\s*(\d+)", text)
    name = re.search(r'versionName\s*=\s*"([^"]+)"', text)
    if not code or not name:
        errors.append("Nepodarilo sa prečítať versionCode/versionName.")
    else:
        print(f"Verzia aplikácie: {name.group(1)} (versionCode {code.group(1)})")
    if "com.android.application" not in text:
        errors.append("Chýba Android application plugin.")
    if "compileSdk" not in text:
        errors.append("Chýba compileSdk.")

manifest = root / "app" / "src" / "main" / "AndroidManifest.xml"
if manifest.is_file():
    text = manifest.read_text(encoding="utf-8")
    if "android.intent.action.MAIN" not in text or "android.intent.category.LAUNCHER" not in text:
        errors.append("Manifest nemá zjavný launcher entry point.")
    if "android.permission.RECORD_AUDIO" in text:
        print("Mikrofónové povolenie deklarované v manifeste (runtime povolenie stále nutné).")

java_root = root / "app" / "src" / "main" / "java"
for path in java_root.rglob("*.kt"):
    text = path.read_text(encoding="utf-8")
    imports = [line.strip() for line in text.splitlines() if line.strip().startswith("import ")]
    duplicates = sorted({line for line in imports if imports.count(line) > 1})
    if duplicates:
        warnings.append(f"{path.relative_to(root)} má duplicitné importy: " + ", ".join(duplicates))
    if "\x00" in text:
        errors.append(f"{path.relative_to(root)} obsahuje NUL znak.")

if not (root / "gradlew").exists():
    warnings.append("Chýba Gradle Wrapper (gradlew); na zostavenie treba lokálny Gradle alebo wrapper.")
if not (root / "gradlew.bat").exists():
    warnings.append("Chýba Gradle Wrapper pre Windows (gradlew.bat).")

print("\nVýsledok statickej kontroly:")
if errors:
    print(f"CHYBY: {len(errors)}")
    for item in errors:
        print(" -", item)
else:
    print("Povinné súbory a základná konfigurácia: OK")
if warnings:
    print(f"UPOZORNENIA: {len(warnings)}")
    for item in warnings:
        print(" -", item)
print("\nTáto kontrola nenahrádza Gradle build, Kotlin kompiláciu ani test na zariadení.")
sys.exit(1 if errors else 0)
