#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v gradle >/dev/null 2>&1; then
  echo "CHYBA: Príkaz gradle sa nenašiel."
  echo "Nainštaluj Gradle a Android SDK, alebo otvor projekt v Android Studio."
  exit 2
fi

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "UPOZORNENIE: ANDROID_HOME/ANDROID_SDK_ROOT nie je nastavené."
  echo "Gradle môže zlyhať, ak Android SDK nie je dostupné."
fi

gradle --version
gradle :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "ÚSPECH: APK vytvorené: $APK"
else
  echo "Gradle skončil, ale APK sa nenašlo na očakávanom mieste."
  exit 3
fi
