$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

$Gradle = Get-Command gradle -ErrorAction SilentlyContinue
if (-not $Gradle) {
    Write-Error "Príkaz gradle sa nenašiel. Nainštaluj Gradle a Android SDK alebo otvor projekt v Android Studio."
    exit 2
}

if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
    Write-Warning "ANDROID_HOME/ANDROID_SDK_ROOT nie je nastavené; build môže zlyhať."
}

gradle --version
gradle :app:assembleDebug
$Apk = Join-Path $Root "app/build/outputs/apk/debug/app-debug.apk"
if (Test-Path $Apk) {
    Write-Host "ÚSPECH: APK vytvorené: $Apk"
} else {
    throw "APK sa nenašlo na očakávanom mieste."
}
