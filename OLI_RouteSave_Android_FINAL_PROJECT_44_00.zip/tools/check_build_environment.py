#!/usr/bin/env python3
"""Report Android build prerequisites for OLI RouteSave; does not compile the app."""
from pathlib import Path
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
print("OLI RouteSave — kontrola prostredia")
print("Koreň projektu:", root)
print()

checks = []
checks.append(("Gradle executable", shutil.which("gradle")))
checks.append(("Java executable", shutil.which("java")))
checks.append(("Android SDK env", os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")))
checks.append(("Gradle wrapper", str(root / "gradlew") if (root / "gradlew").is_file() else None))
checks.append(("App build file", str(root / "app" / "build.gradle.kts") if (root / "app" / "build.gradle.kts").is_file() else None))
checks.append(("Manifest", str(root / "app" / "src" / "main" / "AndroidManifest.xml") if (root / "app" / "src" / "main" / "AndroidManifest.xml").is_file() else None))

failed = []
for label, value in checks:
    ok = bool(value)
    print(f"[{'OK' if ok else 'CHÝBA'}] {label}: {value or 'nenájdené'}")
    if label in ("App build file", "Manifest") and not ok:
        failed.append(label)

if shutil.which("java"):
    try:
        proc = subprocess.run(["java", "-version"], text=True, capture_output=True, timeout=5)
        output = (proc.stderr or proc.stdout).strip().splitlines()
        if output:
            print("\nJava verzia:", output[0])
    except Exception as exc:
        print("Java verzia sa nepodarila zistiť:", exc)

sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
if sdk:
    sdk_path = Path(sdk)
    print("SDK cesta existuje:", sdk_path.exists(), f"({sdk_path})")
    if not sdk_path.exists():
        print("UPOZORNENIE: premenná ukazuje na neexistujúcu cestu.")

if not shutil.which("gradle") and not (root / "gradlew").is_file():
    print("\nĎalší krok: otvoriť celý projekt v Android Studio a nechať IDE nastaviť Gradle/SDK,")
    print("alebo nainštalovať Gradle a Android SDK a následne spustiť build skript.")
elif not sdk:
    print("\nĎalší krok: nainštalovať Android SDK a nastaviť ANDROID_HOME/ANDROID_SDK_ROOT.")
else:
    print("\nPredpoklady sú aspoň čiastočne dostupné; spusti tools/build_debug_apk skript na skutočný build.")

print("\nTáto kontrola iba zisťuje dostupnosť nástrojov a súborov. Nekompiluje Kotlin ani negarantuje úspešný build.")
sys.exit(1 if failed else 0)
