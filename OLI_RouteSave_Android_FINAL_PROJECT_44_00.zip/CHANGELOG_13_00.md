# OLI RouteSave — 13.0

Large block: community help foundation.
- Added help requests for drivers, cyclists, pedestrians and other users.
- Added categories, urgency, radius and optional location fields.
- Added validation and a preview-first explicit consent flow.
- Added a publisher boundary that rejects unconfirmed or expired requests.
- Added tests and integration/privacy documentation.
- No network backend or live nearby-user discovery is connected yet.
- Source-only; APK not compiled or device-tested.
