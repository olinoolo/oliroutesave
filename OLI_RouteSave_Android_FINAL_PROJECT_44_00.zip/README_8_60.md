# OLI RouteSave — milestone 8.60: Voice-to-app bridge

## Added
- A provider-neutral coordinator that accepts speech recognition results, parses commands, routes supported intents to callbacks, and produces assistant responses.
- Explicit confirmation state for external actions.
- Assistant profile model including official name, invocation name, personal address, and language.
- Response formatting using the selected assistant's invocation/personal address.
- Tests for command routing and confirmation-first behavior.

## Current limitations
Source-only module; not compiled or device-tested. This connects voice parsing to a controller boundary, but does not yet provide an AI conversation engine, continuous wake-word listening, actual phone calls, SMS sending, or live navigation. Unsupported commands are safely handed back as unknown instead of executing guesses.
