# OLI RouteSave 34.0

# OLI RouteSave 34.0 — Koordinácia hlasovej interakcie

## Pridané
- `VoiceInteractionCoordinator` spája výber asistenta, čiastočný/finálny rozpoznaný text, odpoveď asistenta a čakajúce potvrdenie do jedného stavového toku.
- Kontrola vlastného oslovenia asistenta (napr. Niko, Naty, Vany, Brandži).
- Základné triedenie textových príkazov na navigáciu/cieľ, vyhľadanie spojenia, výpočet nákladov a externé akcie.
- Ak je príkaz nejasný alebo oslovenie nesedí, koordinátor požiada o zopakovanie.
- Požiadavka na externú akciu vytvorí čakajúcu akciu; jasné „nie“ ju zruší a nejasná odpoveď vyvolá ďalšiu otázku.
- Verzia zvýšená na 34.0.

## Bezpečnostné hranice
Koordinátor po potvrdení iba označí čakajúcu akciu ako potvrdenú a oznámi, že aplikácia môže prejsť do ďalšej fázy. Sám nevolá, neposiela SMS, nekupuje lístky ani nezdieľa polohu. Skutočné vykonanie musí byť pripojené v samostatnej vrstve a iba po potvrdení.

## Stav integrácie
Android adaptéry `SpeechRecognizer` a `TextToSpeech` z verzie 33.0 sú stále pripravené ako samostatné komponenty; koordinátor ich zatiaľ automaticky nevytvára ani nespája s Compose obrazovkou. Mikrofón, rozpoznávanie reči a hlasový výstup preto ešte netvoria kompletne integrovaný používateľský tok.

## Zostavenie
Ide o zdrojový Android projekt. APK nebolo vytvorené; Gradle build ani testovanie na zariadení nebolo vykonané v tomto prostredí.
